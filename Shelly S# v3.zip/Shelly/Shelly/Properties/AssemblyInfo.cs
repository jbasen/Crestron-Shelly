﻿using System.Reflection;

[assembly: AssemblyTitle("Shelly")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Shelly")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2020")]
[assembly: AssemblyVersion("1.0.0.*")]


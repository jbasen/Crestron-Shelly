﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Http;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace Shelly_Integration
{
	#region Classes
	//Event Classes
	public class SerialChangeEventArgs : EventArgs
	{
		public string Device_IP { get; set; }
		public string Bluetooth_ID { get; set; }
		public string Device_Type { get; set; }
		public short Channel { get; set; }
		public short Relay_Is_On { get; set; }
		public string Roller_State { get; set; }
		public short Position { get; set; }
		public string Power_Under_or_Over { get; set; }
		public string Action { get; set; }
		public string Button { get; set; }
		public string Output { get; set; }
		public ushort Brightness_Gain { get; set; }
		public short Red { get; set; }
		public short Green { get; set; }
		public short Blue { get; set; }
		public short White { get; set; }
		public short Effect { get; set; }
		public string Lux { get; set; }
		public string Humidity { get; set; }
		public short Temperature { get; set; }
		public short Temperature_Tenths { get; set; }
		public short Target_Temperature_Enabled { get; set; }
		public short Target_Temperature { get; set; }
		public short Target_Temperature_Tenths { get; set; }
		public short Schedule_Enabled { get; set; }
		public short Schedule_Profile_ID { get; set; }
		public string Schedule_Profile_Name { get; set; }
		public string Valve_Position { get; set; }
		public short Battery_Percentage { get; set; }
		public string Error_Condition { get; set; }
		public string Sensor { get; set; }
		public string Sensor_ID { get; set; }
		public short Analog { get; set; }
		public short Digital { get; set; }
		public ushort White_Balance { get; set; }


		public SerialChangeEventArgs()
		{
		}

		public SerialChangeEventArgs(string Device_IP, string Bluetooth_ID, string Device_Type, short Channel, short Relay_Is_On, string Roller_State, 
			short Position, string Power_Under_or_Over, string Action, string Button, string Output, 
			ushort Brightness_Gain, short Red, short Green, short Blue, short White, short Effect,
			string Lux, short Temperature, string Humidity, short Temperature_Tenths, short Target_Temperature_Enabled,
			short Schedule_Enabled, short Schedule_Profile_ID, string Schedule_Profile_Name, string Valve_Position,
			short Target_Temperature, short Target_Temperature_Tenths, short Battery_Percentage, string Error_Condition,
			string Sensor, string Sensor_ID, short Analog, short Digital, ushort White_Balance)
		{
			#region Set Class Data Elements from Parameters
			this.Device_IP = Device_IP;
			this.Bluetooth_ID = Bluetooth_ID;
			this.Device_Type = Device_Type;
			this.Channel = Channel;
			this.Relay_Is_On = Relay_Is_On;
			this.Roller_State = Roller_State;
			this.Position = Position;
			this.Power_Under_or_Over = Power_Under_or_Over;
			this.Action = Action;
			this.Button = Button;
			this.Output = Output;
			this.Brightness_Gain = Brightness_Gain;
			this.Red = Red;
			this.Green = Green;
			this.Blue = Blue;
			this.White = White;
			this.Effect = Effect;
			this.Lux = Lux;
			this.Temperature = Temperature;
			this.Humidity = Humidity;
			this.Temperature_Tenths = Temperature_Tenths;
			this.Target_Temperature_Enabled = Target_Temperature_Enabled;
			this.Target_Temperature = Target_Temperature;
			this.Target_Temperature_Tenths = Target_Temperature_Tenths;
			this.Schedule_Enabled = Schedule_Enabled;
			this.Schedule_Profile_ID = Schedule_Profile_ID;
			this.Schedule_Profile_Name = Schedule_Profile_Name;
			this.Valve_Position = Valve_Position;
			this.Battery_Percentage = Battery_Percentage;
			this.Error_Condition = Error_Condition;
			this.Sensor = Sensor;
			this.Sensor_ID = Sensor_ID;
			this.Analog = Analog;
			this.Digital = Digital;
			this.White_Balance = White_Balance;
			#endregion
		}
	}

	public static class SignalChangeEvents
	{
		public static event SerialChangedEventHandler onSerialValueChange;

		public static void SerialValueChange(string Device_IP, string Bluetooth_ID, string Device_Type, short Channel, short Relay_Is_On, string Roller_State, short Position,
			string Power_Under_or_Over, string Action, string Button, string Output, ushort Brightness_Gain, short Red,
			short Green, short Blue, short White, short Effect, string Lux, short Temperature, string Humidity, short Temperature_Tenths,
			short Target_Temperature_Enabled, short Schedule_Enabled, short Schedule_Profile_ID, string Schedule_Profile_Name, string Valve_Position,
			short Target_Temperature, short Target_Temperature_Tenths, short Battery_Percentage, string Error_Condition,
			string Sensor, string Sensor_ID, short Analog, short Digital, ushort White_Balance)
		{
			SignalChangeEvents.onSerialValueChange(new SerialChangeEventArgs(Device_IP, Bluetooth_ID, Device_Type, Channel, Relay_Is_On, 
				Roller_State, Position, Power_Under_or_Over, Action, Button, Output, Brightness_Gain,
				Red, Green, Blue, White, Effect, Lux, Temperature, Humidity, Temperature_Tenths, Target_Temperature_Enabled,
				Schedule_Enabled, Schedule_Profile_ID, Schedule_Profile_Name, Valve_Position, Target_Temperature,
				Target_Temperature_Tenths, Battery_Percentage, Error_Condition, Sensor, Sensor_ID, Analog, Digital, White_Balance));
		}
	}
	#endregion

	#region Delegates
	public delegate void SerialChangedEventHandler(SerialChangeEventArgs e);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Shelly
	{
		#region Declarations
		private static HttpServer Server;
		private static bool Server_Running = false;
		private static Debug_Options Debug;
		private static string Processor_IP;
		private static string Processor_Port;
		private const int Generation_1_Device = 0;
		private const int Generation_2_Device = 1;
		private const short Temperature_Format_Fehrenheit = 1;
		private const short Temperature_Format_Celcius = 2;
		private const short Measurement_Type_Temperature = 1;
		private const short Measurement_Type_Humidity = 2;
		private const short Measurement_Type_Input = 3;
		private const short Measurement_Type_Analog = 4;
		#endregion

		//****************************************************************************************
		// 
		//  Shelly	-	Default Constructor
		// 
		//****************************************************************************************
		public Shelly()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public short Initialize(string Processor_IP, string Processor_Port, short Debug)
		{
			#region Validate IP Address
			if (Validate_IP_Address(Processor_IP, "Initialize") == false)
			{
				return 0;
			}
			#endregion

			#region Save Parameters
			Shelly.Processor_IP = Processor_IP;
			Shelly.Processor_Port = Processor_Port;
			#endregion

			Set_Debug_Message_Output(Debug);

			#region Create Server for capturing responses from Shelly Devices
			if (Server_Running == false)                                        //don't create server if already running
			{
				if (Create_Server(Processor_IP, Processor_Port) == false)
				{
					Debug_Message("Initialize", "Create Server Failed");
					return 0;
				}
			}
			#endregion

			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Create_Server	-	Setup http server to receive status messages from shelly devices
		// 
		//****************************************************************************************
		private bool Create_Server(string Processor_IP, string Processor_Port)
		{
			try
			{
				//Create a new instance of a server
				Server = new HttpServer();
				//Set the server's IP address
				Server.ServerName = Processor_IP;
				//Set the server's port
				Server.Port = int.Parse(Processor_Port);
				//Assign an event handling method to the server
				Server.OnHttpRequest += new OnHttpRequestHandler(HTTPRequestEventHandler);
				Server.Active = true;
				//save that server is running so initialization can possibly be run again to get device status
				Server_Running = true;
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Shelly - Create_Server - Can't create http server: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Shelly - Create_Server - Can't create http server: " + e + "\n");
				Server.Active = false;
				return false;
			}

			return true;
		}

		//****************************************************************************************
		// 
		//  HTTPRequestEventHandler	-	Handler to receive messages sent from Shelly Devices 
		// 
		//****************************************************************************************
		private void HTTPRequestEventHandler(Object sender, OnHttpRequestArgs requestArgs)
		{
			short Channel;
			string State;
			string Input;
			string Power_Under_or_Over;
			string s = "";
			string Lux = "";
			string Temp = "";
			string Humidity = "";
			short Battery = 101;
			short Temperature = 9999;
			short Temperature_Tenths = 9999;
			double d;
			string Sensor_ID;
			string Sensor;
			short Analog;
			short Digital;

			//Get IP Address of Shelly device that sent message
			string Device_IP = requestArgs.Connection.RemoteEndPointAddress;
			Debug_Message("HTTPRequestEventHandler", "Device_IP = " + Device_IP);

			//Get Path of Request
			string Path = requestArgs.Request.Path;
			Debug_Message("HTTPRequestEventHandler", "Path = " + Path);

			#region Parse Data Elements from Path
			Path = Path.ToUpper();
			
			#region Is this update from a relay?
			s = Parse_Data_Substring(Path, "", "/RELAY/", "/");
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Convert Channel string to short
				try
				{
					Channel = Int16.Parse(s);
				}
				catch (Exception e)
				{
					Debug_Message("HTTPRequestEventHandler", "Exception Parsing Relay from Path - " + Path);
					Debug_Message("HTTPRequestEventHandler", e.ToString());
					return;
				}
				#endregion

				#region Parse State and Imput from Path
				State = Parse_Data_Substring(Path, "", "/STATE/", "/");
				Input = Parse_Data_Substring(Path, "", "/INPUT/", "/");
				if ((String.IsNullOrEmpty(State) == true) && (String.IsNullOrEmpty(Input) == true))
				{
					Debug_Message("HTTPRequestEventHandler", "Path Does Not Contain Relay or Input State - " + Path);
					return;
				}
				#endregion

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Relay - Device_IP = " + Device_IP + ", Channel = " + Channel + ", State = " + State + ", Input = " + Input);
				if (State == "ON")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, "", "RELAY", Channel, 1, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				else if (State == "OFF")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, "", "RELAY", Channel, 0, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				else if ((Input == "OFF") || (Input == "ON") || (Input == "PUSH") || (Input == "LONGPUSH") || (Input == "DOUBLEPUSH"))
				{
					SignalChangeEvents.SerialValueChange(Device_IP, "", "RELAY", Channel, 2, "", 0, "", Input, "", "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				else
				{
					Debug_Message("HTTPRequestEventHandler", "Unknown State/Input In Path - " + Path);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from an EM?
			s = Parse_Data_Substring(Path, "", "/EM/", "/");
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Convert Channel string to short
				try
				{
					Channel = Int16.Parse(s);
				}
				catch (Exception e)
				{
					Debug_Message("HTTPRequestEventHandler", "Exception Parsing Roller from Path - " + Path);
					Debug_Message("HTTPRequestEventHandler", e.ToString());
					return;
				}
				#endregion

				#region Parse Power under or over from Path
				Power_Under_or_Over = Parse_Data_Substring(Path, "", "/POWER/", "/");
				if (String.IsNullOrEmpty(Power_Under_or_Over) == true)
				{
					Debug_Message("HTTPRequestEventHandler", "Path Does Not Contain EM power under/over - " + Path);
					return;
				}
				#endregion

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "EM - Device_IP = " + Device_IP + ", Channel = " + Channel + ", Power_Under_or_Over = " + Power_Under_or_Over);
				SignalChangeEvents.SerialValueChange(Device_IP, "", "EM", Channel, 0, "", 0, Power_Under_or_Over, "", "", "", 101, 256, 256, 256, 256, 256,
					"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				#endregion
				return;
			}
			#endregion

			#region Is this update from a roller?
			s = Parse_Data_Substring(Path, "", "/ROLLER/", "/");
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Convert Channel string to short
				try
				{
					Channel = Int16.Parse(s);
				}
				catch (Exception e)
				{
					Debug_Message("HTTPRequestEventHandler", "Exception Parsing Roller from Path - " + Path);
					Debug_Message("HTTPRequestEventHandler", e.ToString());
					return;
				}
				#endregion

				#region Parse Roller State from Path
				State = Parse_Data_Substring(Path, "", "/STATE/", "/");
				if (String.IsNullOrEmpty(State) == true)
				{
					Debug_Message("HTTPRequestEventHandler", "Path Does Not Contain Roller State - " + Path);
					return;
				}
				#endregion

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Roller - Device_IP = " + Device_IP + ", Channel = " + Channel + ", State = " + State);
				SignalChangeEvents.SerialValueChange(Device_IP, "", "ROLLER", Channel, 0, State, 101, "", "", "", "", 101, 256, 256, 256, 256, 256,
					"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				#endregion
				return;
			}
			#endregion

			#region Is this update from a Motion Sensor
			s = Parse_Data_Substring(Path, "", "/MOTION/", "/");
			// - actions = detected, detected_in_dark, detected_in_twilight, detected_in_bright, end_of_motion, tamper, end_of_tamper
			if (String.IsNullOrEmpty(s) == false)
			{
				if (s == "SENSOR")
				{
					//Get Query Strings of Request
					QueryString query = requestArgs.Request.QueryString;

					#region Parse Lux
					Lux = query["lux"];
					if (String.IsNullOrEmpty(Lux) == true)
					{
						Lux = "";
					}
					Debug_Message("HTTPRequestEventHandler", "lux = " + Lux);
					#endregion

					#region Parse Temp
					Temp = query["temp"];
					if (String.IsNullOrEmpty(Temp) == false)
					{
						try
						{
							d = Double.Parse(Temp);
							Temperature = Convert.ToInt16(Math.Round(d, 0));
							Temperature_Tenths = Convert.ToInt16(Math.Round((d * 10), 0));
							Debug_Message("HTTPRequestEventHandler", "Temperature = " + Temperature);
							Debug_Message("HTTPRequestEventHandler", "Temperature_Tenths = " + Temperature_Tenths);
						}
						catch (Exception e)
						{
							Debug_Message("HTTPRequestEventHandler", "Exception Parsing Temperature from Temp String - " + Temp);
							Debug_Message("HTTPRequestEventHandler", e.ToString());
							return;
						}
					}
					#endregion

					#region Parse Battery
					Temp = query["bat"];
					if (String.IsNullOrEmpty(Temp) == false)
					{
						try
						{
							Battery = Int16.Parse(Temp);
							Debug_Message("HTTPRequestEventHandler", "Battery = " + Battery);
						}
						catch (Exception e)
						{
							Debug_Message("HTTPRequestEventHandler", "Exception Parsing Battery from Temp String - " + Temp);
							Debug_Message("HTTPRequestEventHandler", e.ToString());
							return;
						}
					}
					#endregion
				}

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Motion - Device_IP = " + Device_IP + ", Action = " + s);
				SignalChangeEvents.SerialValueChange(Device_IP, "", "MOTION", 0, 0, "", 0, "", s, "", "", 101, 256, 256, 256, 256, 256,
					Lux, Temperature, "", Temperature_Tenths, 256, 256, 256, "", "", 9999, 9999, Battery, "", "", "", 0, 0, 0);
				#endregion
				return;
			}
			#endregion

			#region Is this update from an Uni
			s = Parse_Data_Substring(Path, "", "/UNI/", "/");
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Convert Channel string to short
				try
				{
					Channel = Int16.Parse(s);
				}
				catch (Exception e)
				{
					Debug_Message("HTTPRequestEventHandler", "Exception Parsing UNI from Path - " + Path);
					Debug_Message("HTTPRequestEventHandler", e.ToString());
					return;
				}

				#endregion

				#region Button Update
				s = Parse_Data_Substring(Path, "", "/BUTTON/", "/");
				if (String.IsNullOrEmpty(s) == false)
				{
					#region Send Device Status
					Debug_Message("HTTPRequestEventHandler", "Uni - Device_IP = " + Device_IP + ", Channel = " + Channel + ", Button = " + s);
					SignalChangeEvents.SerialValueChange(Device_IP, "", "UNI", Channel, 0, "", 0, "", "", s, "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
					#endregion
					return;
				}
				#endregion

				#region Output Update
				s = Parse_Data_Substring(Path, "", "/OUTPUT/", "/");
				if (String.IsNullOrEmpty(s) == false)
				{
					#region Send Device Status
					Debug_Message("HTTPRequestEventHandler", "Uni - Device_IP = " + Device_IP + ", Channel = " + Channel + ", Output = " + s);
					SignalChangeEvents.SerialValueChange(Device_IP, "", "UNI", Channel, 0, "", 0, "", "", "", s, 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
					#endregion
					return;
				}
				#endregion
			}
			#endregion

			#region Is this update from an i3 or i4
			s = Parse_Data_Substring(Path, "", "/I3/", "/");
			if (String.IsNullOrEmpty(s) == true)
			{
				s = Parse_Data_Substring(Path, "", "/I4/", "/");
			}
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Convert Channel string to short
				try
				{
					Channel = Int16.Parse(s);
				}
				catch (Exception e)
				{
					Debug_Message("HTTPRequestEventHandler", "Exception Parsing i3-i4 from Path - " + Path);
					Debug_Message("HTTPRequestEventHandler", e.ToString());
					return;
				}

				#endregion

				#region Button Update
				s = Parse_Data_Substring(Path, "", "/BUTTON/", "/");
				if (String.IsNullOrEmpty(s) == false)
				{
					#region Send Device Status
					Debug_Message("HTTPRequestEventHandler", "i3-i4 - Device_IP = " + Device_IP + ", Channel = " + Channel + ", Button = " + s);
					SignalChangeEvents.SerialValueChange(Device_IP, "", "I3-I4", Channel, 0, "", 0, "", "", s, "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
					#endregion
					return;
				}
				#endregion
			}
			#endregion

			#region Is this update from a dimmer?
			s = Parse_Data_Substring(Path, "", "/DIMMER/", "/");
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Parse State and Imput from Path
				State = Parse_Data_Substring(Path, "", "/STATE/", "/");
				Input = Parse_Data_Substring(Path, "", "/INPUT/", "/");
				if ((String.IsNullOrEmpty(State) == true) && (String.IsNullOrEmpty(Input) == true))
				{
					Debug_Message("HTTPRequestEventHandler", "Path Does Not Contain Dimmer or Input State - " + Path);
					return;
				}
				#endregion

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Dimmer - Device_IP = " + Device_IP + ", State = " + State);
				if (State == "ON")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, "", "DIMMER", 0, 1, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				else if (State == "OFF")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, "", "DIMMER", 0, 0, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				else if ((Input == "OFF") || (Input == "ON") || (Input == "PUSH") || (Input == "LONGPUSH") || (Input == "DOUBLEPUSH"))
				{
					SignalChangeEvents.SerialValueChange(Device_IP, "", "DIMMER", 0, 2, "", 0, "", Input, "", "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				else
				{
					Debug_Message("HTTPRequestEventHandler", "Unknown State In Path - " + Path);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from a RGBW?
			State = Parse_Data_Substring(Path, "", "/RGBW/STATE/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Get State
				if (String.IsNullOrEmpty(State) == true)
				{
					Debug_Message("HTTPRequestEventHandler", "Path Does Not Contain Dimmer State - " + Path);
					return;
				}
				#endregion

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "RGBW - Device_IP = " + Device_IP + ", State = " + State);
				if (State == "ON")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, "", "RGBW", 0, 1, "", 0, "", "", "", "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				else if (State == "OFF")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, "", "RGBW", 0, 0, "", 0, "", "", "", "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				else
				{
					Debug_Message("HTTPRequestEventHandler", "Unknown State In Path - " + Path);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from a button?
			State = Parse_Data_Substring(Path, "", "/BUTTON/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Button - Device_IP = " + Device_IP + ", State = " + State);
				SignalChangeEvents.SerialValueChange(Device_IP, "", "BUTTON", 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256,
					"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				#endregion
				return;
			}
			#endregion

			#region Is this update from a door-window 2?
			State = Parse_Data_Substring(Path, "", "/DW2/", "/");
			if (String.IsNullOrEmpty(State) == false)//for Sensor url action
			{
				//Set to values for invalid reading	
				Temperature = 9999;
				Temperature_Tenths = 9999;

				//Get Query Strings of Request
				QueryString query = requestArgs.Request.QueryString;

				#region Parse Lux
				Lux = query["lux"];
				if (String.IsNullOrEmpty(Lux) == true)
				{
					Lux = "";
				}
				Debug_Message("HTTPRequestEventHandler", "lux = " + Lux);
				#endregion

				#region Parse Temp
				Temp = query["temp"];
				if (String.IsNullOrEmpty(Temp) == false)
				{
					try
					{
						d = Double.Parse(Temp);
						Temperature = Convert.ToInt16(Math.Round(d, 0));
						Temperature_Tenths = Convert.ToInt16(Math.Round((d * 10), 0));
						Debug_Message("HTTPRequestEventHandler", "Temperature = " + Temperature);
						Debug_Message("HTTPRequestEventHandler", "Temperature_Tenths = " + Temperature_Tenths);
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Temperature from Temp String - " + Temp);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				#endregion

				#region Send Device Status
				if ((String.IsNullOrEmpty(State) == false) || (String.IsNullOrEmpty(Lux) == false) || (String.IsNullOrEmpty(Temp) == false))
				{
					Debug_Message("HTTPRequestEventHandler", "Door-Window 2 - Device_IP = " + Device_IP + ", State = " + State);
					SignalChangeEvents.SerialValueChange(Device_IP, "", "DOOR-WINDOW2", 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256,
						Lux, Temperature, "", Temperature_Tenths, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from a fist generation humidity-temperature sensor?
			State = Parse_Data_Substring(Path, "", "/HT/", "/");
			if (String.IsNullOrEmpty(State) == false)//for Sensor url action
			{
				//Set to values for invalid reading	
				Temperature = 9999;
				Temperature_Tenths = 9999;

				//Get Query Strings of Request
				QueryString query = requestArgs.Request.QueryString;

				#region Parse Humidity
				Humidity = query["hum"];
				if (String.IsNullOrEmpty(Humidity) == true)
				{
					Humidity = "";
				}
				Debug_Message("HTTPRequestEventHandler", "humidity = " + Humidity);
				#endregion

				#region Parse Temperature
				Temp = query["temp"];
				if (String.IsNullOrEmpty(Temp) == false)
				{
					try
					{
						d = Double.Parse(Temp);
						Temperature = Convert.ToInt16(Math.Round(d, 0));
						Temperature_Tenths = Convert.ToInt16(Math.Round((d * 10), 0));
						Debug_Message("HTTPRequestEventHandler", "Temperature = " + Temperature);
						Debug_Message("HTTPRequestEventHandler", "Temperature_Tenths = " + Temperature_Tenths);
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Temperature from Temp String - " + Temp);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				#endregion

				#region Send Device Status
				if ((String.IsNullOrEmpty(State) == false) || (String.IsNullOrEmpty(Humidity) == false) || (String.IsNullOrEmpty(Temp) == false))
				{
					Debug_Message("HTTPRequestEventHandler", "Humidity-Temperature Sensor - Device_IP = " + Device_IP + ", State = " + State);
					SignalChangeEvents.SerialValueChange(Device_IP, "", "HT_SENSOR", 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256, "",
						Temperature, Humidity, Temperature_Tenths, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from a plus humidity-temperature sensor?
			//http://[Processor_IP]:[Processor_Port]/plus-ht/sensor/temperature/$temperature/
			//http://[Processor_IP]:[Processor_Port]/plus-ht/sensor/temperature/$temperatureF/
			//http://[Processor_IP]:[Processor_Port]/plus-ht/sensor/humidity/$humidity/
			State = Parse_Data_Substring(Path, "", "/PLUS-HT", "/");
			if (String.IsNullOrEmpty(State) == false)//for Sensor url action
			{
				//Set to values for invalid reading	
				Temperature = 9999;
				Temperature_Tenths = 9999;

				#region Parse Humidity
				Humidity = Parse_Data_Substring(Path, "", "/HUMIDITY/", "/");
				if (String.IsNullOrEmpty(Humidity) == true)
				{
					Humidity = "";
				}
				else
				{
					try
					{
						d = Double.Parse(Humidity);
						d = Convert.ToInt16(Math.Round(d, 0));
						Humidity = d.ToString();
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Humdiity from String - " + Temp);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				Debug_Message("HTTPRequestEventHandler", "humidity = " + Humidity);
				#endregion

				#region Parse Temperature
				Temp = Parse_Data_Substring(Path, "", "/TEMPERATURE/", "/");
				if (String.IsNullOrEmpty(Temp) == false)
				{
					try
					{
						d = Double.Parse(Temp);
						Temperature = Convert.ToInt16(Math.Round(d, 0));
						Temperature_Tenths = Convert.ToInt16(Math.Round((d * 10), 0));
						Debug_Message("HTTPRequestEventHandler", "Temperature = " + Temperature);
						Debug_Message("HTTPRequestEventHandler", "Temperature_Tenths = " + Temperature_Tenths);
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Temperature from Temp String - " + Temp);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				#endregion

				#region Send Device Status
				if ((String.IsNullOrEmpty(State) == false) || (String.IsNullOrEmpty(Humidity) == false) || (String.IsNullOrEmpty(Temp) == false))
				{
					Debug_Message("HTTPRequestEventHandler", "Humidity-Temperature Sensor - Device_IP = " + Device_IP + ", State = " + State);
					SignalChangeEvents.SerialValueChange(Device_IP, "", "PLUS_HT_SENSOR", 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256, "",
						Temperature, Humidity, Temperature_Tenths, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				#endregion
			}
			#endregion

			#region Is this update from a flood sensor?
			State = Parse_Data_Substring(Path, "", "/FLOOD/", "/");
			if (String.IsNullOrEmpty(State) == false)//for Sensor url action
			{
				//Set to values for invalid reading	
				Temperature = 9999;
				Temperature_Tenths = 9999;

				//Get Query Strings of Request
				QueryString query = requestArgs.Request.QueryString;

				#region Parse Temperature
				Temp = query["temp"];
				if (String.IsNullOrEmpty(Temp) == false)
				{
					try
					{
						d = Double.Parse(Temp);
						Temperature = Convert.ToInt16(Math.Round(d, 0));
						Temperature_Tenths = Convert.ToInt16(Math.Round((d * 10), 0));
						Debug_Message("HTTPRequestEventHandler", "Temperature = " + Temperature);
						Debug_Message("HTTPRequestEventHandler", "Temperature_Tenths = " + Temperature_Tenths);
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Temperature from Temp String - " + Temp);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				#endregion

				#region Send Device Status
				if ((String.IsNullOrEmpty(State) == false) || (String.IsNullOrEmpty(Temp) == false))
				{
					Debug_Message("HTTPRequestEventHandler", "Flood Sensor - Device_IP = " + Device_IP + ", State = " + State);
					SignalChangeEvents.SerialValueChange(Device_IP, "", "FLOOD", 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256, "",
						Temperature, "", Temperature_Tenths, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				}
				#endregion
				return;
			}

			#endregion

			#region Is this update from a gas sensor?
			State = Parse_Data_Substring(Path, "", "/GAS/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Gas Sensor - Device_IP = " + Device_IP + ", State = " + State);
				SignalChangeEvents.SerialValueChange(Device_IP, "", "GAS", 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256,
					"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				#endregion
				return;
			}
			#endregion

			#region Is this update from a TRV?
			State = Parse_Data_Substring(Path, "", "/TRV/STATE/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "TRV - Device_IP = " + Device_IP + ", State = " + State);
				SignalChangeEvents.SerialValueChange(Device_IP, "", "TRV", 0, 0, "", 0, "", "", "", "", 101, 256, 256, 256, 256, 256,
					"", 9999, "", 9999, 256, 256, 256, "", State, 9999, 9999, 101, "", "", "", 0, 0, 0);
				#endregion
				return;
			}
			#endregion

			#region Is this update from a smoke detector?
			State = Parse_Data_Substring(Path, "", "/SMOKE/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Smoke Detector - Device_IP = " + Device_IP + ", State = " + State);
				SignalChangeEvents.SerialValueChange(Device_IP, "", "SMOKE", 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256,
					"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
				#endregion
				return;
			}
			#endregion

			#region Is this update from a Window Controller Plus 1PM/Plus2PM?
			State = Parse_Data_Substring(Path, "", "/WINDOW/STATE/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Window Controller - Device_IP = " + Device_IP + ", State = " + State);
				SignalChangeEvents.SerialValueChange(Device_IP, "", "WINDOW_CONTROLLER", 0, 0, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256,
					"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, State, "", "", 0, 0, 0);
				#endregion
				return;
			}
			#endregion

			#region Is this update from an Add-On Connected to a Shelly Plus 1 or Plus 1PM
			Sensor_ID = Parse_Data_Substring(Path, "", "/PLUS1-1PM-ADDON/", "/");
			if (String.IsNullOrEmpty(Sensor_ID) == false)
			{
				//http://[Processor_IP]:[Processor_Port]/plus1-1pm-AddOn/Sensor_ID/temperature/$temperature/
				//http://[Processor_IP]:[Processor_Port]/plus1-1pm-AddOn/Sensor_ID/humidity/$humidity/
				//http://[Processor_IP]:[Processor_Port]/plus1-1pm-AddOn/Sensor_ID/digital/on|off/
				//http://[Processor_IP]:[Processor_Port]/plus1-1pm-AddOn/Sensor_ID/analog/value/
				Sensor = "";
				Temperature = -1;
				Analog = -1;
				Digital = -1;

				#region Parse Humidity
				Humidity = Parse_Data_Substring(Path, "", "/HUMIDITY/", "/");
				if (String.IsNullOrEmpty(Humidity) == true)
				{
					Humidity = "";
				}
				else
				{
					Sensor = "HUMIDITY";
					try
					{
						d = Double.Parse(Humidity);
						d = Convert.ToInt16(Math.Round(d, 0));
						Humidity = d.ToString();
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Humdiity from String - " + Temp);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				Debug_Message("HTTPRequestEventHandler", "humidity = " + Humidity);
				#endregion

				#region Parse Temperature
				//Set to values for invalid reading	
				Temperature = 9999;
				Temperature_Tenths = 9999;
				Temp = Parse_Data_Substring(Path, "", "/TEMPERATURE/", "/");
				if (String.IsNullOrEmpty(Temp) == false)
				{
					Sensor = "TEMPERATURE";
					try
					{
						d = Double.Parse(Temp);
						Temperature = Convert.ToInt16(Math.Round(d, 0));
						Temperature_Tenths = Convert.ToInt16(Math.Round((d * 10), 0));
						Debug_Message("HTTPRequestEventHandler", "Temperature = " + Temperature);
						Debug_Message("HTTPRequestEventHandler", "Temperature_Tenths = " + Temperature_Tenths);
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Temperature from Temp String - " + Temp);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				#endregion

				#region Parse Digital
				s = Parse_Data_Substring(Path, "", "/DIGITAL/", "/");
				if (String.IsNullOrEmpty(s) == false)
				{
					Sensor = "DIGITAL";
					if (s == "ON")
					{
						Digital = 1;
					}
					else
					{
						Digital = 0;
					}
				}
				Debug_Message("HTTPRequestEventHandler", "Digital = " + Digital);
				#endregion

				#region Parse Analog
				s = Parse_Data_Substring(Path, "", "/ANALOG/", "/");
				if (String.IsNullOrEmpty(s) == false)
				{
					Sensor = "ANALOG";
					try
					{
						Analog = short.Parse(Temp);
						Debug_Message("HTTPRequestEventHandler", "Analog = " + Analog);
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Analog from Temp String - " + s);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				Debug_Message("HTTPRequestEventHandler", "Analog = " + Analog);
				#endregion

				#region Send Device Status
				if ((String.IsNullOrEmpty(Humidity) == false) || (Temperature != -1) || (Analog != -1) || (Digital != -1))
				{
					Debug_Message("HTTPRequestEventHandler", "Shelly Plus 1 or Plus 1PM Add-On - Device_IP = " + Device_IP + ", Sensor_ID = " + Sensor_ID);
					SignalChangeEvents.SerialValueChange(Device_IP, "", "ADD-ON", 0, 0, "", 0, "", "", "ADD-ON", "", 101, 256, 256, 256, 256, 256, "",
						Temperature, Humidity, Temperature_Tenths, 256, 256, 256, "", "", 9999, 9999, 101, "", Sensor, Sensor_ID, Analog, Digital, 0);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from a Bluetooth Door/Window Sensor
			if (Path.Contains("DWBLU") == true)		{
				Bluetooth_Device_Info Item = Bluetooth_Device_Info.Parse(requestArgs.Request.ContentString);
				Debug_Message("HTTPRequestEventHandler", "Bluetooth Door-Window - Device_ID = " + Item.DeviceId + ", State = "
					+ Item.State + ", Rotation = " + Item.Rotation + ", Lux = " + Item.Lux);
				SignalChangeEvents.SerialValueChange("", Item.DeviceId, Item.DeviceType, 0, 0, "", Item.Rotation, "", "", Item.State, "", 101, 256, 256, 256, 256, 256,
					Item.Lux.ToString(), 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, Item.Battery, "", "", "", 0, 0, 0);
				return;
			}
			#endregion

			#region Is this update from a Bluetooth Button
			if (Path.Contains("BUTTONBLU") == true)
			{
				Bluetooth_Device_Info Item = Bluetooth_Device_Info.Parse(requestArgs.Request.ContentString);
				Debug_Message("HTTPRequestEventHandler", "Bluetooth Button - Device_ID = " + Item.DeviceId + ", State = " + Item.State);
				SignalChangeEvents.SerialValueChange("", Item.DeviceId, Item.DeviceType, 0, 0, "", 0, "", "", Item.State, "", 101, 256, 256, 256, 256, 256,
					"", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, Item.Battery, "", "", "", 0, 0, 0);
				return;
			}
			#endregion

			Debug_Message("HTTPRequestEventHandler", "Unknown Device Type in Path = " + Path);
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Input_State	-	Gets the state of inputs on Shelly devices for
		//						initializtion of S+ modules at startup
		// 
		//****************************************************************************************
		public short Get_Input_State(string Device_IP, ushort Device_Generation, short Input_Count, 
			ref ushort Input_0_State, ref ushort Input_1_State, ref ushort Input_2_State, ref ushort Input_3_State)
		{
			HttpClient client = null;

			Debug_Message("Get_Input_State", "Device_IP = " + Device_IP + ", Device_Generation = " + Device_Generation + ", Input_Count = " + Input_Count);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Get_Input_State") == false)
			{
				return 0;
			}
			#endregion
			
			//Check if device doesn't have any inputs
			if (Input_Count == 0)
			{
				return 1;
			}

			if (Device_Generation == Generation_1_Device)
			{
				#region Create url
				string url = "";

				url = "http://" + Device_IP + "/status";

				Debug_Message("Get_Input_State", "URL: " + url);
				#endregion

				#region Send Command
				try
				{
					//Create http client
					client = new HttpClient();
					//client.Verbose = true;
					HttpClientRequest request = new HttpClientRequest();
					HttpClientResponse response;

					//Format http client request
					request.KeepAlive = false;
					request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
					request.Url.Parse(url);

					//Get response
					response = client.Dispatch(request);
					if (response.Code < 200 || response.Code >= 300)
					{
						// server threw a error.
						string err = "Shelly - Get_Input_State - http response code: " + response.Code;
						CrestronConsole.PrintLine(err);
						Crestron.SimplSharp.ErrorLog.Error(err + "\n");
						return 0;
					}
					else
					{
						string s = response.ContentString;
						Debug_Message("Get_Input_State", "ContentString = " + s);
						#region Parse Json
						s = Parse_Data_Substring(s, "", "\"inputs\":", "]");
						//TODO Parse for Input and then make it parsable
						s = "{\"inputList\":" + s + "]}";  //make json parsable by newtonsoft

						Debug_Message("Get_Input_List", "JSON = " + s);

						Gen_1_Input_List List = Gen_1_Input_List.Parse(s);
						if (List != null)
						{
							//Loop through list
							for (int i = 0; i < List.inputList.Count; i++)
							{
								Debug_Message("Get_Input_List", "Input[" + i + "] = " + List.inputList[i].input);
								switch (i)
								{
									case 0:
										Input_0_State = List.inputList[i].input;
										break;

									case 1:
										Input_1_State = List.inputList[i].input;
										break;

									case 2:
										Input_2_State = List.inputList[i].input;
										break;

									case 3:
										Input_3_State = List.inputList[i].input;
										break;
								}
							}
						}
						else
						{
							Debug_Message("Get_Input_List", "Returned List = null");
						}

						#endregion
					}
				}
				catch (Exception e)
				{
					string err = "Shelly - Get_Input_State - Error Obtaining Device Input State: " + e;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}
				finally
				{
					if (client != null)
					{
						client.Dispose();
					}
				}
				#endregion
			}
			else//Gen 2
			{
				for (int i = 0; i < Input_Count; i++)
				{
					#region Create url
					string url = "";

					url = "http://" + Device_IP + "/rpc/input.getstatus?id=" + i;

					Debug_Message("Get_Input_State", "URL: " + url);
					#endregion

					#region Send Command
					try
					{
						//Create http client
						client = new HttpClient();
						//client.Verbose = true;
						HttpClientRequest request = new HttpClientRequest();
						HttpClientResponse response;

						//Format http client request
						request.KeepAlive = false;
						request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
						request.Url.Parse(url);

						//Get response
						response = client.Dispatch(request);
						if (response.Code < 200 || response.Code >= 300)
						{
							// server threw a error.
							string err = "Shelly - Get_Input_State - http response code: " + response.Code;
							CrestronConsole.PrintLine(err);
							Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							return 0;
						}
						else
						{
							string ContentString = response.ContentString;
							Debug_Message("Get_Input_State", "ContentString = " + ContentString);

							#region Parse JSON
							Gen_2_Input_Info Item = Gen_2_Input_Info.Parse(ContentString);
							
							switch (Item.id)
							{
								case 0:
									Input_0_State = Convert.ToUInt16(Item.state ? 1 : 0);
									break;

								case 1:
									Input_1_State = Convert.ToUInt16(Item.state ? 1 : 0);
									break;

								case 2:
									Input_2_State = Convert.ToUInt16(Item.state ? 1 : 0);
									break;

								case 3:
									Input_3_State = Convert.ToUInt16(Item.state ? 1 : 0);
									break;
							}
							#endregion
						}
					}
					catch (Exception e)
					{
						string err = "Shelly - Get_Input_State - Error Obtaining Device Input State: " + e;
						CrestronConsole.PrintLine(err);
						Crestron.SimplSharp.ErrorLog.Error(err + "\n");
						return 0;
					}
					finally
					{
						if (client != null)
						{
							client.Dispose();
						}
					}
					#endregion
				}
			}

			return 1;
		}

		//****************************************************************************************
		// 
		//  Send_Device_Command	-	Sends a relay command (on, off, etc.) to the Shelly
		//							Command Format	=	http://[device_IP]/relay/[channel]?command
		//												http://user:pass@[device_IP]/relay/[channel]?command
		//												command format - turn=on, turn=off, turn=toggle
		// 
		//****************************************************************************************
		public void Send_Relay_Command(string Device_IP, short Channel, short Command, string Username, string Password)
		{
			HttpClient client = null;

			Debug_Message("Send_Relay_Command", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password + ", Command = " + Command);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Send_Relay_Command") == false)
			{
				return;
			}
			#endregion

			#region Create url
			string url = "";

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/relay/" + Channel;
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/relay/" + Channel;
			}
			
			//Add Command to URL
			switch (Command)
			{
				case 0:
					//turn off
					url += "?turn=off";
					break;

				case 1:
					//turn on
					url += "?turn=on";
					break;

				case 2:
					//toggle
					url += "?turn=toggle";
					break;

				case 3:
					//refresh device state
					break;

				default:
					//unsupported command
					Debug_Message("Send_Relay_Command", "Error - Unsupported command - " + Command);
					return;
			}

			Debug_Message("Send_Relay_Command", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Send_Relay_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Send_Relay_Command", "ContentString = " + ContentString);
					string s = Parse_Data_Substring(ContentString, "", "\"ison\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_Relay_Command", "ison = " + s);
						short Relay_Is_On = Convert.ToInt16(((s == "true") || (s == " true")) ? 1 : 0);
						SignalChangeEvents.SerialValueChange(Device_IP, "", "RELAY", Channel, Relay_Is_On, "", 0, "", "STATE", "", "", 101,
							256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
					}
					else
					{
						Debug_Message("Send_Relay_Command", "Error - Unable to Parse Device State from Content String");
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Send_Relay_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_Roller_Command	-	Sends a command to a Shelly 2.5 connected to a roller shade
		//							or similar motorized device.
		//							Command Format	=	http://[device_IP]/roller/0/?command
		//												http://user:pass@[device_IP]/roller/0/?command
		//												command format - go=open, go=close, go=stop, go=to_pos&roller_pos=x
		// 
		//****************************************************************************************
		public void Send_Roller_Command(string Device_IP, ushort Device_Generation, short Channel, short Command, short position, string Username, string Password)
		{
			string State;
			short Current_Position;
			HttpClient client = null;
			string s;

			Debug_Message("Send_Roller_Command", "Device_IP = " + Device_IP + ", Device_Generation = " + Device_Generation + ", Command = " + Command + ", Position = " + position);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Send_Roller_Command") == false)
			{
				return;
			}
			#endregion

			if (Device_Generation == Generation_1_Device)
			{
				Debug_Message("Send_Roller_Command", "Generation 1");

				#region Create url
			string url = "";

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/roller/" + Channel + "/";
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/roller/" + Channel + "/";
			}

			//Add Command to URL
			switch (Command)
			{
				case 0:
					//open
					url += "?go=open";
					break;

				case 1:
					//close
					url += "?go=close";
					break;

				case 2:
					//stop
					url += "?go=stop";
					break;

				case 3:
					//refresh device state
					break;

				case 4:
					//set position
					if (position < 0)
					{
						position = 0;
					}
					else if (position > 100)
					{
						position = 100;
					}
					url += "?go=to_pos&roller_pos=" + position;
					break;

				default:
					//unsupported command
					Debug_Message("Send_Roller_Command", "Error - Unsupported command - " + Command);
					return;
			}

			Debug_Message("Send_Roller_Command", "URL: " + url);
			#endregion

				#region Send Command
				try
				{
					//Create http client
					client = new HttpClient();
					//client.Verbose = true;
					HttpClientRequest request = new HttpClientRequest();
					HttpClientResponse response;

					//Format http client request
					request.KeepAlive = false;
					request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
					request.Url.Parse(url);

					//Get response
					response = client.Dispatch(request);
					if (response.Code < 200 || response.Code >= 300)
					{
						// server threw a error.
						string err = "Shelly - Send_Roller_Command - http response code: " + response.Code;
						CrestronConsole.PrintLine(err);
						Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					}
					else
					{
						string ContentString = response.ContentString;
						Debug_Message("Send_Roller_Command", "ContentString = " + ContentString);
						if (string.IsNullOrEmpty(ContentString) == false)
						{
							#region Parse State
							State = Parse_Data_Substring(ContentString, "", "\"state\":\"", "\",");
							if (string.IsNullOrEmpty(State) == true)
							{
								Debug_Message("Send_Roller_Command", "Error - Unable to Parse Device State from Content String");
								return;
							}
							#endregion

							#region Parse Current Position
							s = Parse_Data_Substring(ContentString, "", "\"current_pos\":", ",");
							if ((string.IsNullOrEmpty(s) == true) || (s == "null"))
							{
								Debug_Message("Send_Roller_Command", "Error - Unable to Parse Current Position from Content String");
								Current_Position = 101;
							}
							else
							{
								Current_Position = Int16.Parse(s);
							}
							#endregion

							Debug_Message("Send_Roller_Command", "State = " + State + ", Current_Position = " + Current_Position);
							SignalChangeEvents.SerialValueChange(Device_IP, "", "ROLLER", Channel, 0, State, Current_Position, "", "", "", "", 101,
								256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
						}
					}
				}
				catch (Exception e)
				{
					string err = "Shelly - Send_Roller_Command - Error Sending Device Command: " + e;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				finally
				{
					if (client != null)
					{
						client.Dispose();
					}
				}
				#endregion
			}
			else//Generation 2
			{
				Debug_Message("Send_Roller_Command", "Generation 2");

				#region Create url
				string url = "";
				if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
				{
					url = "http://" + Device_IP + "/rpc/Cover";
				}
				else
				{
					url = "http://" + Username + ":" + Password + "@" + Device_IP + "/rpc/Cover";
				}

				//Add Command to URL
				switch (Command)
				{
					case 0:
						//open
						url += ".Open?id=" + Channel;
						break;

					case 1:
						//close
						url += ".Close?id=" + Channel;
						break;

					case 2:
						//stop
						url += ".Stop?id=" + Channel;
						break;

					case 3:
						//refresh device state
						url += ".GetStatus?id=" + Channel;
						break;

					case 4:
						//set position
						if (position < 0)
						{
							position = 0;
						}
						else if (position > 100)
						{
							position = 100;
						}
						url += ".GoToPosition?id=" + Channel + "&pos=" + position;
						break;

					default:
						//unsupported command
						Debug_Message("Send_Roller_Command", "Error - Unsupported command - " + Command);
						return;
				}

				Debug_Message("Send_Roller_Command", "URL: " + url);
				#endregion

				#region Send Command
				try
				{
					//Create http client
					client = new HttpClient();
					//client.Verbose = true;
					HttpClientRequest request = new HttpClientRequest();
					HttpClientResponse response;

					//Format http client request
					request.KeepAlive = false;
					request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
					request.Url.Parse(url);

					//Get response
					response = client.Dispatch(request);
					if (response.Code < 200 || response.Code >= 300)
					{
						// server threw a error.
						string err = "Shelly - Send_Roller_Command - http response code: " + response.Code;
						CrestronConsole.PrintLine(err);
						Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					}
					else
					{
						string ContentString = response.ContentString;
						if (string.IsNullOrEmpty(ContentString) == false)
						{
							Debug_Message("Send_Roller_Command", "ContentString = " + ContentString);
							#region Parse State
							State = Parse_Data_Substring(ContentString, "", "\"state\":\"", "\"");
							if (string.IsNullOrEmpty(State) == true)
							{
								Debug_Message("Send_Roller_Command", "Error - Unable to Parse Device State from Content String");
								return;
							}
							#endregion

							#region Parse Current Position
							s = Parse_Data_Substring(ContentString, "", "\"current_pos\":", "}");
							if ((string.IsNullOrEmpty(s) == true) || (s == "null"))
							{
								Debug_Message("Send_Roller_Command", "Error - Unable to Parse current position from Content String");
								Current_Position = 101;
							}
							else
							{
								Current_Position = Int16.Parse(s);
							}
							#endregion

							Debug_Message("Send_Roller_Command", "State = " + State + ", Current_Position = " + Current_Position);
							SignalChangeEvents.SerialValueChange(Device_IP, "", "ROLLER", Channel, 0, State, Current_Position, "", "", "", "", 101,
								256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
						}
					}
				}
				catch (Exception e)
				{
					string err = "Shelly - Send_Roller_Command - Error Sending Device Command: " + e;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				finally
				{
					if (client != null)
					{
						client.Dispose();
					}
				}
				#endregion
			}
		}

		//****************************************************************************************
		// 
		//  Send_Dimmer_Command	-	Sends a dimmer command (on, off, etc.) to the Shelly
		// 
		//****************************************************************************************
		public void Send_Dimmer_Command(string Device_IP, short Command, ushort Brightness, ushort Device_Generation, ushort Supports_White_Balance, ushort White_Balance, string Username, string Password)
		{
			short Light_Is_On = 0;
			string s = "";
			int iWhite_Balance = 0 ;
			HttpClient client = null;

			Debug_Message("Send_Dimmer_Command", "Device_IP = " + Device_IP + ", Command = " + Command + ", Level = " + Brightness + ", White_Balance = " + White_Balance);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Send_Dimmer_Command") == false)
			{
				return;
			}
			#endregion

			//round brightness to percentage value
			int iBrightness = Convert.ToInt32(decimal.Round((((Convert.ToDecimal(Brightness)) / 65535) * 100), 0));
			Debug_Message("Send_Dimmer_Command", "Brightness = " + iBrightness);

			if (Supports_White_Balance == 1)
			{
				iWhite_Balance = Convert.ToInt32(decimal.Round((((Convert.ToDecimal(White_Balance)) / 65535) * 100), 0));
				Debug_Message("Send_Dimmer_Command", "White_Balance = " + iWhite_Balance);
			}

			#region Create url
			string url = "";

			if (Command <= 9)//Gen 1
			{
				url = "http://" + Device_IP + "/light/0";
			}
			else //Gen 2
			{
				url = "http://" + Device_IP + "/rpc/Light.";
			}

			//Add Command to URL
			switch (Command)
			{
				case 0:
					//turn off
					url += "?turn=off";
					break;

				case 1:
					//turn on
					url += "?turn=on";
					break;

				case 2:
					//toggle
					url += "?turn=toggle";
					break;

				case 3:
					//refresh device state
					break;

				case 4:
					//dim
					if (iBrightness > 0)
					{
						url += "?turn=on&brightness=" + iBrightness;
					}
					else
					{
						url += "?turn=off";
					}
					break;

				case 5:
					//white balance
					if (Supports_White_Balance == 1)
					{
						url += "?white=" + iWhite_Balance;
					}
					break;

				case 10:
					//turn off
					url += "Set?id=0&on=false";
					break;

				case 11:
					//turn on
					url += "Set?id=0&on=true";
					break;

				case 12:
					//toggle
					url += "Toggle?id=0";
					break;

				case 13:
					//refresh device state
					url += "GetStatus?id=0";
					break;

				case 14:
					//dim
					if (iBrightness > 0)
					{
						url += "Set?id=0&on=true&brightness=" + iBrightness;
					}
					else
					{
						url += "Set?id=0&on=false";
					}
					break;

				case 15:
					//white balance
					if (Supports_White_Balance == 1)
					{
						url += "Set?id=0&white=" + iWhite_Balance;
					}
					break;

				default:
					//unsupported command
					Debug_Message("Send_Dimmer_Command", "Error - Unsupported command - " + Command);
					return;
			}
			Debug_Message("Send_Dimmer_Command", "URL: " + url);
			#endregion

			#region Send Command
			double Brightness_FB = 0;
			double White_Balance_FB = 0;
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Send_Dimmer_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Send_Dimmer_Command", "ContentString = " + ContentString); 
					if (string.IsNullOrEmpty(ContentString) == false)
					{
						if (Device_Generation == Generation_1_Device)
						{
							s = Parse_Data_Substring(ContentString, "", "\"ison\":", ",");
						}
						else//Gen 2
						{
							s = Parse_Data_Substring(ContentString, "", "\"output\":", ",");
						}

						if (string.IsNullOrEmpty(s) == false)
						{
							Debug_Message("Send_Dimmer_Command", "ison = " + s);
							Light_Is_On = Convert.ToInt16((s == "true") ? 1 : 0);
							if (Light_Is_On == 1)//light is on true
							{
								#region Brightness
								if (Device_Generation == Generation_1_Device)
								{
									s = Parse_Data_Substring(ContentString, "", "\"brightness\":", ",");
								}
								else//Gen 2
								{
									s = Parse_Data_Substring(ContentString, "", "\"brightness\":", "}");
								}
								if (string.IsNullOrEmpty(s) == false)
								{
									Debug_Message("Send_Dimmer_Command", "brightness = " + s);
									Brightness_FB = double.Parse(s);
								}
								else
								{
									Brightness_FB = 0;
								}
								#endregion
							}
							else
							{
								Brightness_FB = 0;
							}

							#region White Balance
							if (Device_Generation == Generation_1_Device)
							{
								s = Parse_Data_Substring(ContentString, "", "\"white\":", ",");
								if (string.IsNullOrEmpty(s) == false)
								{
									Debug_Message("Send_Dimmer_Command", "white = " + s);
									White_Balance_FB = double.Parse(s);
								}
							}
							#endregion

							SignalChangeEvents.SerialValueChange(Device_IP, "", "DIMMER", 0, Light_Is_On, "", 0, "", "STATE", "", "", Convert.ToUInt16(Brightness_FB),
								256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, Convert.ToUInt16(White_Balance_FB));
						}
					}
					else
					{
						Debug_Message("Send_Dimmer_Command", "Content String is Null - Unable to Parse Device State from Content String");
						return;
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Send_Dimmer_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_RGBW_Command	-	Sends an RGBW command (on, off, etc.) to the Shelly
		// 
		//****************************************************************************************
		public void Send_RGBW_Command(string Device_IP, short Command, string Mode, short Channel, ushort Brightness_Gain, short Red, short Green, short Blue, short White, short Effect, string Username, string Password)
		{
			HttpClient client = null;

			//round brightness to percentage value
			int iBrightness_Gain = Convert.ToInt32(decimal.Round((((Convert.ToDecimal(Brightness_Gain)) * 100) / 65535), 0));

			Debug_Message("Send_RGBW_Command", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password + ", Command = " + Command + ", Level = " + iBrightness_Gain);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Send_RGBW_Command") == false)
			{
				return;
			}
			#endregion

			#region Create url
			string url = "";

			//Channel must be zero if device not controlling a multichannel white LED strip.
			if (Mode != "white")
			{
				Channel = 0;
			}

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/" + Mode + "/" + Channel.ToString();
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/" + Mode + "/" + Channel.ToString();
			}

			//Add Command to URL
			switch (Command)
			{
				case 0:
					//turn off
					url += "?turn=off";
					break;

				case 1:
					//turn on
					url += "?turn=on";
					break;

				case 2:
					//toggle
					url += "?turn=toggle";
					break;

				case 3:
					//refresh device state
					break;

				case 4:
					//rgbw
					if (Mode == "white")
					{
						url += "?turn=on&brightness=" + iBrightness_Gain;
					}
					else if (Mode == "color")
					{
						url += "?turn=on&mode=" + Mode + "&red=" + Red + "&green=" + Green + "&blue=" + Blue + "&gain=" + iBrightness_Gain + "&white=" + White + "&effect=" + Effect;
					}
					else
					{
						Debug_Message("Send_RGBW_Command", "Error - Unsupported mode - " + Mode);
					}
					break;

				default:
					//unsupported command
					Debug_Message("Send_RGBW_Command", "Error - Unsupported command - " + Command);
					return;
			}
			Debug_Message("Send_RGBW_Command", "URL: " + url);
			#endregion

			#region Send Command
			double Brightness_Gain_FB = 0;
			short Red_FB = 0;
			short Green_FB = 0;
			short Blue_FB = 0;
			short White_FB = 0;
			short Effect_FB = 0;
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Send_RGBW_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Send_RGBW_Command", "ContentString = " + ContentString);
					string s = Parse_Data_Substring(ContentString, "", "\"ison\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_RGBW_Command", "ison = " + s);

						#region Parse Is On
						short Light_Is_On = Convert.ToInt16((s == "true") ? 1 : 0);
						#endregion

						#region Parse Brightness
						s = Parse_Data_Substring(ContentString, "", "\"mode\":\"", "\",");
						if (string.IsNullOrEmpty(s) == false)
						{
							if (s == "color")
							{
								s = Parse_Data_Substring(ContentString, "", "\"gain\":", ",");
								if (string.IsNullOrEmpty(s) == false)
								{
									Brightness_Gain_FB = double.Parse(s);
								}
								else
								{
									Brightness_Gain_FB = 0;
								}
							}
							else if (s == "white")
							{
								s = Parse_Data_Substring(ContentString, "", "\"brightness\":", ",");
								if (string.IsNullOrEmpty(s) == false)
								{
									Brightness_Gain_FB = double.Parse(s);
								}
								else
								{
									Brightness_Gain_FB = 0;
								}
							}
						}
						else
						{
							Debug_Message("Send_RGBW_Command", "Parsing ContentString - modse = null");
							Brightness_Gain_FB = 0;
						}
						#endregion

						#region Parse Red
						s = Parse_Data_Substring(ContentString, "", "\"red\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							Red_FB = short.Parse(s);
						}
						else
						{
							Red_FB = 256;
						}
						#endregion

						#region Parse Green
						s = Parse_Data_Substring(ContentString, "", "\"green\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							Green_FB = short.Parse(s);
						}
						else
						{
							Green_FB = 256;
						}
						#endregion

						#region Parse Blue
						s = Parse_Data_Substring(ContentString, "", "\"blue\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							Blue_FB = short.Parse(s);
						}
						else
						{
							Blue_FB = 256;
						}
						#endregion

						#region Parse White
						s = Parse_Data_Substring(ContentString, "", "\"white\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							White_FB = short.Parse(s);
						}
						else
						{
							White_FB = 256;
						}
						#endregion

						#region Parse Effect
						s = Parse_Data_Substring(ContentString, "", "\"effect\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							Effect_FB = short.Parse(s);
						}
						else
						{
							Effect_FB = 256;
						}
						#endregion

						SignalChangeEvents.SerialValueChange(Device_IP, "", "RGBW", Channel, Light_Is_On, "", 0, "", "", "", "",
							Convert.ToUInt16(Brightness_Gain_FB), Red_FB, Green_FB, Blue_FB, White_FB, Effect_FB, "", 9999,
							"", 9999, 256, 256, 256, "", "", 9999, 9999, 101, "", "", "", 0, 0, 0);
					}
					else
					{
						Debug_Message("Send_RGBW_Command", "Error - Unable to Parse Device State from Content String");
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Send_RGBW_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_TRV_Command	-	Sends a TRV command to the Shelly device
		//							Command Format	=	http://[device_IP]/settings/thermostat/0?parameter=value
		//							Temperature_Format - 1=Fahrenheit, 2=Celsius
		//							Returns 1 if successful or 0 if not
		// 
		//****************************************************************************************
		public void Send_TRV_Command(string Device_IP, string Parameter, string Value, string Username, string Password)
		{
			string s;
			decimal d;
			short Target_Temperature = 9999;
			short Target_Temperature_Tenths = 9999;
			short Target_Temp_Enabled = 256;
			short Schedule_Enabled = 256;
			short Schedule_Profile_ID = 256;
			HttpClient client = null;

			Debug_Message("Send_TRV_Command", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password + ", Parameter = " + Parameter + ", Value = " + Value);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Send_TRV_Command") == false)
			{
				return;
			}
			#endregion

			#region Create url
			string url = "";

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/settings/thermostat/0/";
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/settings/thermostat/0/";
			}

			//Add Value to URL
			if ((String.IsNullOrEmpty(Parameter) == false) && (String.IsNullOrEmpty(Value) == false))
			{
				#region Target Temperature in Tenths to Degrees
				if (Parameter == "target_t")
				{
					try
					{
						d = decimal.Parse(Value);
						d = d / 10;
						Value = d.ToString();
					}
					catch (Exception e)
					{
						string err = "Shelly - Send_TRV_Command - Unable to Parse Target Temperature Value: " + e;
						CrestronConsole.PrintLine(err);
						Crestron.SimplSharp.ErrorLog.Error(err + "\n");
						return;
					}
				}
				#endregion
				url += "?" + Parameter + "=" + Value;
			}

			Debug_Message("Send_TRV_Command", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				client.TimeoutEnabled = true;
				client.Timeout = 30;//30 seconds
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Send_TRV_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Send_TRV_Command", "ContentString = " + ContentString);

					#region Parse Temperature Setpoint Value
					s = Parse_Data_Substring(ContentString, "", "\"value\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_TRV_Command", "target_t-value = " + s);
						try
						{
							d = decimal.Parse(s);
							Target_Temperature = Convert.ToInt16(decimal.Round(d, 0));
							Target_Temperature_Tenths = Convert.ToInt16(decimal.Round((d * 10), 0));

						}
						catch (Exception e)
						{
							Debug_Message("Send_TRV_Command", "Exception Parsing Temperature from Content String - " + ContentString);
							Debug_Message("Send_TRV_Command", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse target_t-enabled from Content String");
					}
					#endregion

					#region Parse Target Temp Enabled
					s = Parse_Data_Substring(ContentString, "", "\"enabled\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_TRV_Command", "target_t-enabled = " + s);
						Target_Temp_Enabled = Convert.ToInt16(((s == "true") || (s == " true")) ? 1 : 0);
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse target_t-enabled from Content String");
					}
					#endregion

					#region Parse Schedule Enabled
					s = Parse_Data_Substring(ContentString, "", "\"schedule\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_TRV_Command", "schedule-enabled = " + s);
						Schedule_Enabled = Convert.ToInt16(((s == "true") || (s == " true")) ? 1 : 0);
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse schedule-enabled from Content String");
					}
					#endregion

					#region Parse Schedule Profile
					s = Parse_Data_Substring(ContentString, "", "\"schedule_profile\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_TRV_Command", "schedule_profile = " + s);
						try
						{
							Schedule_Profile_ID = Int16.Parse(s);
						}
						catch (Exception e)
						{
							Debug_Message("Send_TRV_Command", "Exception Parsing schedule_profile from Content String - " + ContentString);
							Debug_Message("Send_TRV_Command", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse schedule_profile from Content String");
					}
					#endregion

					SignalChangeEvents.SerialValueChange(Device_IP, "", "TRV", 0, 256, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, Target_Temp_Enabled, Schedule_Enabled, Schedule_Profile_ID, "", "", Target_Temperature,
						Target_Temperature_Tenths, 101, "", "", "", 0, 0, 0);
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Send_TRV_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  TRV_Poll_Status		-	Poll TRV for Status
		//							Command Format	=	http://[device_IP]/thermostat/0
		//							Temperature_Format - 1=Fahrenheit, 2=Celsius
		//							Returns 1 if successful or 0 if not
		// 
		//****************************************************************************************
		public void TRV_Poll_Status(string Device_IP, string Username, string Password)
		{
			string s;
			decimal d;
			short Target_Temperature = 9999;
			short Target_Temperature_Tenths = 9999;
			short Target_Temp_Enabled = 256;
			short Schedule_Enabled = 256;
			short Schedule_Profile_ID = 256;
			string Valve_Position = "";
			short Temperature = 9999;
			short Temperature_Tenths = 9999;
			short Battery_Percentage = 101;
			HttpClient client = null;

			Debug_Message("TRV_Poll_Status", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "TRV_Poll_Status") == false)
			{
				return;
			}
			#endregion

			#region Create url
			string url = "";

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/status";
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/status";
			}

			Debug_Message("Send_TRV_Command", "URL: " + url);
			#endregion

			#region Poll
			try
			{
				//Create http client
				client = new HttpClient();
				client.TimeoutEnabled = true;
				client.Timeout = 30;//30 seconds
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - TRV_Poll_Status - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("TRV_Poll_Status", "ContentString = " + ContentString);

					#region Parse Target Temperature Setpoint Value
					s = Parse_Data_Substring(ContentString, "target_t", "\"value\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "target_t-value = " + s);
						try
						{
							d = decimal.Parse(s);
							Target_Temperature = Convert.ToInt16(decimal.Round(d, 0));
							Target_Temperature_Tenths = Convert.ToInt16(decimal.Round((d * 10), 0));

						}
						catch (Exception e)
						{
							Debug_Message("TRV_Poll_Status", "Exception Parsing Target Temperature from Content String - " + ContentString);
							Debug_Message("TRV_Poll_Status", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse Target Temperature from Content String");
					}
					#endregion

					#region Parse Target Temp Enabled
					s = Parse_Data_Substring(ContentString, "target_t", "\"enabled\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "target_t-enabled = " + s);
						Target_Temp_Enabled = Convert.ToInt16(((s == "true") || (s == " true")) ? 1 : 0);
					}
					else
					{
						Debug_Message("TRV_Poll_Status", "Error - Unable to Parse target_t-enabled from Content String");
					}
					#endregion

					#region Parse Schedule Enabled
					s = Parse_Data_Substring(ContentString, "thermostats", "\"schedule\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "schedule-enabled = " + s);
						Schedule_Enabled = Convert.ToInt16(((s == "true") || (s == " true")) ? 1 : 0);
					}
					else
					{
						Debug_Message("TRV_Poll_Status", "Error - Unable to Parse schedule-enabled from Content String");
					}
					#endregion

					#region Parse Schedule Profile
					s = Parse_Data_Substring(ContentString, "thermostats", "\"schedule_profile\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "schedule_profile = " + s);
						try
						{
							Schedule_Profile_ID = Int16.Parse(s);
						}
						catch (Exception e)
						{
							Debug_Message("TRV_Poll_Status", "Exception Parsing schedule_profile from Content String - " + ContentString);
							Debug_Message("TRV_Poll_Status", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse schedule_profile from Content String");
					}
					#endregion

					#region Parse Valve Position
					s = Parse_Data_Substring(ContentString, "thermostats", "\"pos\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "Valve Position = " + s);
						try
						{
							d = decimal.Parse(s);
							d = decimal.Round(d, 0);//assure accuracy of comparisons
							if (d == -1)//not calibrated
							{
								Valve_Position = "";
							}
							else if (d == 0)//closed
							{
								Valve_Position = "CLOSED";
							}
							else if (d > 0)//opened
							{
								Valve_Position = "OPENED";
							}
						}
						catch (Exception e)
						{
							Debug_Message("TRV_Poll_Status", "Exception Parsing Valve Postion from Content String - " + ContentString);
							Debug_Message("TRV_Poll_Status", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse Valve Position from Content String");
					}
					#endregion

					#region Parse Temperature Reading
					s = Parse_Data_Substring(ContentString, "tmp", "\"value\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "temperature reading = " + s);
						try
						{
							d = decimal.Parse(s);
							Temperature = Convert.ToInt16(decimal.Round(d, 0));
							Temperature_Tenths = Convert.ToInt16(decimal.Round((d * 10), 0));

						}
						catch (Exception e)
						{
							Debug_Message("TRV_Poll_Status", "Exception Parsing Temperature from Content String - " + ContentString);
							Debug_Message("TRV_Poll_Status", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse Temperature from Content String");
					}
					#endregion

					#region Parse Battery Percentage
					s = Parse_Data_Substring(ContentString, "bat", "\"value\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "bat-value = " + s);
						try
						{
							Battery_Percentage = Int16.Parse(s);
						}
						catch (Exception e)
						{
							Debug_Message("TRV_Poll_Status", "Exception Parsing Battery Percentage from Content String - " + ContentString);
							Debug_Message("TRV_Poll_Status", e.ToString());
						}
					}
					else
					{
						Debug_Message("TRV_Poll_Status", "Error - Unable to Parse Battery Percentage from Content String");
					}
					#endregion

					SignalChangeEvents.SerialValueChange(Device_IP, "", "TRV", 0, 256, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256,
						"", Temperature, "", Temperature_Tenths, Target_Temp_Enabled, Schedule_Enabled, Schedule_Profile_ID, "",
						Valve_Position, Target_Temperature, Target_Temperature_Tenths, Battery_Percentage, "", "", "", 0, 0, 0);
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - TRV_Poll_Status - Error Polling Status: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  TEST_Send_TRV_URL	-	Test code for TRV
		// 
		//****************************************************************************************
		public void TEST_Send_TRV_URL(string Device_IP, string URL_Extension)
		{
			HttpClient client = null;

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "TRV_Poll_Status") == false)
			{
				return;
			}
			#endregion

			#region Create url
			string url = "";
			url = "http://" + Device_IP + "/" + URL_Extension;
			Debug_Message("Send_TRV_Command", "URL: " + url);
			#endregion

			#region Test
			try
			{
				//Create http client
				client = new HttpClient();
				client.TimeoutEnabled = true;
				client.Timeout = 30;//30 seconds
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - TEST_Send_TRV_URL - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("TEST_Send_TRV_URL", "URL_Extension = " + URL_Extension);
					Debug_Message("TEST_Send_TRV_URL", "ContentString = " + ContentString);
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - TEST_Send_TRV_URL - URL_Extension = " + URL_Extension + ", Error: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Power	-	Read Power from internal meter
		// 
		//****************************************************************************************
		public short Get_Power(short Power_Meter_Type, string Device_IP, short Channel, string Username, string Password)
		{
			HttpClient client = null;

			Debug_Message("Get_Power", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password + ", Power_Meter_Type = " + Power_Meter_Type);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Get_Power") == false)
			{
				return 0;
			}
			#endregion

			#region Create url
			string url = "";

			//Create base part of url based on whether a username / password is set
			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP;
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP;
			}

			//set the remainder of the url based on the device type
			if (Power_Meter_Type == 0)
			{
				//EM Power Meter
				url += "/emeter/" + Channel + "/power";
			}
			else if (Power_Meter_Type == 1)
			{
				//No Power Meter
				return -1;
			}
			else if (Power_Meter_Type == 2)
			{
				//Shelly 2.5
				url += "/meter/" + Channel + "/power";
			}
			else if (Power_Meter_Type == 3)
			{
				//Shelly 1PM
				url += "/status/meters/" + Channel;
			}
			else if (Power_Meter_Type == 4)
			{
				//Shelly Plus RPC Call
				url += "/rpc/Switch.GetStatus?id=" + Channel;
			}
			else if (Power_Meter_Type == 5)
			{
				//Shelly PRO EM RPC Call
				url += "/rpc/Switch.GetStatus?id=" + Channel;
			}
			else if (Power_Meter_Type == 6)
			{
				//Shelly PRO 3EM RPC Call
				url += "/rpc/EM.GetStatus?id=0";
			}
			else
			{
				//Unknown Device Type
				Debug_Message("Get_Power", "Notice - Trying to retrieve power from unknown power meter type");
				return -1;
			}

			Debug_Message("Get_Power", "URL: " + url);
			#endregion

			#region Send Command to Retrieve Status
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Get_Power - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Get_Power", "ContentString = " + ContentString);
					string s = "";
					if (Power_Meter_Type <= 3)
					{
						//Gen 1 Products
						s = Parse_Data_Substring(ContentString, "", "\"power\":", ",");
					}
					else if (Power_Meter_Type == 4)
					{
						//Plus RPC
						s = Parse_Data_Substring(ContentString, "", "\"apower\":", ",");
					}
					else if (Power_Meter_Type == 5)
					{
						//PRO EM RPC
						s = Parse_Data_Substring(ContentString, "", "\"act_power\":", ",");
					}
					else if (Power_Meter_Type == 6)
					{
						//PRO 3EM RPC
						switch (Channel)
						{
							case 0:
								s = Parse_Data_Substring(ContentString, "", "\"a_act_power\":", ",");
								break;

							case 1:
								s = Parse_Data_Substring(ContentString, "", "\"b_act_power\":", ",");
								break;

							case 2:
								s = Parse_Data_Substring(ContentString, "", "\"c_active_power\":", ",");
								break;
						}
					}

					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Get_Power", "power = " + s);
						return Convert.ToInt16(decimal.Round((decimal.Parse(s)), 0));
					}
					else
					{
						Debug_Message("Get_Power", "Error - Unable to Parse Power from Content String");
						return 0;
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Get_Power - Error Reading Power: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_EM_Voltage	-	Read volage from EM devicd
		// 
		//****************************************************************************************
		public short Get_EM_Voltage(string Device_IP, short Power_Meter_Type, short Channel, string Username, string Password)
		{
			HttpClient client = null;

			Debug_Message("Get_EM_Voltage", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Get_EM_Voltage") == false)
			{
				return -1;
			}
			#endregion

			#region Create url
			string url = "";

			//Create base part of url based on whether a username / password is set
			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP;
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP;
			}

			if (Power_Meter_Type == 0)
			{
				//EM Power Meter
				url += "/emeter/" + Channel + "/power";
			}
			else if (Power_Meter_Type == 5)
			{
				//Shelly PRO EM RPC Call
				url += "/rpc/Switch.GetStatus?id=" + Channel;
			}
			else if (Power_Meter_Type == 6)
			{
				//Shelly PRO 3EM RPC Call
				url += "/rpc/EM.GetStatus?id=0";
			}
			else
			{
				//Unknown Device Type
				Debug_Message("Get_EM_Voltage", "Notice - Trying to retrieve voltage from unknown meter type");
				return -1;
			}

			Debug_Message("Get_EM_Voltage", "URL: " + url);
			#endregion

			#region Send Command to Retrieve Status
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Get_EM_Voltage - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return -1;
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Get_EM_Voltage", "ContentString = " + ContentString);
					string s = "";
					if (Power_Meter_Type <= 3)
					{
						//Gen 1 Products
						s = Parse_Data_Substring(ContentString, "", "\"voltage\":", ",");
					}
					else if (Power_Meter_Type == 5)
					{
						//PRO EM RPC
						s = Parse_Data_Substring(ContentString, "", "\"voltage\":", ",");
					}
					else if (Power_Meter_Type == 6)
					{
						//PRO 3EM RPC
						switch (Channel)
						{
							case 0:
								s = Parse_Data_Substring(ContentString, "", "\"a_voltage\":", ",");
								break;

							case 1:
								s = Parse_Data_Substring(ContentString, "", "\"b_voltage\":", ",");
								break;

							case 2:
								s = Parse_Data_Substring(ContentString, "", "\"c_voltage\":", ",");
								break;
						}
					}

					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Get_EM_Voltage", "voltage = " + s);
						return Convert.ToInt16(decimal.Round((decimal.Parse(s)), 0));
					}
					else
					{
						Debug_Message("Get_EM_Voltage", "Error - Unable to Parse Voltage from Content String");
						return -1;
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Get_EM_Voltage - Error Reading Voltage: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return -1;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Uni_Get_Temp_and_Humidity	-	Read temperature / Humidity when a DS18B20 or
		//									DHT22 is connected to a Shelly Uni
		// 
		//****************************************************************************************
		public short Uni_Get_Temp_and_Humidity(string Device_IP, string Username, string Password, short Celcius, short Tenth_of_Degrees, ref short Temperature, ref short Humidity)
		{
			string t, h;
			Decimal d;
			HttpClient client = null;

			Debug_Message("Uni_Get_Temp_and_Humidity", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password
				+ ", Celcius = " + Celcius + ", Tenth_of_Degrees = " + Tenth_of_Degrees);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Uni_Get_Temp_and_Humidity") == false)
			{
				return 0;
			}
			#endregion
			
			#region Create url
			string url = "";

			//Create base part of url based on whether a username / password is set
			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP;
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP;
			}
			url += "/status";

			Debug_Message("Uni_Get_Temp_and_Humidity", "URL: " + url);
			#endregion

			#region Send Command to Retrieve Status
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Uni_Get_Temp_and_Humidity - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Uni_Get_Temp_and_Humidity", "ContentString = " + ContentString);

					#region Parse Temperature
					if (Celcius == 0)
					{
						t = Parse_Data_Substring(ContentString, "", "\"tF\":", "}");
					}
					else
					{
						t = Parse_Data_Substring(ContentString, "", "\"tC\":", ",");
					}

					if (string.IsNullOrEmpty(t) == false)
					{
						try
						{
							d = Decimal.Parse(t);
							if (Tenth_of_Degrees == 1)
							{
								d *= 10;
							}
							Temperature = Convert.ToInt16(decimal.Round(d, 0));
						}
						catch (Exception e)
						{
							string err = "Shelly - Uni_Get_Temp_and_Humidity - Unable to Parse Temperature: " + t + ", Exception = " + e.ToString();
							CrestronConsole.PrintLine(err);
							Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							return 0;
						}
					}
					else
					{
						Debug_Message("Uni_Get_Temp_and_Humidity", "Error - Unable to Retrieve Temperature from Content String");
						return 0;
					}
					#endregion

					#region Parse Humidity
					h = Parse_Data_Substring(ContentString, "", "\"hum\":", "}");
					if (string.IsNullOrEmpty(h) == false)
					{
						try
						{
							d = Decimal.Parse(h);
							Humidity = Convert.ToInt16(decimal.Round(d, 0));
						}
						catch (Exception e)
						{
							string err = "Shelly - Uni_Get_Temp_and_Humidity - Unable to Parse Humidity: " + h + ", Exception = " + e.ToString();
							CrestronConsole.PrintLine(err);
							Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							return 0;
						}
					}
					else
					{
						Humidity = 0;
					}
					#endregion

					return 1;
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Uni_Get_Temp_and_Humidity - Error Reading temp/humidity: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Uni_Get_ADC_Voltage	-	Read of ADC Input
		// 
		//****************************************************************************************
		public short Uni_Get_ADC_Voltage(string Device_IP, string Username, string Password, ref short Voltage)
		{
			string s;
			Decimal d;
			HttpClient client = null;

			Debug_Message("Uni_Get_ADC_Voltage", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Uni_Get_ADC_Voltage") == false)
			{
				return 0;
			}
			#endregion

			#region Create url
			string url = "";

			//Create base part of url based on whether a username / password is set
			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP;
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP;
			}
			url += "/status";

			Debug_Message("Uni_Get_ADC_Voltage", "URL: " + url);
			#endregion

			#region Send Command to Retrieve Status
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Uni_Get_ADC_Voltage - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Uni_Get_ADC_Voltage", "ContentString = " + ContentString);

					#region Parse Voltage
					s = Parse_Data_Substring(ContentString, "adcs", "{\"voltage\":", "}");
					if (string.IsNullOrEmpty(s) == false)
					{
						try
						{
							d = Decimal.Parse(s);
							d *= 10;//convert to tenths
							Voltage = Convert.ToInt16(decimal.Round(d, 0));
						}
						catch (Exception e)
						{
							string err = "Shelly - Uni_Get_ADC_Voltage - Unable to Parse Voltage: " + s + ", Exception = " + e.ToString();
							CrestronConsole.PrintLine(err);
							Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							return 0;
						}
					}
					else
					{
						Debug_Message("Uni_Get_ADC_Voltage", "Error - Unable to Retrieve Voltage from Content String");
						return 0;
					}
					#endregion

					return 1;
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Uni_Get_ADC_Voltage - Error Reading Voltage: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Uni_Get_ADC_Voltage	-	Read of ADC Input
		// 
		//****************************************************************************************
		public short Get_AddOn_Sensor(string Device_IP, short Sensor_ID, short Measurement_Type, short Temperature_Format, ref short Value, ref short Value_Tenths)
		{
			double d;
			HttpClient client = null;
			//http://192.168.1.93/rpc/input.getstatus?id=100		{"id":100,"state":false}
			//http://192.168.1.93/rpc/temperature.getstatus?id=100	{"id": 100,"tC":19.6, "tF":67.3}
			//http://192.168.1.93/rpc/humidity.getstatus?id=100
			//http://192.168.1.93/rpc/analoginput.getstatus?id=100	{"id": 100,"percent":49.8}

			Debug_Message("Get_AddOn_Sensor", "Device_IP = " + Device_IP + ", Sensor_ID = " + Sensor_ID);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Get_AddOn_Sensor") == false)
			{
				return 0;
			}
			#endregion

			#region Create url
			string url = "";

			//Create base part of url based on whether a username / password is set
			url = "http://" + Device_IP + "/rpc/temperature.getstatus?id=" + Sensor_ID.ToString();
			Debug_Message("Get_AddOn_Sensor", "URL: " + url);
			#endregion

			#region Send Command to Retrieve Status
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Get_AddOn_Sensor - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}
				else
				{
					#region Parse Measurement from JSON
					string ContentString = response.ContentString;
					Debug_Message("Get_AddOn_Sensor", "ContentString = " + ContentString);

					Add_On_Status Item = Add_On_Status.Parse(ContentString);
					if (Measurement_Type == Measurement_Type_Temperature)
					{
						if (Temperature_Format == Temperature_Format_Fehrenheit)
						{
							d = Math.Round(Item.tF, 0);
							Value = Convert.ToInt16(d);
							d = Math.Round(Item.tF, 1) * 10;
							Value_Tenths = Convert.ToInt16(d);
						}
						else
						{
							d = Math.Round(Item.tC, 0);
							Value = Convert.ToInt16(d);
							d = Math.Round(Item.tC, 1) * 10;
							Value_Tenths = Convert.ToInt16(d);
						}
					}
					else if (Measurement_Type == Measurement_Type_Humidity)
					{
						d = Math.Round(Item.rh, 0);
						Value = Convert.ToInt16(d);
					}
					else if (Measurement_Type == Measurement_Type_Input)
					{
						if (Item.state == true)
						{
							Value = 1;
						}
						else
						{
							Value = 0;
						}
					}
					else if (Measurement_Type == Measurement_Type_Analog)
					{
						d = Math.Round(Item.percent, 0);
						Value = Convert.ToInt16(d);
					}
					else
					{
						Debug_Message("Get_AddOn_Sensor", "Unknown Measurement_Type = " + Measurement_Type);
						return 0;
					}
					return 1;
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Get_AddOn_Sensor - Error Reading Voltage: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Execute_Script	-	Sends an http command to trigger a script
		//						running on a shelly device
		// 
		//****************************************************************************************
		public void Execute_Script(string Device_IP, short Script_ID, string Endpoint_Name)
		{
			HttpClient client = null;

			//http://<SHELLY_IP>/script/<script_id>/<endpoint_name>

			Debug_Message("Execute_Script", "Device_IP = " + Device_IP + ", Script_ID = " + Script_ID + ", Endpoint_Name = " + Endpoint_Name);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Execute_Script") == false)
			{
				return;
			}
			#endregion

			#region Create url
			string url = "http://" + Device_IP + "/script/" + Script_ID.ToString() + "/" + Endpoint_Name;
			Debug_Message("Execute_Script", "URL: " + url);
			#endregion

			#region Send Command to Retrieve Status
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Execute_Script - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Execute_Script - Error Sending Command to Execute Script: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Mute_Smoke_Detector	-	Mute smoke detector
		//							Command Format	=	http://[device_IP]/rpc/Smoke.Mute?id=0
		// 
		//****************************************************************************************
		public void Mute_Smoke_Detector(string Device_IP)
		{
			HttpClient client = null;

			Debug_Message("Mute_Smoke_Detector", "Device_IP = " + Device_IP);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Mute_Smoke_Detector") == false)
			{
				return;
			}
			#endregion

			#region Create url
			string url = "http://" + Device_IP + "/rpc/Smoke.Mute?id=0";
			Debug_Message("Mute_Smoke_Detector", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				client.TimeoutEnabled = true;
				client.Timeout = 30;//30 seconds
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Mute_Smoke_Detector - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Mute_Smoke_Detector - Error Sending Mute Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Validate_IP_Address	-	checks if a string contains a valid IP address
		// 
		//****************************************************************************************
		private bool Validate_IP_Address(string IP_Address, string Calling_Routine)
		{
			IPAddress address;

			try
			{
				address = IPAddress.Parse(IP_Address);
			}
			catch (Exception e)
			{
				string err = "Shelly - Validate_IP_Address - Called from: " + Calling_Routine + " - Invalid IP Address: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return false;
			}
			return true;
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Shelly - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Shelly - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Shelly - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Shelly - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Shelly - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Shelly - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Shelly.Debug = Debug_Options.None;
					break;

				case 1:
					Shelly.Debug = Debug_Options.Console;
					break;

				case 2:
					Shelly.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Shelly.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		public void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Shelly - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Shelly - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}

	public class Add_On_Status
	{
		#region Declarations
		public int id { get; set; }
		public bool state { get; set; }
		public double tC { get; set; }
		public double tF { get; set; }
		public double rh { get; set; }
		public double percent { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-   Parse Add_On_Status
		// 
		//****************************************************************************************
		public static Add_On_Status Parse(string json)
		{
			CrestronConsole.PrintLine("Add_On_Status.Parse - " + json);

			try
			{
				Add_On_Status item = JsonConvert.DeserializeObject<Add_On_Status>(json);
				return item;
			}
			catch (Exception ex)
			{
				string err = "Shelly - Add_On_Status - Parsing JSON: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("Shelly - Add_On_Status - Parsing JSON - \n" + ex.StackTrace);
				return null;
			}
		}
	}

	public class Gen_1_Input_List
	{
		#region Declarations
		public List<Gen_1_Input_Info> inputList { get; set; }
		#endregion Declarations

		//****************************************************************************************
		// 
		//  Parse	-   Parse input status from gen 1 devices
		// 
		//****************************************************************************************
		public static Gen_1_Input_List Parse(string JSON)
		{
			try
			{
				return JsonConvert.DeserializeObject<Gen_1_Input_List>(JSON);
			}
			catch (Exception e)
			{
				string err = "Error Parsing JSON: " + e;
				CrestronConsole.PrintLine("Device_List - Parse", err);
				Crestron.SimplSharp.ErrorLog.Error("Device_List - Parse - " + err + "\n");
				return null;
			}
		}
	}

	public class Gen_1_Input_Info
	{
		#region Declarations
		public ushort input { get; set; }
		#endregion
	}

	public class Gen_2_Input_Info
	{
		#region Declarations
		public int id { get; set; }
		public bool state { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-   Parse Add_On_Status
		// 
		//****************************************************************************************
		public static Gen_2_Input_Info Parse(string json)
		{
			CrestronConsole.PrintLine("Gen_2_Input_Info.Parse - " + json);

			try
			{
				Gen_2_Input_Info item = JsonConvert.DeserializeObject<Gen_2_Input_Info>(json);
				return item;
			}
			catch (Exception ex)
			{
				string err = "Shelly - Gen_2_Input_Info - Parsing JSON: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("Shelly - Gen_2_Input_Info - Parsing JSON - \n" + ex.StackTrace);
				return null;
			}
		}
	}

	public class Bluetooth_Device_Info
	{
		#region Declarations
		public string DeviceId { get; set; }
		public string DeviceType { get; set; }
		public int Lux { get; set; }
		public short Rotation { get; set; }
		public short Battery { get; set; }
		public string State { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-   Parse Add_On_Status
		// 
		//****************************************************************************************
		public static Bluetooth_Device_Info Parse(string json)
		{
			CrestronConsole.PrintLine("Bluetooth_Device_Info.Parse - " + json);

			try
			{
				Bluetooth_Device_Info item = JsonConvert.DeserializeObject<Bluetooth_Device_Info>(json);
				item.DeviceId = item.DeviceId.ToUpper();
				item.State = item.State.ToUpper();
				return item;
			}
			catch (Exception ex)
			{
				string err = "Shelly - Bluetooth_Device_Info - Parsing JSON: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("Shelly - Bluetooth_Device_Info - Parsing JSON - \n" + ex.StackTrace);
				return null;
			}
		}
	}

}

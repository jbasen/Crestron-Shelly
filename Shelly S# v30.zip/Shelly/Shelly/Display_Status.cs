﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;


namespace Shelly_Integration
{
	public class Display_Status
	{

		#region Declarations
		public Ble ble { get; set; }
		public Cloud cloud { get; set; }
		public Mqtt mqtt { get; set; }

		[JsonProperty("temperature:0")]
		public Temperature0 temperature0 { get; set; }

		[JsonProperty("humidity:0")]
		public Humidity0 humidity0 { get; set; }

		[JsonProperty("illuminance:0")]
		public Illuminance0 illuminance0 { get; set; }

		[JsonProperty("switch:0")]
		public Switch0 switch0 { get; set; }

		[JsonProperty("input:0")]
		public Input0 input0 { get; set; }
		public Sys sys { get; set; }
		public Wifi wifi { get; set; }
		public bool awaiting_auth_code { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-   
		// 
		//****************************************************************************************
		public static Display_Status Parse(string JSON)
		{
			try
			{
				Display_Status Status = JsonConvert.DeserializeObject<Display_Status>(JSON);
				return Status;
			}
			catch (Exception e)
			{
				string err = "Error Parsing JSON: " + e;
				CrestronConsole.PrintLine("Shelly - Display_Status - Parse - " + err);
				Crestron.SimplSharp.ErrorLog.Error("Shelly - Display_Status - Parse - " + err + "\n");
				return null;
			}
		}
	}

	public class AvailableUpdates
	{
	}

	public class Ble
	{
	}

	public class Cloud
	{
		public bool enabled { get; set; }
		public bool connected { get; set; }
	}

	public class Humidity0
	{
		public int id { get; set; }
		public double rh { get; set; }
	}

	public class Illuminance0
	{
		public int id { get; set; }
		public int lux { get; set; }
		public string illumination { get; set; }
	}

	public class Input0
	{
		public int id { get; set; }
		public bool state { get; set; }
	}

	public class Mqtt
	{
		public bool connected { get; set; }
	}

	public class Switch0
	{
		public int id { get; set; }
		public bool output { get; set; }
		public string source { get; set; }
	}

	public class Sys
	{
		public string id { get; set; }
		public string mac { get; set; }
		public string model { get; set; }
		public int gen { get; set; }
		public string fw_id { get; set; }
		public string ver { get; set; }
		public string app { get; set; }
		public bool auth_en { get; set; }
		public int uptime { get; set; }
		public bool discoverable { get; set; }
		public int cfg_rev { get; set; }
		public int schedule_rev { get; set; }
		public int webhook_rev { get; set; }
		public AvailableUpdates available_updates { get; set; }
	}

	public class Temperature0
	{
		public int id { get; set; }
		public double tC { get; set; }
		public double tF { get; set; }
	}

	public class Wifi
	{
		public string sta_ip { get; set; }
		public string status { get; set; }
		public string mac { get; set; }
		public string ssid { get; set; }
		public int rssi { get; set; }
		public string netmask { get; set; }
		public string gw { get; set; }
		public string nameserver { get; set; }
	}

}
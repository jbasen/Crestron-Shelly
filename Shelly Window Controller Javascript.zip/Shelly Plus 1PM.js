let MAX_POWER = 6.1;
let Power_Monitor_Timer;
let Send_Only_Once_Flag = false;
let Shelly_Plus_2PM_IP_Address = '192.168.1.84';
let Crestron_IP_Address = '192.168.1.3';
let Crestron_Port = '9000';

//****************************************************************************************
// 
//  Get_Status_Callback  -  Callback from getStatus call with current
//                          device status
// 
//****************************************************************************************
function Get_Status_Callback(result, error_code, error_message, userdata)
{
  if (result.apower > MAX_POWER)
  {
    print("Max APower reached. Power =", result.apower);
    
    if (Send_Only_Once_Flag === false)    //check if the off command was already sent
    {
      Send_Only_Once_Flag = true;        //set flag to keep from sending multiple commands
   
      //Send command to stop window movement
      Shelly.call("HTTP.GET", {'url': 'http://Shelly_Plus_2PM_IP_Address/script/1/stop'}, null);
      
      //Notify Crestron System
      Shelly.call("HTTP.GET", {'url': 'http://Crestron_IP_Address:9000/window/state/jam/'}, null);
    }
  }
  else
  {
    Send_Only_Once_Flag = false;          //clear flag now that power has dropped
  }
}

//****************************************************************************************
// 
//  Get_Status_Callback  -  Callback when timer expires
// 
//****************************************************************************************
function Timer_Callback()
{
  Shelly.call("switch.getStatus", { id: 0 }, Get_Status_Callback, null);
}

//****************************************************************************************
// 
//  Start_Power_Monitor-  Starts repetitive timer to monitor power
// 
//****************************************************************************************
function Start_Power_Monitor()
{
  Power_Monitor_Timer = Timer.set(100, true, Timer_Callback, null);//repeating .1 second timer
}

Start_Power_Monitor();
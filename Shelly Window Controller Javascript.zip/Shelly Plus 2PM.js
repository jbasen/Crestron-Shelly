let Movement_Timer = null;
let Movement_Time;

//****************************************************************************************
// 
//  Init-	Initialize operation
// 
//****************************************************************************************
function Init(request, response)
{
  print("Executing Function init");
  
  //Parse parameter
  let i = request.query.indexOf('=');
  let parameter = request.query.slice(i+1);
  
  //Convert to numeric
  let num = 0;
  for (i = 0; i < parameter.length; i++)
  {
    num = (num * 10) + (parameter.at(i) - 48);
  }
  Movement_Time = num;
  Movement_Time = Movement_Time * 1000;  //Convert from seconds to msec
  print ('Movement_Time', Movement_Time );
  
  //Send response OK back to Crestron System
  response.code = 200;
  response.send();
}

//****************************************************************************************
// 
//  Stop    -	Turn off both outputs to stop window movement
// 
//****************************************************************************************
function Stop(request, response)
{
  print("Executing Function stop");
  Shelly.call("Switch.set", {"id": 0, "on": false}, null);
  Shelly.call("Switch.set", {"id": 1, "on": false}, null);
  
  //Stop the movement timer if it was running
  Stop_Movement_Timer();
  
  //Send response OK back to Crestron System
  response.code = 200;
  response.send();
}

//****************************************************************************************
// 
//  Open    -	Turn on O1 to open window
// 
//****************************************************************************************
function Open(request, response)
{
  print("Executing Function open");

  //Make sure both outputs are off
  Shelly.call("Switch.set", {"id": 0, "on": false}, null);
  Shelly.call("Switch.set", {"id": 1, "on": false}, null);
  
  //Stop the movement timer if it was running
  Stop_Movement_Timer();

  //Turn on Output to open the window
  Shelly.call("Switch.set", {"id": 0, "on": true}, null);
  
  //Start Movement Timer to turn off outputs and trigger
  //status update to Crestron system when linear actuator
  //hits limit switch
  Start_Movement_Timer();

  //Send response OK back to Crestron System
  response.code = 200;
  response.send();
}

//****************************************************************************************
// 
//  Close    -	Turn on O2 to close window
// 
//****************************************************************************************
function Close(request, response)
{
  print("Executing Function close");

  //Make sure both outputs are off
  Shelly.call("Switch.set", {"id": 0, "on": false}, null);
  Shelly.call("Switch.set", {"id": 1, "on": false}, null);

  //Stop the movement timer if it was running
  Stop_Movement_Timer();

   //Turn on Output to close the window
   Shelly.call("Switch.set", {"id": 1, "on": true}, null);

  //Start Movement Timer to turn off outputs and trigger
  //status update to Crestron system when linear actuator
  //hits limit switch
  Start_Movement_Timer();

  //Send response OK back to Crestron System
  response.code = 200;
  response.send();
}


//****************************************************************************************
// 
//  Movement_Timer_Callback  -	Callback function when timer expires
// 
//****************************************************************************************
function Movement_Timer_Callback()
{
  //Turn off both outputs to send stop feedback
  //through webhooks to Crestron system
  Shelly.call("Switch.set", {"id": 0, "on": false}, null);
  Shelly.call("Switch.set", {"id": 1, "on": false}, null);
  Movement_Timer = null;
}

//****************************************************************************************
// 
//  Stop_Movement_Timer    -	Stop timer used to force status back to
//                              Crestron system when linear actuatoris
//                              moving and hits limit switch
// 
//****************************************************************************************
function Stop_Movement_Timer()
{
  if (Movement_Timer !== null)
  {
    Timer.clear(Movement_Timer);
    Movement_Timer = null;
  }
}

//****************************************************************************************
// 
//  Start_Movement_Timer    -	Start time that will expire after window
//                              opens or closes amd linear actuator has
//                              stopped by hitting limit switch
// 
//****************************************************************************************
function Start_Movement_Timer()
{
  Movement_Timer = Timer.set(Movement_Time , false, Movement_Timer_Callback, null);
}


//Initiate Servers
HTTPServer.registerEndpoint("init", Init);
HTTPServer.registerEndpoint("stop", Stop);
HTTPServer.registerEndpoint("open", Open);
HTTPServer.registerEndpoint("close", Close);
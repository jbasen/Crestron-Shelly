﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Http;

namespace Shelly_Integration
{
	#region Classes
	//Event Classes
	public class SerialChangeEventArgs : EventArgs
	{
		public string Device_IP { get; set; }
		public short Channel { get; set; }
		public short Relay_Is_On { get; set; }
		public string Roller_State { get; set; }
		public short Position { get; set; }
		public string Power_Under_or_Over { get; set; }
		public string Action { get; set; }
		public string Button { get; set; }
		public string Output { get; set; }
		public ushort Brightness_Gain { get; set; }
		public short Red { get; set; }
		public short Green { get; set; }
		public short Blue { get; set; }
		public short White { get; set; }
		public short Effect { get; set; }
		public string Lux { get; set; }
		public string Humidity { get; set; }
		public short Temperature { get; set; }
		public short Temperature_Tenths { get; set; }
		public short Target_Temperature_Enabled { get; set; }
		public short Target_Temperature { get; set; }
		public short Target_Temperature_Tenths { get; set; }
		public short Schedule_Enabled { get; set; }
		public short Schedule_Profile_ID { get; set; }
		public string Schedule_Profile_Name { get; set; }
		public string Valve_Position { get; set; }
		public short Battery_Percentage { get; set; }

		public SerialChangeEventArgs()
		{
		}

		public SerialChangeEventArgs(string Device_IP, short Channel, short Relay_Is_On, string Roller_State, 
			short Position, string Power_Under_or_Over, string Action, string Button, string Output, 
			ushort Brightness_Gain, short Red, short Green, short Blue, short White, short Effect,
			string Lux, short Temperature, string Humidity, short Temperature_Tenths, short Target_Temperature_Enabled,
			short Schedule_Enabled, short Schedule_Profile_ID, string Schedule_Profile_Name, string Valve_Position,
			short Target_Temperature, short Target_Temperature_Tenths, short Battery_Percentage)
		{
			#region Set Class Data Elements from Parameters
			this.Device_IP = Device_IP;
			this.Channel = Channel;
			this.Relay_Is_On = Relay_Is_On;
			this.Roller_State = Roller_State;
			this.Position = Position;
			this.Power_Under_or_Over = Power_Under_or_Over;
			this.Action = Action;
			this.Button = Button;
			this.Output = Output;
			this.Brightness_Gain = Brightness_Gain;
			this.Red = Red;
			this.Green = Green;
			this.Blue = Blue;
			this.White = White;
			this.Effect = Effect;
			this.Lux = Lux;
			this.Temperature = Temperature;
			this.Humidity = Humidity;
			this.Temperature_Tenths = Temperature_Tenths;
			this.Target_Temperature_Enabled = Target_Temperature_Enabled;
			this.Target_Temperature = Target_Temperature;
			this.Target_Temperature_Tenths = Target_Temperature_Tenths;
			this.Schedule_Enabled = Schedule_Enabled;
			this.Schedule_Profile_ID = Schedule_Profile_ID;
			this.Schedule_Profile_Name = Schedule_Profile_Name;
			this.Valve_Position = Valve_Position;
			this.Battery_Percentage = Battery_Percentage;
			#endregion
		}
	}

	public static class SignalChangeEvents
	{
		public static event SerialChangedEventHandler onSerialValueChange;

		public static void SerialValueChange(string Device_IP, short Channel, short Relay_Is_On, string Roller_State, short Position,
			string Power_Under_or_Over, string Action, string Button, string Output, ushort Brightness_Gain, short Red,
			short Green, short Blue, short White, short Effect, string Lux, short Temperature, string Humidity, short Temperature_Tenths,
			short Target_Temperature_Enabled, short Schedule_Enabled, short Schedule_Profile_ID, string Schedule_Profile_Name, string Valve_Position,
			short Target_Temperature, short Target_Temperature_Tenths, short Battery_Percentage)
		{
			SignalChangeEvents.onSerialValueChange(new SerialChangeEventArgs(Device_IP, Channel, Relay_Is_On, 
				Roller_State, Position, Power_Under_or_Over, Action, Button, Output, Brightness_Gain,
				Red, Green, Blue, White, Effect, Lux, Temperature, Humidity, Temperature_Tenths, Target_Temperature_Enabled,
				Schedule_Enabled, Schedule_Profile_ID, Schedule_Profile_Name, Valve_Position, Target_Temperature, Target_Temperature_Tenths, Battery_Percentage));
		}
	}
	#endregion

	#region Delegates
	public delegate void SerialChangedEventHandler(SerialChangeEventArgs e);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Shelly
	{
		#region Declarations
		private static HttpServer Server;
		private static bool Server_Running = false;
		private static Debug_Options Debug;
		private static string Processor_IP;
		private static string Processor_Port;
		#endregion

		//****************************************************************************************
		// 
		//  Shelly	-	Default Constructor
		// 
		//****************************************************************************************
		public Shelly()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public short Initialize(string Processor_IP, string Processor_Port, short Debug)
		{
			#region Save Parameters
			Shelly.Processor_IP = Processor_IP;
			Shelly.Processor_Port = Processor_Port;
			#endregion

			Set_Debug_Message_Output(Debug);

			#region Create Server for capturing responses from Shelly Devices
			if (Server_Running == false)                                        //don't create server if already running
			{
				if (Create_Server(Processor_IP, Processor_Port) == false)
				{
					Debug_Message("Initialize", "Create Server Failed");
					return 0;
				}
			}
			#endregion

			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Create_Server	-	Setup http server to receive status messages from shelly devices
		// 
		//****************************************************************************************
		private bool Create_Server(string Processor_IP, string Processor_Port)
		{
			try
			{
				//Create a new instance of a server
				Server = new HttpServer();
				//Set the server's IP address
				Server.ServerName = Processor_IP;
				//Set the server's port
				Server.Port = int.Parse(Processor_Port);
				//Assign an event handling method to the server
				Server.OnHttpRequest += new OnHttpRequestHandler(HTTPRequestEventHandler);
				Server.Active = true;
				//save that server is running so initialization can possibly be run again to get device status
				Server_Running = true;
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Shelly - Create_Server - Can't create http server: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Shelly - Create_Server - Can't create http server: " + e + "\n");
				Server.Active = false;
				return false;
			}

			return true;
		}

		//****************************************************************************************
		// 
		//  HTTPRequestEventHandler	-	Handler to receive messages sent from Shelly Devices 
		// 
		//****************************************************************************************
		private void HTTPRequestEventHandler(Object sender, OnHttpRequestArgs requestArgs)
		{
			short Channel;
			string State;
			string Input;
			string Power_Under_or_Over;
			string s = "";
			string Lux = "";
			string Temp = "";
			string Humidity = "";
			short Temperature = 9999;
			short Temperature_Tenths = 9999;
			double d;


			//Get IP Address of Shelly device that sent message
			string Device_IP = requestArgs.Connection.RemoteEndPointAddress;
			Debug_Message("HTTPRequestEventHandler", "Device_IP = " + Device_IP);

			//Get Path of Request
			string Path = requestArgs.Request.Path;
			Debug_Message("HTTPRequestEventHandler", "Path = " + Path);

			#region Parse Data Elements from Path
			Path = Path.ToUpper();
			
			#region Is this update from a relay?
			s = Parse_Data_Substring(Path, "", "/RELAY/", "/");
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Convert Channel string to short
				try
				{
					Channel = Int16.Parse(s);
				}
				catch (Exception e)
				{
					Debug_Message("HTTPRequestEventHandler", "Exception Parsing Relay from Path - " + Path);
					Debug_Message("HTTPRequestEventHandler", e.ToString());
					return;
				}
				#endregion

				#region Parse State from Path
				State = Parse_Data_Substring(Path, "", "/STATE/", "/");
				Input = Parse_Data_Substring(Path, "", "/INPUT/", "/");
				if ((String.IsNullOrEmpty(State) == true) && (String.IsNullOrEmpty(Input) == true))
				{
					Debug_Message("HTTPRequestEventHandler", "Path Does Not Contain Relay or Input State - " + Path);
					return;
				}
				#endregion

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Relay - Device_IP = " + Device_IP + ", Channel = " + Channel + ", State = " + State + ", Input = " + Input);
				if (State == "ON")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, Channel, 1, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				}
				else if (State == "OFF")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, Channel, 0, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				}
				else if ((Input == "OFF") || (Input == "ON") || (Input == "PUSH") || (Input == "LONGPUSH") || (Input == "DOUBLEPUSH"))
				{
					SignalChangeEvents.SerialValueChange(Device_IP, Channel, 2, "", 0, "", Input, "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				}
				else
				{
					Debug_Message("HTTPRequestEventHandler", "Unknown State/Input In Path - " + Path);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from an EM?
			s = Parse_Data_Substring(Path, "", "/EM/", "/");
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Convert Channel string to short
				try
				{
					Channel = Int16.Parse(s);
				}
				catch (Exception e)
				{
					Debug_Message("HTTPRequestEventHandler", "Exception Parsing Roller from Path - " + Path);
					Debug_Message("HTTPRequestEventHandler", e.ToString());
					return;
				}
				#endregion

				#region Parse Power under or over from Path
				Power_Under_or_Over = Parse_Data_Substring(Path, "", "/POWER/", "/");
				if (String.IsNullOrEmpty(Power_Under_or_Over) == true)
				{
					Debug_Message("HTTPRequestEventHandler", "Path Does Not Contain EM power under/over - " + Path);
					return;
				}
				#endregion

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "EM - Device_IP = " + Device_IP + ", Channel = " + Channel + ", Power_Under_or_Over = " + Power_Under_or_Over);
				SignalChangeEvents.SerialValueChange(Device_IP, Channel, 0, "", 0, Power_Under_or_Over, "", "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				#endregion
				return;
			}
			#endregion

			#region Is this update from a roller?
			s = Parse_Data_Substring(Path, "", "/ROLLER/", "/");
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Convert Channel string to short
				try
				{
					Channel = Int16.Parse(s);
				}
				catch (Exception e)
				{
					Debug_Message("HTTPRequestEventHandler", "Exception Parsing Roller from Path - " + Path);
					Debug_Message("HTTPRequestEventHandler", e.ToString());
					return;
				}
				#endregion

				#region Parse Roller State from Path
				State = Parse_Data_Substring(Path, "", "/STATE/", "/");
				if (String.IsNullOrEmpty(State) == true)
				{
					Debug_Message("HTTPRequestEventHandler", "Path Does Not Contain Roller State - " + Path);
					return;
				}
				#endregion

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Roller - Device_IP = " + Device_IP + ", Channel = " + Channel + ", State = " + State);
				SignalChangeEvents.SerialValueChange(Device_IP, Channel, 0, State, 101, "", "", "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				#endregion
				return;
			}
			#endregion

			#region Is this update from a Motion Sensor
			s = Parse_Data_Substring(Path, "", "/MOTION/", "/");
			// - actions = detected, detected_in_dark, detected_in_twilight, detected_in_bright, end_of_motion, tamper, end_of_tamper
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Motion - Device_IP = " + Device_IP + ", Action = " + s);
				SignalChangeEvents.SerialValueChange(Device_IP, 0, 0, "", 0, "", s, "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				#endregion
				return;
			}
			#endregion

			#region Is this update from an Uni
			s = Parse_Data_Substring(Path, "", "/UNI/", "/");
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Convert Channel string to short
				try
				{
					Channel = Int16.Parse(s);
				}
				catch (Exception e)
				{
					Debug_Message("HTTPRequestEventHandler", "Exception Parsing UNI from Path - " + Path);
					Debug_Message("HTTPRequestEventHandler", e.ToString());
					return;
				}

				#endregion

				#region Button Update
				s = Parse_Data_Substring(Path, "", "/BUTTON/", "/");
				if (String.IsNullOrEmpty(s) == false)
				{
					#region Send Device Status
					Debug_Message("HTTPRequestEventHandler", "Uni - Device_IP = " + Device_IP + ", Channel = " + Channel + ", Button = " + s);
					SignalChangeEvents.SerialValueChange(Device_IP, Channel, 0, "", 0, "", "", s, "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
					#endregion
					return;
				}
				#endregion

				#region Output Update
				s = Parse_Data_Substring(Path, "", "/OUTPUT/", "/");
				if (String.IsNullOrEmpty(s) == false)
				{
					#region Send Device Status
					Debug_Message("HTTPRequestEventHandler", "Uni - Device_IP = " + Device_IP + ", Channel = " + Channel + ", Output = " + s);
					SignalChangeEvents.SerialValueChange(Device_IP, Channel, 0, "", 0, "", "", "", s, 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
					#endregion
					return;
				}
				#endregion
			}
			#endregion

			#region Is this update from an i3 or i4
			s = Parse_Data_Substring(Path, "", "/I3/", "/");
			if (String.IsNullOrEmpty(s) == true)
			{
				s = Parse_Data_Substring(Path, "", "/I4/", "/");
			}
			if (String.IsNullOrEmpty(s) == false)
			{
				#region Convert Channel string to short
				try
				{
					Channel = Int16.Parse(s);
				}
				catch (Exception e)
				{
					Debug_Message("HTTPRequestEventHandler", "Exception Parsing i3-i4 from Path - " + Path);
					Debug_Message("HTTPRequestEventHandler", e.ToString());
					return;
				}

				#endregion

				#region Button Update
				s = Parse_Data_Substring(Path, "", "/BUTTON/", "/");
				if (String.IsNullOrEmpty(s) == false)
				{
					#region Send Device Status
					Debug_Message("HTTPRequestEventHandler", "i3-i4 - Device_IP = " + Device_IP + ", Channel = " + Channel + ", Button = " + s);
					SignalChangeEvents.SerialValueChange(Device_IP, Channel, 0, "", 0, "", "", s, "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
					#endregion
					return;
				}
				#endregion
			}
			#endregion

			#region Is this update from a dimmer?
			State = Parse_Data_Substring(Path, "", "/DIMMER/STATE/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Get State
				if (String.IsNullOrEmpty(State) == true)
				{
					Debug_Message("HTTPRequestEventHandler", "Path Does Not Contain Dimmer State - " + Path);
					return;
				}
				#endregion

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Dimmer - Device_IP = " + Device_IP + ", State = " + State);
				if (State == "ON")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, 0, 1, "", 0, "", "", "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				}
				else if (State == "OFF")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, 0, 0, "", 0, "", "", "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				}
				else
				{
					Debug_Message("HTTPRequestEventHandler", "Unknown State In Path - " + Path);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from a RGBW?
			State = Parse_Data_Substring(Path, "", "/RGBW/STATE/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Get State
				if (String.IsNullOrEmpty(State) == true)
				{
					Debug_Message("HTTPRequestEventHandler", "Path Does Not Contain Dimmer State - " + Path);
					return;
				}
				#endregion

				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "RGBW - Device_IP = " + Device_IP + ", State = " + State);
				if (State == "ON")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, 0, 1, "", 0, "", "", "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				}
				else if (State == "OFF")
				{
					SignalChangeEvents.SerialValueChange(Device_IP, 0, 0, "", 0, "", "", "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				}
				else
				{
					Debug_Message("HTTPRequestEventHandler", "Unknown State In Path - " + Path);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from a button?
			State = Parse_Data_Substring(Path, "", "/BUTTON/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Button - Device_IP = " + Device_IP + ", State = " + State);
				SignalChangeEvents.SerialValueChange(Device_IP, 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				#endregion
				return;
			}
			#endregion

			#region Is this update from a door-window 2?
			State = Parse_Data_Substring(Path, "", "/DW2/", "/");
			if (String.IsNullOrEmpty(State) == false)//for Sensor url action
			{
				//Set to values for invalid reading	
				Temperature = 9999;
				Temperature_Tenths = 9999;

				//Get Query Strings of Request
				QueryString query = requestArgs.Request.QueryString;

				#region Parse Lux
				Lux = query["lux"];
				if (String.IsNullOrEmpty(Lux) == true)
				{
					Lux = "";
				}
				Debug_Message("HTTPRequestEventHandler", "lux = " + Lux);
				#endregion

				#region Parse Temp
				Temp = query["temp"];
				if (String.IsNullOrEmpty(Temp) == false)
				{
					try
					{
						d = Double.Parse(Temp);
						Temperature = Convert.ToInt16(Math.Round(d, 0));
						Temperature_Tenths = Convert.ToInt16(Math.Round((d * 10), 0));
						Debug_Message("HTTPRequestEventHandler", "Temperature = " + Temperature);
						Debug_Message("HTTPRequestEventHandler", "Temperature_Tenths = " + Temperature_Tenths);
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Temperature from Temp String - " + Temp);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				#endregion

				#region Send Device Status
				if ((String.IsNullOrEmpty(State) == false) || (String.IsNullOrEmpty(Lux) == false) || (String.IsNullOrEmpty(Temp) == false))
				{
					Debug_Message("HTTPRequestEventHandler", "Door-Window 2 - Device_IP = " + Device_IP + ", State = " + State);
					SignalChangeEvents.SerialValueChange(Device_IP, 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256,
						Lux, Temperature, "", Temperature_Tenths, 256, 256, 256, "", "", 9999, 9999, 101);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from a humidity-temperature sensor?
			State = Parse_Data_Substring(Path, "", "/HT/", "/");
			if (String.IsNullOrEmpty(State) == false)//for Sensor url action
			{
				//Set to values for invalid reading	
				Temperature = 9999;
				Temperature_Tenths = 9999;

				//Get Query Strings of Request
				QueryString query = requestArgs.Request.QueryString;

				#region Parse Humidity
				Humidity = query["hum"];
				if (String.IsNullOrEmpty(Humidity) == true)
				{
					Humidity = "";
				}
				Debug_Message("HTTPRequestEventHandler", "humidity = " + Humidity);
				#endregion

				#region Parse Temperature
				Temp = query["temp"];
				if (String.IsNullOrEmpty(Temp) == false)
				{
					try
					{
						d = Double.Parse(Temp);
						Temperature = Convert.ToInt16(Math.Round(d, 0));
						Temperature_Tenths = Convert.ToInt16(Math.Round((d * 10), 0));
						Debug_Message("HTTPRequestEventHandler", "Temperature = " + Temperature);
						Debug_Message("HTTPRequestEventHandler", "Temperature_Tenths = " + Temperature_Tenths);
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Temperature from Temp String - " + Temp);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				#endregion

				#region Send Device Status
				if ((String.IsNullOrEmpty(State) == false) || (String.IsNullOrEmpty(Humidity) == false) || (String.IsNullOrEmpty(Temp) == false))
				{
					Debug_Message("HTTPRequestEventHandler", "Humidity-Temperature Sensor - Device_IP = " + Device_IP + ", State = " + State);
					SignalChangeEvents.SerialValueChange(Device_IP, 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256, "",
						Temperature, Humidity, Temperature_Tenths, 256, 256, 256, "", "", 9999, 9999, 101);
				}
				#endregion
				return;
			}
			#endregion

			#region Is this update from a flood sensor?
			State = Parse_Data_Substring(Path, "", "/FLOOD/", "/");
			if (String.IsNullOrEmpty(State) == false)//for Sensor url action
			{
				//Set to values for invalid reading	
				Temperature = 9999;
				Temperature_Tenths = 9999;

				//Get Query Strings of Request
				QueryString query = requestArgs.Request.QueryString;

				#region Parse Temperature
				Temp = query["temp"];
				if (String.IsNullOrEmpty(Temp) == false)
				{
					try
					{
						d = Double.Parse(Temp);
						Temperature = Convert.ToInt16(Math.Round(d, 0));
						Temperature_Tenths = Convert.ToInt16(Math.Round((d * 10), 0));
						Debug_Message("HTTPRequestEventHandler", "Temperature = " + Temperature);
						Debug_Message("HTTPRequestEventHandler", "Temperature_Tenths = " + Temperature_Tenths);
					}
					catch (Exception e)
					{
						Debug_Message("HTTPRequestEventHandler", "Exception Parsing Temperature from Temp String - " + Temp);
						Debug_Message("HTTPRequestEventHandler", e.ToString());
						return;
					}
				}
				#endregion

				#region Send Device Status
				if ((String.IsNullOrEmpty(State) == false) || (String.IsNullOrEmpty(Temp) == false))
				{
					Debug_Message("HTTPRequestEventHandler", "Flood Sensor - Device_IP = " + Device_IP + ", State = " + State);
					SignalChangeEvents.SerialValueChange(Device_IP, 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256, "",
						Temperature, "", Temperature_Tenths, 256, 256, 256, "", "", 9999, 9999, 101);
				}
				#endregion
				return;
			}

			#endregion

			#region Is this update from a gas sensor?
			State = Parse_Data_Substring(Path, "", "/GAS/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "Gas Sensor - Device_IP = " + Device_IP + ", State = " + State);
				SignalChangeEvents.SerialValueChange(Device_IP, 0, 0, "", 0, "", "", State, "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				#endregion
				return;
			}
			#endregion

			#region Is this update from a TRV?
			State = Parse_Data_Substring(Path, "", "/TRV/STATE/", "/");
			if (String.IsNullOrEmpty(State) == false)
			{
				#region Send Device Status
				Debug_Message("HTTPRequestEventHandler", "TRV - Device_IP = " + Device_IP + ", State = " + State);
				SignalChangeEvents.SerialValueChange(Device_IP, 0, 0, "", 0, "", "", "", "", 101, 256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", State, 9999, 9999, 101);
				#endregion
				return;
			}
			#endregion

			Debug_Message("HTTPRequestEventHandler", "Unknown Device Type in Path = " + Path);
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_Device_Command	-	Sends a relay command (on, off, etc.) to the Shelly
		//							Command Format	=	http://[device_IP]/relay/[channel]?command
		//												http://user:pass@[device_IP]/relay/[channel]?command
		//												command format - turn=on, turn=off, turn=toggle
		// 
		//****************************************************************************************
		public void Send_Relay_Command(string Device_IP, short Channel, short Command, string Username, string Password)
		{

			Debug_Message("Send_Relay_Command", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password + ", Command = " + Command);

			#region Create url
			string url = "";

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/relay/" + Channel;
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/relay/" + Channel;
			}
			
			//Add Command to URL
			switch (Command)
			{
				case 0:
					//turn off
					url += "?turn=off";
					break;

				case 1:
					//turn on
					url += "?turn=on";
					break;

				case 2:
					//toggle
					url += "?turn=toggle";
					break;

				case 3:
					//refresh device state
					break;

				default:
					//unsupported command
					Debug_Message("Send_Relay_Command", "Error - Unsupported command - " + Command);
					return;
			}

			Debug_Message("Send_Relay_Command", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Send_Relay_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Send_Relay_Command", "ContentString = " + ContentString);
					string s = Parse_Data_Substring(ContentString, "", "\"ison\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_Relay_Command", "ison = " + s);
						short Relay_Is_On = Convert.ToInt16(((s == "true") || (s == " true")) ? 1 : 0);
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Relay_Is_On, "", 0, "", "STATE", "", "", 101,
							256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
					}
					else
					{
						Debug_Message("Send_Relay_Command", "Error - Unable to Parse Device State from Content String");
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Send_Relay_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_Roller_Command	-	Sends a command to a Shelly 2.5 connected to a roller shade
		//							or similar motorized device.
		//							Command Format	=	http://[device_IP]/roller/0/?command
		//												http://user:pass@[device_IP]/roller/0/?command
		//												command format - go=open, go=close, go=stop
		// 
		//****************************************************************************************
		public void Send_Roller_Command(string Device_IP, short Command, string Username, string Password)
		{
			string State;
			short Current_Position;

			Debug_Message("Send_Roller_Command", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password + ", Command = " + Command);

			#region Create url
			string url = "";

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/roller/0/";
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/roller/0/";
			}

			//Add Command to URL
			switch (Command)
			{
				case 0:
					//open
					url += "?go=open";
					break;

				case 1:
					//close
					url += "?go=close";
					break;

				case 2:
					//stop
					url += "?go=stop";
					break;

				case 3:
					//refresh device state
					break;

				default:
					//unsupported command
					Debug_Message("Send_Roller_Command", "Error - Unsupported command - " + Command);
					return;
			}

			Debug_Message("Send_Roller_Command", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Send_Roller_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Send_Roller_Command", "ContentString = " + ContentString);
					#region Parse State
					State = Parse_Data_Substring(ContentString, "", "\"state\":\"", "\",");
					if (string.IsNullOrEmpty(State) == true)
					{
						Debug_Message("Send_Roller_Command", "Error - Unable to Parse Device State from Content String");
						return;
					}
					#endregion

					#region Parse Current Position
					string s = Parse_Data_Substring(ContentString, "", "\"current_pos\":", ",");
					if (string.IsNullOrEmpty(s) == true)
					{
						Debug_Message("Send_Roller_Command", "Error - Unable to Parse Device State from Content String");
						return;
					}
					else
					{
						Current_Position = Int16.Parse(s);
					}
					#endregion

					Debug_Message("Send_Roller_Command", "State = " + State + ", Current_Position = " + Current_Position);
					SignalChangeEvents.SerialValueChange(Device_IP, 0, 0, State, Current_Position, "", "", "", "", 101,
						256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Send_Roller_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_Dimmer_Command	-	Sends a dimmer command (on, off, etc.) to the Shelly
		// 
		//****************************************************************************************
		public void Send_Dimmer_Command(string Device_IP, short Command, ushort Brightness, string Username, string Password)
		{
			//round brightness to percentage value
			int iBrightness = Convert.ToInt32(decimal.Round((((Convert.ToDecimal(Brightness)) * 100) / 65535), 0));

			Debug_Message("Send_Dimmer_Command", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password + ", Command = " + Command + ", Level = " + iBrightness);

			#region Create url
			string url = "";

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/light/0";
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/light/0";
			}

			//Add Command to URL
			switch (Command)
			{
				case 0:
					//turn off
					url += "?turn=off";
					break;

				case 1:
					//turn on
					url += "?turn=on";
					break;

				case 2:
					//toggle
					url += "?turn=toggle";
					break;

				case 3:
					//refresh device state
					break;

				case 4:
					//dim
					if (iBrightness > 0)
					{
						url += "?turn=on&brightness=" + iBrightness;
					}
					else
					{
						url += "?turn=off";
					}
					break;

				default:
					//unsupported command
					Debug_Message("Send_Dimmer_Command", "Error - Unsupported command - " + Command);
					return;
			}
			Debug_Message("Send_Dimmer_Command", "URL: " + url);
			#endregion

			#region Send Command
			double Brightness_FB = 0;
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Send_Dimmer_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Send_Dimmer_Command", "ContentString = " + ContentString);
					string s = Parse_Data_Substring(ContentString, "", "\"ison\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_Dimmer_Command", "ison = " + s);
						short Light_Is_On = Convert.ToInt16((s == "true") ? 1 : 0);
						if (Light_Is_On == 1)//light is on true
						{
							s = Parse_Data_Substring(ContentString, "", "\"brightness\":", ",");
							if (string.IsNullOrEmpty(s) == false)
							{
								Debug_Message("Send_Dimmer_Command", "brightness = " + s);
								Brightness_FB = double.Parse(s);
							}
							else
							{
								Brightness_FB = 0;
							}
						}
						else
						{
							Brightness_FB = 0;
						}
						SignalChangeEvents.SerialValueChange(Device_IP, 0, Light_Is_On, "", 0, "", "", "", "", Convert.ToUInt16(Brightness_FB),
							256, 256, 256, 256, 256, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
					}
					else
					{
						Debug_Message("Send_Dimmer_Command", "Error - Unable to Parse Device State from Content String");
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Send_Dimmer_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_RGBW_Command	-	Sends an RGBW command (on, off, etc.) to the Shelly
		// 
		//****************************************************************************************
		public void Send_RGBW_Command(string Device_IP, short Command, string Mode, short Channel, ushort Brightness_Gain, short Red, short Green, short Blue, short White, short Effect, string Username, string Password)
		{
			//round brightness to percentage value
			int iBrightness_Gain = Convert.ToInt32(decimal.Round((((Convert.ToDecimal(Brightness_Gain)) * 100) / 65535), 0));

			Debug_Message("Send_RGBW_Command", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password + ", Command = " + Command + ", Level = " + iBrightness_Gain);

			#region Create url
			string url = "";

			//Channel must be zero if device not controlling a multichannel white LED strip.
			if (Mode != "white")
			{
				Channel = 0;
			}

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/" + Mode + "/" + Channel.ToString();
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/" + Mode + "/" + Channel.ToString();
			}

			//Add Command to URL
			switch (Command)
			{
				case 0:
					//turn off
					url += "?turn=off";
					break;

				case 1:
					//turn on
					url += "?turn=on";
					break;

				case 2:
					//toggle
					url += "?turn=toggle";
					break;

				case 3:
					//refresh device state
					break;

				case 4:
					//rgbw
					if (Mode == "white")
					{
						url += "?turn=on&brightness=" + iBrightness_Gain;
					}
					else if (Mode == "color")
					{
						url += "?turn=on&mode=" + Mode + "&red=" + Red + "&green=" + Green + "&blue=" + Blue + "&gain=" + iBrightness_Gain + "&white=" + White + "&effect=" + Effect;
					}
					else
					{
						Debug_Message("Send_RGBW_Command", "Error - Unsupported mode - " + Mode);
					}
					break;

				default:
					//unsupported command
					Debug_Message("Send_RGBW_Command", "Error - Unsupported command - " + Command);
					return;
			}
			Debug_Message("Send_RGBW_Command", "URL: " + url);
			#endregion

			#region Send Command
			double Brightness_Gain_FB = 0;
			short Red_FB = 0;
			short Green_FB = 0;
			short Blue_FB = 0;
			short White_FB = 0;
			short Effect_FB = 0;
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Send_RGBW_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Send_RGBW_Command", "ContentString = " + ContentString);
					string s = Parse_Data_Substring(ContentString, "", "\"ison\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_RGBW_Command", "ison = " + s);

						#region Parse Is On
						short Light_Is_On = Convert.ToInt16((s == "true") ? 1 : 0);
						#endregion

						#region Parse Brightness
						s = Parse_Data_Substring(ContentString, "", "\"mode\":\"", "\",");
						if (string.IsNullOrEmpty(s) == false)
						{
							if (s == "color")
							{
								s = Parse_Data_Substring(ContentString, "", "\"gain\":", ",");
								if (string.IsNullOrEmpty(s) == false)
								{
									Brightness_Gain_FB = double.Parse(s);
								}
								else
								{
									Brightness_Gain_FB = 0;
								}
							}
							else if (s == "white")
							{
								s = Parse_Data_Substring(ContentString, "", "\"brightness\":", ",");
								if (string.IsNullOrEmpty(s) == false)
								{
									Brightness_Gain_FB = double.Parse(s);
								}
								else
								{
									Brightness_Gain_FB = 0;
								}
							}
						}
						else
						{
							Debug_Message("Send_RGBW_Command", "Parsing ContentString - modse = null");
							Brightness_Gain_FB = 0;
						}
						#endregion

						#region Parse Red
						s = Parse_Data_Substring(ContentString, "", "\"red\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							Red_FB = short.Parse(s);
						}
						else
						{
							Red_FB = 256;
						}
						#endregion

						#region Parse Green
						s = Parse_Data_Substring(ContentString, "", "\"green\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							Green_FB = short.Parse(s);
						}
						else
						{
							Green_FB = 256;
						}
						#endregion

						#region Parse Blue
						s = Parse_Data_Substring(ContentString, "", "\"blue\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							Blue_FB = short.Parse(s);
						}
						else
						{
							Blue_FB = 256;
						}
						#endregion

						#region Parse White
						s = Parse_Data_Substring(ContentString, "", "\"white\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							White_FB = short.Parse(s);
						}
						else
						{
							White_FB = 256;
						}
						#endregion

						#region Parse Effect
						s = Parse_Data_Substring(ContentString, "", "\"effect\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							Effect_FB = short.Parse(s);
						}
						else
						{
							Effect_FB = 256;
						}
						#endregion

						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Light_Is_On, "", 0, "", "", "", "",
							Convert.ToUInt16(Brightness_Gain_FB), Red_FB, Green_FB, Blue_FB, White_FB, Effect_FB, "", 9999, "", 9999, 256, 256, 256, "", "", 9999, 9999, 101);
					}
					else
					{
						Debug_Message("Send_RGBW_Command", "Error - Unable to Parse Device State from Content String");
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Send_RGBW_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_TRV_Command	-	Sends a TRV command to the Shelly device
		//							Command Format	=	http://[device_IP]/settings/thermostat/0?parameter=value
		//							Temperature_Format - 1=Fahrenheit, 2=Celsius
		//							Returns 1 if successful or 0 if not
		// 
		//****************************************************************************************
		public void Send_TRV_Command(string Device_IP, string Parameter, string Value, string Username, string Password)
		{
			string s;
			decimal d;
			short Target_Temperature = 9999;
			short Target_Temperature_Tenths = 9999;
			short Target_Temp_Enabled = 256;
			short Schedule_Enabled = 256;
			short Schedule_Profile_ID = 256;

			Debug_Message("Send_TRV_Command", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password + ", Parameter = " + Parameter + ", Value = " + Value);

			#region Create url
			string url = "";

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/settings/thermostat/0";
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/settings/thermostat/0";
			}

			//Add Value to URL
			if ((String.IsNullOrEmpty(Parameter) == false) && (String.IsNullOrEmpty(Value) == false))
			{
				#region Target Temperature in Tenths to Degrees
				if (Parameter == "target_t")
				{
					try
					{
						d = decimal.Parse(Value);
						d = d / 10;
						Value = d.ToString();
					}
					catch (Exception e)
					{
						string err = "Shelly - Send_TRV_Command - Unable to Parse Target Temperature Value: " + e;
						CrestronConsole.PrintLine(err);
						Crestron.SimplSharp.ErrorLog.Error(err + "\n");
						return;
					}
				}
				#endregion
				url += "?" + Parameter + "=" + Value;
			}

			Debug_Message("Send_TRV_Command", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.TimeoutEnabled = true;
				//client.Timeout = 10;//10 seconds
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Header.SetHeaderValue("accept", "application/json");
				request.Header.SetHeaderValue("accept-language", "en");
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Send_TRV_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Send_TRV_Command", "ContentString = " + ContentString);

					#region Parse Temperature Setpoint Value
					s = Parse_Data_Substring(ContentString, "", "\"value\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_TRV_Command", "target_t-value = " + s);
						try
						{
							d = decimal.Parse(s);
							Target_Temperature = Convert.ToInt16(decimal.Round(d, 0));
							Target_Temperature_Tenths = Convert.ToInt16(decimal.Round((d * 10), 0));

						}
						catch (Exception e)
						{
							Debug_Message("Send_TRV_Command", "Exception Parsing Temperature from Content String - " + ContentString);
							Debug_Message("Send_TRV_Command", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse target_t-enabled from Content String");
					}
					#endregion

					#region Parse Target Temp Enabled
					s = Parse_Data_Substring(ContentString, "", "\"enabled\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_TRV_Command", "target_t-enabled = " + s);
						Target_Temp_Enabled = Convert.ToInt16(((s == "true") || (s == " true")) ? 1 : 0);
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse target_t-enabled from Content String");
					}
					#endregion

					#region Parse Schedule Enabled
					s = Parse_Data_Substring(ContentString, "", "\"schedule\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_TRV_Command", "schedule-enabled = " + s);
						Schedule_Enabled = Convert.ToInt16(((s == "true") || (s == " true")) ? 1 : 0);
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse schedule-enabled from Content String");
					}
					#endregion

					#region Parse Schedule Profile
					s = Parse_Data_Substring(ContentString, "", "\"schedule_profile\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Send_TRV_Command", "schedule_profile = " + s);
						try
						{
							Schedule_Profile_ID = Int16.Parse(s);
						}
						catch (Exception e)
						{
							Debug_Message("Send_TRV_Command", "Exception Parsing schedule_profile from Content String - " + ContentString);
							Debug_Message("Send_TRV_Command", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse schedule_profile from Content String");
					}
					#endregion

					SignalChangeEvents.SerialValueChange(Device_IP, 0, 256, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256,
						"", 9999, "", 9999, Target_Temp_Enabled, Schedule_Enabled, Schedule_Profile_ID, "", "", Target_Temperature, Target_Temperature_Tenths, 101);
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Send_TRV_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  TRV_Poll_Status		-	Poll TRV for Status
		//							Command Format	=	http://[device_IP]/thermostat/0
		//							Temperature_Format - 1=Fahrenheit, 2=Celsius
		//							Returns 1 if successful or 0 if not
		// 
		//****************************************************************************************
		public void TRV_Poll_Status(string Device_IP, string Username, string Password)
		{
			string s;
			decimal d;
			short Target_Temperature = 9999;
			short Target_Temperature_Tenths = 9999;
			short Target_Temp_Enabled = 256;
			short Schedule_Enabled = 256;
			short Schedule_Profile_ID = 256;
			string Valve_Position = "";
			short Temperature = 9999;
			short Temperature_Tenths = 9999;
			short Battery_Percentage = 101;

			Debug_Message("TRV_Poll_Status", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password);

			#region Create url
			string url = "";

			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/status";
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/status";
			}

			Debug_Message("Send_TRV_Command", "URL: " + url);
			#endregion

			#region Poll
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.TimeoutEnabled = true;
				//client.Timeout = 10;//10 seconds
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Header.SetHeaderValue("accept", "application/json");
				request.Header.SetHeaderValue("accept-language", "en");
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - TRV_Poll_Status - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("TRV_Poll_Status", "ContentString = " + ContentString);

					#region Parse Target Temperature Setpoint Value
					s = Parse_Data_Substring(ContentString, "target_t", "\"value\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "target_t-value = " + s);
						try
						{
							d = decimal.Parse(s);
							Target_Temperature = Convert.ToInt16(decimal.Round(d, 0));
							Target_Temperature_Tenths = Convert.ToInt16(decimal.Round((d * 10), 0));

						}
						catch (Exception e)
						{
							Debug_Message("TRV_Poll_Status", "Exception Parsing Target Temperature from Content String - " + ContentString);
							Debug_Message("TRV_Poll_Status", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse Target Temperature from Content String");
					}
					#endregion

					#region Parse Target Temp Enabled
					s = Parse_Data_Substring(ContentString, "target_t", "\"enabled\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "target_t-enabled = " + s);
						Target_Temp_Enabled = Convert.ToInt16(((s == "true") || (s == " true")) ? 1 : 0);
					}
					else
					{
						Debug_Message("TRV_Poll_Status", "Error - Unable to Parse target_t-enabled from Content String");
					}
					#endregion

					#region Parse Schedule Enabled
					s = Parse_Data_Substring(ContentString, "thermostats", "\"schedule\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "schedule-enabled = " + s);
						Schedule_Enabled = Convert.ToInt16(((s == "true") || (s == " true")) ? 1 : 0);
					}
					else
					{
						Debug_Message("TRV_Poll_Status", "Error - Unable to Parse schedule-enabled from Content String");
					}
					#endregion

					#region Parse Schedule Profile
					s = Parse_Data_Substring(ContentString, "thermostats", "\"schedule_profile\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "schedule_profile = " + s);
						try
						{
							Schedule_Profile_ID = Int16.Parse(s);
						}
						catch (Exception e)
						{
							Debug_Message("TRV_Poll_Status", "Exception Parsing schedule_profile from Content String - " + ContentString);
							Debug_Message("TRV_Poll_Status", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse schedule_profile from Content String");
					}
					#endregion

					#region Parse Valve Position
					s = Parse_Data_Substring(ContentString, "thermostats", "\"pos\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "Valve Position = " + s);
						try
						{
							d = decimal.Parse(s);
							d = decimal.Round(d, 0);//assure accuracy of comparisons
							if (d == -1)//not calibrated
							{
								Valve_Position = "";
							}
							else if (d == 0)//closed
							{
								Valve_Position = "CLOSED";
							}
							else if (d > 0)//opened
							{
								Valve_Position = "OPENED";
							}
						}
						catch (Exception e)
						{
							Debug_Message("TRV_Poll_Status", "Exception Parsing Valve Postion from Content String - " + ContentString);
							Debug_Message("TRV_Poll_Status", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse Valve Position from Content String");
					}
					#endregion

					#region Parse Temperature Reading
					s = Parse_Data_Substring(ContentString, "tmp", "\"value\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "temperature reading = " + s);
						try
						{
							d = decimal.Parse(s);
							Temperature = Convert.ToInt16(decimal.Round(d, 0));
							Temperature_Tenths = Convert.ToInt16(decimal.Round((d * 10), 0));

						}
						catch (Exception e)
						{
							Debug_Message("TRV_Poll_Status", "Exception Parsing Temperature from Content String - " + ContentString);
							Debug_Message("TRV_Poll_Status", e.ToString());
						}
					}
					else
					{
						Debug_Message("Send_TRV_Command", "Error - Unable to Parse Temperature from Content String");
					}
					#endregion

					#region Parse Battery Percentage
					s = Parse_Data_Substring(ContentString, "bat", "\"value\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("TRV_Poll_Status", "bat-value = " + s);
						try
						{
							Battery_Percentage = Int16.Parse(s);
						}
						catch (Exception e)
						{
							Debug_Message("TRV_Poll_Status", "Exception Parsing Battery Percentage from Content String - " + ContentString);
							Debug_Message("TRV_Poll_Status", e.ToString());
						}
					}
					else
					{
						Debug_Message("TRV_Poll_Status", "Error - Unable to Parse Battery Percentage from Content String");
					}
					#endregion

					SignalChangeEvents.SerialValueChange(Device_IP, 0, 256, "", 0, "", "STATE", "", "", 101, 256, 256, 256, 256, 256,
						"", Temperature, "", Temperature_Tenths, Target_Temp_Enabled, Schedule_Enabled, Schedule_Profile_ID, "", 
						Valve_Position, Target_Temperature, Target_Temperature_Tenths, Battery_Percentage);
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - TRV_Poll_Status - Error Polling Status: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Power	-	Read Power from internal meter
		// 
		//****************************************************************************************
		public short Get_Power(short Power_Meter_Type, string Device_IP, short Channel, string Username, string Password)
		{
			Debug_Message("Get_Power", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password + ", Power_Meter_Type = " + Power_Meter_Type);

			#region Create url
			string url = "";

			//Create base part of url based on whether a username / password is set
			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP;
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP;
			}

			//set the remainder of the url based on the device type
			if (Power_Meter_Type == 0)
			{
				//EM Power Meter
				url += "/emeter/" + Channel + "/power";
			}
			else if (Power_Meter_Type == 1)
			{
				//No Power Meter
				return -1;
			}
			else if (Power_Meter_Type == 2)
			{
				//Shelly 2.5
				url += "/meter/" + Channel + "/power";
			}
			else if (Power_Meter_Type == 3)
			{
				//Shelly 1PM
				url += "/status/meters/" + Channel;
			}
			else if (Power_Meter_Type == 4)
			{
				//Shelly Plus and Pro RPC Call
				url += "/rpc/Switch.GetStatus?id=" + Channel;
			}
			else
			{
				//Unknown Device Type
				Debug_Message("Get_Power", "Notice - Trying to retrieve power from unknown power meter type");
				return -1;
			}

			Debug_Message("Get_Power", "URL: " + url);
			#endregion

			#region Send Command to Retrieve Status
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Get_Power - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return -1;
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Get_Power", "ContentString = " + ContentString);
					string s = "";
					if (Power_Meter_Type <= 3)
					{
						//Gen 1 Products
						s = Parse_Data_Substring(ContentString, "", "\"power\":", ",");
					}
					else
					{
						//RPC
						s = Parse_Data_Substring(ContentString, "", "\"apower\":", ",");
					}
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Get_Power", "power = " + s);
						return Convert.ToInt16(decimal.Round((decimal.Parse(s)), 0));
					}
					else
					{
						Debug_Message("Get_Power", "Error - Unable to Parse Power from Content String");
						return -1;
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Get_Power - Error Reading Power: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return -1;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_EM_Voltage	-	Read volage from EM devicd
		// 
		//****************************************************************************************
		public short Get_EM_Voltage(string Device_IP, short Channel, string Username, string Password)
		{
			Debug_Message("Get_EM_Voltage", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password);

			#region Create url
			string url = "";

			//Create base part of url based on whether a username / password is set
			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP + "/emeter/" + Channel + "/power";
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP + "/emeter/" + Channel + "/power";
			}

			Debug_Message("Get_EM_Voltage", "URL: " + url);
			#endregion

			#region Send Command to Retrieve Status
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Get_EM_Voltage - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return -1;
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Get_EM_Voltage", "ContentString = " + ContentString);
					string s = Parse_Data_Substring(ContentString, "", "\"voltage\":", ",");
					if (string.IsNullOrEmpty(s) == false)
					{
						Debug_Message("Get_EM_Voltage", "voltage = " + s);
						return Convert.ToInt16(decimal.Round((decimal.Parse(s)), 0));
					}
					else
					{
						Debug_Message("Get_EM_Voltage", "Error - Unable to Parse Voltage from Content String");
						return -1;
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Get_EM_Voltage - Error Reading Voltage: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return -1;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Uni_Get_Temp_and_Humidity	-	Read temperature / Humidity when a DS18B20 or
		//									DHT22 is connected to a Shelly Uni
		// 
		//****************************************************************************************
		public short Uni_Get_Temp_and_Humidity(string Device_IP, string Username, string Password, short Celcius, short Tenth_of_Degrees, ref short Temperature, ref short Humidity)
		{
			string t, h;
			Decimal d;

			Debug_Message("Uni_Get_Temp_and_Humidity", "Device_IP = " + Device_IP + ", Username = " + Username + ", Password = " + Password
				+ ", Celcius = " + Celcius + ", Tenth_of_Degrees = " + Tenth_of_Degrees);

			#region Create url
			string url = "";

			//Create base part of url based on whether a username / password is set
			if ((string.IsNullOrEmpty(Username)) || (string.IsNullOrEmpty(Password)))
			{
				url = "http://" + Device_IP;
			}
			else
			{
				url = "http://" + Username + ":" + Password + "@" + Device_IP;
			}
			url += "/status";

			Debug_Message("Uni_Get_Temp_and_Humidity", "URL: " + url);
			#endregion

			#region Send Command to Retrieve Status
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly - Uni_Get_Temp_and_Humidity - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Uni_Get_Temp_and_Humidity", "ContentString = " + ContentString);

					#region Parse Temperature
					if (Celcius == 0)
					{
						t = Parse_Data_Substring(ContentString, "", "\"tF\":", "}");
					}
					else
					{
						t = Parse_Data_Substring(ContentString, "", "\"tC\":", ",");
					}

					if (string.IsNullOrEmpty(t) == false)
					{
						try
						{
							d = Decimal.Parse(t);
							if (Tenth_of_Degrees == 1)
							{
								d *= 10;
							}
							Temperature = Convert.ToInt16(decimal.Round(d, 0));
						}
						catch (Exception e)
						{
							string err = "Shelly - Uni_Get_Temp_and_Humidity - Unable to Parse Temperature: " + t + ", Exception = " + e.ToString();
							CrestronConsole.PrintLine(err);
							Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							return 0;
						}
					}
					else
					{
						Debug_Message("Uni_Get_Temp_and_Humidity", "Error - Unable to Retrieve Temperature from Content String");
						return 0;
					}
					#endregion

					#region Parse Humidity
					h = Parse_Data_Substring(ContentString, "", "\"hum\":", "}");
					if (string.IsNullOrEmpty(h) == false)
					{
						try
						{
							d = Decimal.Parse(h);
							Humidity = Convert.ToInt16(decimal.Round(d, 0));
						}
						catch (Exception e)
						{
							string err = "Shelly - Uni_Get_Temp_and_Humidity - Unable to Parse Humidity: " + h + ", Exception = " + e.ToString();
							CrestronConsole.PrintLine(err);
							Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							return 0;
						}
					}
					else
					{
						Humidity = 0;
					}
					#endregion

					return 1;
				}
			}
			catch (Exception e)
			{
				string err = "Shelly - Uni_Get_Temp_and_Humidity - Error Reading temp/humidity: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Shelly - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Shelly - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Shelly - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Shelly - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Shelly - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Shelly - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Shelly.Debug = Debug_Options.None;
					break;

				case 1:
					Shelly.Debug = Debug_Options.Console;
					break;

				case 2:
					Shelly.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Shelly.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Shelly - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Shelly - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}

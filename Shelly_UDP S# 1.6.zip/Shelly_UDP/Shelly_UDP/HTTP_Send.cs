﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Http;


namespace Shelly_UDP
{
    public class HTTP_Send
	{
		#region Declarations
		private static bool Show_Debug_Messages;
		#endregion Declarations

		#region BTHome Constants
		//BTHome Data Types - https://bthome.io/format/
		const int BTHome_Battery_FP0 = 0x01;
		const int BTHome_Humidity_FP0 = 0x2E;
		const int BTHome_Temperature_FP1 = 0x45;
		const int BTHome_Temperature_FP2 = 0x02;
		const int BTHome_Button = 0x3A;
		const int BTHome_Illuminance_FP2 = 0x05;
		const int BTHome_Window = 0x2D;
		const int BTHome_Rotation_FP1 = 0x3F;
		const int BTHome_Motion = 0x21;
		const int BTHome_Moisture = 0x20;
		const int BTHome_Speed = 0x44;
		const int BTHome_UV_Index = 0x46;
		const int BTHome_Direction = 0x5E;
		const int BTHome_Precipitation = 0x5F;
		const int BTHome_Dewpoint = 0x08;
		const int BTHome_Pressure = 0x04;
		const int BTHome_Voltage = 0x0C;
		#endregion

        //****************************************************************************************
        // 
        //  HTTP_Send	-	Constructor
        // 
        //****************************************************************************************
        public HTTP_Send()
        {
        }

        //****************************************************************************************
        // 
        //  HTTP_Send	-	Destructor
        // 
        //****************************************************************************************
		~HTTP_Send()
        {
        }

		//****************************************************************************************
		// 
		//  Send_Command	-	Send command to Shelly Device
		// 
		//****************************************************************************************
		public void Send_Command(string Device_IP, short Index, string Method_Name, string JSON_Params)
		{
			HttpClient client = null;
			HTTP_Response_Data Data = null;
			string s;
			Show_Debug_Messages = String.IsNullOrEmpty(UDP_Message.Startup_Debug_Device_IP) || (UDP_Message.Startup_Debug_Device_IP == Device_IP);

			Debug_Message("Send_Command", "Device_IP = " + Device_IP + ", Method_Name = " + Method_Name + ", JSON_Params = " + JSON_Params);

			#region Validate IP Address
			if (Validate_IP_Address(Device_IP, "Send_Command") == false)
			{
				return;
			}
			#endregion

			#region Create url
			string url = "";

			url = "http://" + Device_IP + "/rpc/" + Method_Name;

			Debug_Message("Send_Command", "URL: " + url);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Post;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//add data to request
				request.ContentBytes = Encoding.UTF8.GetBytes(JSON_Params);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly Gen2+ - Send_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					Debug_Message("Send_Command", "Success - response.ContentString = " + response.ContentString);
					s = response.ContentString;
					if (string.IsNullOrEmpty(s) != true)
					{
						Data = JsonConvert.DeserializeObject<HTTP_Response_Data>(response.ContentString);
						if (Data != null)
						{
							Pass_Back_HTTP_Response_Data(Device_IP, Index, Data, response.ContentString, Show_Debug_Messages);
						}
						else
						{
							Debug_Message("Send_Command", "JSON Parsing HTTP_Response Data = null");
						}
					}
					else
					{
						Debug_Message("Send_Command", "s is empty or null");
					}

				}
			}
			catch (Exception e)
			{
				string err = "Shelly Gen2+ - Send_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("URL - " + url);
				CrestronConsole.PrintLine("JSON - " + JSON_Params);
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Pass_Back_HTTP_Response_Data	-	Pass data back to S+
		// 
		//****************************************************************************************
		private void Pass_Back_HTTP_Response_Data(string Device_IP, short Channel, HTTP_Response_Data Data, string JSON, bool Show_Debug_Messages)
		{
			#region Declarations
			string aenergy = "";
			string ret_aenergy = "";
			short Red = 999;
			short Green = 999;
			short Blue = 999;
			short White = 999;
			string Temperature_C = "";
			string Temperature_F = "";
			string Relative_Humidity = "";
			string Power = "";
			string Frequency = "";
			string Voltage = "";
			string Current = "";
			string Act_Power = "";
			string Aprt_Power = "";
			string Power_Factor = "";
			short Brightness = 999;
			string State = "";
			short Current_Position = 999;
			short Slat_Position = 999;
			string Set_Point_C = "";
			string Set_Point_F = "";
			short Alarm = 999;
			string Battery_Voltage = "";
			short Battery_Percent = 999;
			string Illuminance = "";
			string Rotation = "";
			short Window_State = 999;
			short Motion = 999;
			string Moisture = "";
			string Speed_0 = "";
			string Speed_1 = "";
			string UV_Index = "";
			string Direction = "";
			string Precipitation = "";
			string Dewpoint = "";
			string Pressure = "";
			short Return_Value = 999;
			short Count = 999;
			string Percent = "";
			short Device_Channel = 0;
			short Steps = 999;
			string Number = "";
			string Number1 = "";
			#endregion

			Debug_Message("Pass_Back_HTTP_Response_Data", "Device_IP = " + Device_IP + ", Index = " + Channel);

			#region Manage Value that can be int, bool, or something else
			string s = UDP_Message.Parse_Data_Substring(JSON, "", "\"value\":", ":");
			if (s == "{\"counter\"")
			{
				Number1 = UDP_Message.Parse_Data_Substring(JSON, "", "\"total\":", ",");
			}
			else
			{
				s = UDP_Message.Parse_Data_Substring(JSON, "", "\"value\":", ",");
				if (string.IsNullOrEmpty(s) == false)
				{
					Debug_Message("Pass_Back_HTTP_Response_Data", "Value = " + s);
					if (s == "true")
					{
						Return_Value = 1;
					}
					else if (s == "false")
					{
						Return_Value = 0;
					}
					else if (s.Contains("."))
					{
						Number = s;
					}
					else
					{
						Number = s;
						try
						{
							Return_Value = short.Parse(s);
						}
						catch (Exception e)
						{
							CrestronConsole.PrintLine("Shelly Gen2+ - Pass_Back_HTTP_Response_Data - Unable to Parse Value Parameter: " + e);
							CrestronConsole.PrintLine("Shelly Gen2+ - Pass_Back_HTTP_Response_Data - Value = " + s);
							Return_Value = 999;
						}
					}
				}
			}
			#endregion

			#region Don't reference nulls
			if (Data.aenergy != null)
			{
				aenergy = Data.aenergy.total.ToString();
			}

			if (Data.ret_aenergy != null)
			{
				aenergy = Data.ret_aenergy.total.ToString();
			}
			if (Data.rgb != null)
			{
				Red = (short)(Data.rgb[0]);
				Green = (short)(Data.rgb[1]);
				Blue = (short)(Data.rgb[2]);
			}
			if (Data.temperature != null)
			{
				Temperature_C = Data.temperature.tC.ToString();
				Temperature_F = Data.temperature.tF.ToString();
			}
			if (Data.humidity != null)
			{
				Relative_Humidity = Data.humidity.rh.ToString();
			}
			#endregion

			#region Don't Pass Back Unitialized Values
			if (JSON.IndexOf("apower\":") != -1)
			{
				Power = Data.apower.ToString();
			}
			if (JSON.IndexOf("voltage\":") != -1)
			{
				if (JSON.IndexOf("voltage\":null") == -1)
				{
					Voltage = Data.voltage.ToString();
				}
			}
			if (JSON.IndexOf("freq\":") != -1)
			{
				Frequency = Data.freq.ToString();
			}
			if (JSON.IndexOf("current\":") != -1)
			{
				Current = Data.current.ToString();
			}
			if (JSON.IndexOf("act_power\":") != -1)
			{
				Act_Power = Data.act_power.ToString();
			}
			if (JSON.IndexOf("aprt_power\":") != -1)
			{
				Aprt_Power = Data.aprt_power.ToString();
			}
			if (JSON.IndexOf("pf\":") != -1)
			{
				Power_Factor = Data.pf.ToString();
			}
			if (JSON.IndexOf("brightness\":") != -1)
			{
				Brightness = (short)Data.brightness;
			}
			if (JSON.IndexOf("state\":") != -1)
			{
				State = Data.state;
			}
			if (JSON.IndexOf("current_pos\":") != -1)
			{
				Current_Position = (short)Data.current_pos;
			}
			if (JSON.IndexOf("slat_pos\":") != -1)
			{
				Slat_Position = (short)Data.slat_pos;
			}
			if (JSON.IndexOf("target_C\":") != -1)
			{
				Set_Point_C = Data.target_C.ToString();
				Set_Point_F = Convert_Temperature_C_to_F(Set_Point_C, 0);
			}
			if (JSON.IndexOf("current_C\":") != -1)
			{
				Temperature_C = Data.current_C.ToString();
				Temperature_F = Convert_Temperature_C_to_F(Temperature_C, 1);
			}
			if (JSON.IndexOf("battery\":") != -1)
			{
				Battery_Percent = (short) Data.battery;
			}
			if (JSON.IndexOf("white\":") != -1)
			{
				White = (short)Data.white;
			}
			if (JSON.IndexOf("tC\":") != -1)
			{
				if (JSON.IndexOf("tC\":null") == -1)
				{
					Temperature_C = Data.tC.ToString();
					Temperature_F = Convert_Temperature_C_to_F(Temperature_C, 1);
				}
			}
			if (JSON.IndexOf("rh\":") != -1)
			{
				if (JSON.IndexOf("rh\":null") == -1)
				{
					Relative_Humidity = Data.rh.ToString();
				}
			}
			if (JSON.IndexOf("percent\":") != -1)
			{
				if (JSON.IndexOf("percent\":null") == -1)
				{
					Percent = Data.percent.ToString();
				}
			}
			if (JSON.IndexOf("num_objects\":") != -1)
			{
				if (JSON.IndexOf("num_objects\":null") == -1)
				{
					Count = (short) Data.num_objects;
				}
			}
			#endregion

			SignalChangeEvents.SerialValueChange(Device_IP, Channel, 999, "", DateTime.Now.ToString(), (short)(Data.output == true ? 1 : 0),
				Power, Voltage, Frequency, Current, aenergy, ret_aenergy, 0, Act_Power, Aprt_Power, Power_Factor, "", "", Brightness, Data.state,
				Current_Position, Slat_Position, "", Red, Green, Blue, White, Temperature_C, Temperature_F, Relative_Humidity, Set_Point_C, Set_Point_F,
				Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, "", Moisture, Speed_0, Speed_1, UV_Index,
				Direction, Precipitation, Dewpoint, Pressure, Return_Value, Count, Percent, Device_Channel, Steps, Number, Number1);
		}

		//****************************************************************************************
		// 
		//  Register_Bluetooth_Device_and_Sensors
		// 
		//****************************************************************************************
		public short Register_Bluetooth_Device_and_Sensors(string Gateway_IP, short Index, string Type)
		{
			HttpClient client = null;
			BTHomeDevice Data = null;
			Device_Types t;

			Debug_Message("Register_Bluetooth_Device_and_Sensors", "Gateway_IP = " + Gateway_IP + ", Index = " + Index + ", Type = " + Type);

			#region Convert String to Device Type
			t = Convert_To_Device_Type(Type);
			if (t == Device_Types.Unknown)
			{
				return 0;
			}
			#endregion

			#region Validate IP Address
			if (Validate_IP_Address(Gateway_IP, "Send_Command") == false)
			{
				return 0;
			}
			#endregion

			#region Add to List of Devices
			Device device = new Device("", Gateway_IP, Index, t, true);
			UDP_Message.Devices.Add(device);
			#endregion

			#region Create url
			string url = "";

			url = "http://" + Gateway_IP + "/rpc/BTHomeDevice.GetKnownObjects?id=" + Index;

			Debug_Message("Register_Bluetooth_Device_and_Sensors", "URL: " + url);
			#endregion

			#region Send Command to Get Sensor List
			try
			{
				//Create http client
				client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.KeepAlive = false;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Shelly Gen2+ - Register_Bluetooth_Device_and_Sensors - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					return 0;
				}
				else
				{
					Debug_Message("Register_Bluetooth_Device_and_Sensors", "Success - response.ContentString = " + response.ContentString);
					string s = response.ContentString;
					if (string.IsNullOrEmpty(s) != true)
					{
						Data = JsonConvert.DeserializeObject<BTHomeDevice>(response.ContentString);
						if (Data != null)
						{
							switch (t)
							{
								case Device_Types.TRV:
									#region TRV
									Debug_Message("Register_Bluetooth_Device_and_Sensors", "Registering TRV Sensors = " + Index);
									foreach (Obj o in Data.objects)//Loop through objects in returned JSON
									{
										if (((o.obj_id == BTHome_Temperature_FP1) || (o.obj_id == BTHome_Temperature_FP2)) && (o.idx == 0))
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "TRV - Set Point = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Set_Point);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (((o.obj_id == BTHome_Temperature_FP1) || (o.obj_id == BTHome_Temperature_FP2)) && (o.idx == 1))
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "TRV Temperature - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Temperature);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Battery_FP0)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "TRV Battery - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Battery);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else
										{
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "TRV - Unsupported Sensor Device_Channel = " + Index + ", o.obj.id = " + o.obj_id);
										}
									}
									#endregion
									break;

								case Device_Types.H_and_T:
									#region H&T
									Debug_Message("Register_Bluetooth_Device_and_Sensors", "Registering H&T Sensors = " + Index);
									foreach (Obj o in Data.objects)//Loop through objects in returned JSON
									{
										if (o.obj_id == BTHome_Humidity_FP0)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "H&T Humidity - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Humidity);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if ((o.obj_id == BTHome_Temperature_FP1) || (o.obj_id == BTHome_Temperature_FP2))
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "H&T Temperature - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Temperature);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Battery_FP0)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "H&T Battery - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Battery);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Button)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "H&T Button - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Button);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else
										{
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "H&T - Unsupported Sensor Device_Channel = " + Index + ", o.obj.id = " + o.obj_id);
										}
									}
									#endregion
									break;

								case Device_Types.Door_Window:
									#region Door/Window
									Debug_Message("Register_Bluetooth_Device_and_Sensors", "Registering Door/Window Sensors = " + Index);
									foreach (Obj o in Data.objects)//Loop through objects in returned JSON
									{
										if (o.obj_id == BTHome_Window)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Door/Window Window - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Door_Window);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Illuminance_FP2)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Door/Window Illuminance - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Illuminance);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Rotation_FP1)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Door/Window Rotation - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Rotation);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Battery_FP0)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Door/Window Battery - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Battery);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else
										{
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "Door/Window - Unsupported Sensor Device_Channel = " + Index + ", o.obj.id = " + o.obj_id);
										}
									}
									#endregion
									break;

								case Device_Types.Button:
									#region Button
									Debug_Message("Register_Bluetooth_Device_and_Sensors", "Registering Button Sensors = " + Index);
									foreach (Obj o in Data.objects)//Loop through objects in returned JSON
									{
										if (o.obj_id == BTHome_Battery_FP0)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Button Battery - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Battery);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else
										{
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "Button - Unsupported Sensor Device_Channel = " + Index + ", o.obj.id = " + o.obj_id);
										}
									}
									#endregion
									break;

								case Device_Types.Motion:
									#region Motion
									Debug_Message("Register_Bluetooth_Device_and_Sensors", "Registering Motion Sensors = " + Index);
									foreach (Obj o in Data.objects)//Loop through objects in returned JSON
									{
										if (o.obj_id == BTHome_Motion)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Motion - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Motion);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Illuminance_FP2)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Door/Window Illuminance - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Illuminance);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Battery_FP0)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Door/Window Battery - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Battery);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else
										{
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "Motion - Unsupported Sensor Device_Channel = " + Index + ", o.obj.id = " + o.obj_id);
										}
									}
									#endregion
									break;

								case Device_Types.Weather:
									#region Weather
									Debug_Message("Register_Bluetooth_Device_and_Sensors", "Registering Weather Sensors = " + Index);
									foreach (Obj o in Data.objects)//Loop through objects in returned JSON
									{
/*
										if (o.obj_id == BTHome_Pressure)
										{
											s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Pressure - t = " + s);
											Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), Index, Device_Types.Pressure);
											device.Sensors.Add(sensor);//Add Sensor to device
											UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
										}
										else if (o.obj_id == BTHome_Pressure)
										{
											s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Pressure - t = " + s);
											Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), Index, Device_Types.Pressure);
											device.Sensors.Add(sensor);//Add Sensor to device
											UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
										}
										else if (o.obj_id == BTHome_Dewpoint)
										{
											s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Dewpoint - t = " + s);
											Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), Index, Device_Types.Dewpoint);
											device.Sensors.Add(sensor);//Add Sensor to device
											UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
										}
										else if (o.obj_id == BTHome_Humidity_FP0)
										{
											s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Humidity - t = " + s);
											Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), Index, Device_Types.Humidity);
											device.Sensors.Add(sensor);//Add Sensor to device
											UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
										}
										else if (o.obj_id == BTHome_Temperature_FP1)
										{
											s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Temperature - t = " + s);
											Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), Index, Device_Types.Temperature);
											device.Sensors.Add(sensor);//Add Sensor to device
											UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
										}
										else if (o.obj_id == BTHome_Precipitation)
										{
											s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Precipitation - t = " + s);
											Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), Index, Device_Types.Precipitation);
											device.Sensors.Add(sensor);//Add Sensor to device
											UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
										}
*/
										if (o.obj_id == BTHome_Illuminance_FP2)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Illuminance - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Illuminance);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Moisture)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Moisture - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Moisture);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Speed)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Speed - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Speed);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Direction)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Direction - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Direction);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Precipitation)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Precipitation - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Precipitation);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Temperature_FP1)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Temperature - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Temperature);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Humidity_FP0)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Humidity - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Humidity);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Dewpoint)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Dewpoint - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Dewpoint);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Pressure)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Pressure - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Pressure);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_UV_Index)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather UV_Index - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.UV_Index);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else if (o.obj_id == BTHome_Battery_FP0)
										{
											if (o.component != null)
											{
												s = UDP_Message.Parse_Data_Substring(o.component + "!", "", "bthomesensor:", "!");//channel from bthomesensor:XXX
												Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Battery - t = " + s);
												Sensor sensor = new Sensor(Gateway_IP, short.Parse(s), o.idx, Index, Device_Types.Battery);
												device.Sensors.Add(sensor);//Add Sensor to device
												UDP_Message.Sensors.Add(sensor);//Add Sensor to sensor list
											}
										}
										else
										{
											Debug_Message("Register_Bluetooth_Device_and_Sensors", "Weather Station - Unsupported Sensor Device_Channel = " + Index + ", o.obj.id = " + o.obj_id);
										}
									}
									#endregion
									break;

								default:
									return 0;
							}
						}
						else
						{
							Debug_Message("Register_Bluetooth_Device_and_Sensors", "JSON Parsing HTTP_Response Data = null");
						}
					}
					else
					{
						Debug_Message("Register_Bluetooth_Device_and_Sensors", "s is empty or null");
					}
				}
			}
			catch (Exception e)
			{
				string err = "Shelly Gen2+ - Register_Bluetooth_Device_and_Sensors - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return 0;
			}
			finally
			{
				if (client != null)
				{
					client.Dispose();
				}
			}
			#endregion

			return 1;
		}

		//****************************************************************************************
		// 
		//  Register_IP_Device
		// 
		//****************************************************************************************
		public short Register_IP_Device(string IP_Address, short Index, string Type)
		{
			Device_Types t;

			Debug_Message("Register_IP_Device", "IP_Address = " + IP_Address + ", Index = " + Index + ", Type = " + Type + ", BTHome_Device = false");

			#region Convert String to Device Type
			t = Convert_To_Device_Type(Type);
			if (t == Device_Types.Unknown)
			{
				return 0;
			}
			#endregion

			#region Validate IP Address
			if (Validate_IP_Address(IP_Address, "Send_Command") == false)
			{
				return 0;
			}
			#endregion

			#region Add to List of Devices
			Device device = new Device("", IP_Address, Index, t, false);
			device.Sensors = null;
			UDP_Message.Devices.Add(device);
			#endregion

			return 1;
		}

		//****************************************************************************************
		// 
		//  Get_BLU_Sensor_States	-	Called at startup to get current state
		//								of all sensors
		// 
		//****************************************************************************************
		public static void Get_BLU_Sensor_States()
		{
			string Speed_0, Speed_1;

			foreach (Sensor sensor in UDP_Message.Sensors)
			{
				HttpClient client = null;

				string url = "http://" + sensor.Gateway_IP + "/rpc/BTHomeSensor.GetStatus?id=" + sensor.Sensor_Channel.ToString();
				Debug_Message("Get_BLU_Sensor_States", "id = " + sensor.Device_Channel + ", type = " + sensor.Type.ToString() + ", url = " + url);

				try
				{
					//Create http client
					client = new HttpClient();
					//client.Verbose = true;
					HttpClientRequest request = new HttpClientRequest();
					HttpClientResponse response;

					//Send http client request
					request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
					request.KeepAlive = false;
					request.Url.Parse(url);

					//Get response
					response = client.Dispatch(request);
					if (response.Code < 200 || response.Code >= 300)
					{
						// server threw a error.
						string err = "Shelly Gen2+ - Get_BLU_Sensor_States - http response code: " + response.Code;
						CrestronConsole.PrintLine(err);
						Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					}
					else
					{
						Debug_Message("Get_BLU_Sensor_States", "Success - response.ContentString = " + response.ContentString);
						string s = response.ContentString;
						s = UDP_Message.Parse_Data_Substring(s, "", "\"value\":", ",");
						if (string.IsNullOrEmpty(s) == false)
						{
							switch (sensor.Type)
							{
								case Device_Types.Set_Point:
									string Set_Point_C = s;
									string Set_Point_F = Convert_Temperature_C_to_F(Set_Point_C, 1);
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Set Point - Value = " + Set_Point_C.ToString());
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", Set_Point_C, Set_Point_F, 999, "", 999, "", "", 999, 999, "", "", "", "", "",
									"", "", "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Temperature:
									string Temperature_C = s;
									string Temperature_F = HTTP_Send.Convert_Temperature_C_to_F(Temperature_C, 1);
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Temperature - Value = " + Temperature_C.ToString());
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, Temperature_C,
									Temperature_F, "", "", "", 999, "", 999, "", "", 999, 999, "", "", "", "", "",
									"", "", "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Humidity:
									string Relative_Humidity = s;
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Humidity - Value = " + Relative_Humidity.ToString());
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", Relative_Humidity, "", "", 999, "", 999, "", "", 999, 999, "", "", "", "", "",
									"", "", "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Battery:
									short Battery_Percent = short.Parse(s);
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Battery - Value = " + Battery_Percent.ToString());
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", Battery_Percent, "", "", 999, 999, "", "", "", "", "", "",
									"", "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Door_Window:
									short Window_State = (short)((s == "true") ? 1 : 0);
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Door/Window - Value = " + Window_State);
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, "", "", Window_State, 999, "", "", "", "", "", "",
									"", "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Illuminance:
									string Illuminance = s;
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Illuminance - Value = " + Illuminance);
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, Illuminance, "", 999, 999, "", "", "", "", "", "",
									"", "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Rotation:
									string Rotation = s;
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Door/Window - Value = " + Rotation);
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, "", Rotation, 999, 999, "", "", "", "", "", "",
									"", "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Motion:
									short Motion = (short)((s == "true") ? 1 : 0);
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Motion - Value = " + Motion);
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, "", "", 999, Motion, "", "", "", "", "", "",
									"", "", "", 999, 999, "", 0, 0, "", "");
									break;
								
								case Device_Types.Moisture:
									string Moisture = s;
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Moisture - Value = " + Moisture);
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, "", "", 999, 999, "", Moisture, "", "", "", "", "",
									"", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Speed:
									if (sensor.Sensor_Index == 0)
									{
										Speed_0 = s;
										Speed_1 = "";
										Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Speed_0 - Value = " + Speed_0);
									}
									else
									{
										Speed_1 = s;
										Speed_0 = "";
										Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Speed_1 - Value = " + Speed_1);
									}
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, "", "", 999, 999, "", "", Speed_0, Speed_1, "", "", "", "",
									"", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.UV_Index:
									string UV_Index = s;
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - UV_Index - Value = " + UV_Index);
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, "", "", 999, 999, "", "", "", UV_Index, "", "", "", "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Direction:
									string Direction = s;
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Direction - Value = " + Direction);
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, "", "", 999, 999, "", "", "", "", Direction, "", "", "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Precipitation:
									string Precipitation = s;
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Precipitation - Value = " + Precipitation);
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, "", "", 999, 999, "", "", "", "", "", Precipitation, "", "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Dewpoint:
									string Dewpoint = s;
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Dewpoint - Value = " + Dewpoint);
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, "", "", 999, 999, "", "", "", "", "", "", Dewpoint, "", "", 999, 999, "", 0, 0, "", "");
									break;

								case Device_Types.Pressure:
									string Pressure = s;
									Debug_Message("Get_BLU_Sensor_States", "BTHome Sensor - ID = " + sensor.Device_Channel + " - Pressure - Value = " + Pressure);
									SignalChangeEvents.SerialValueChange(sensor.Gateway_IP, sensor.Device_Channel, 999, "", DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
									"", "", "", "", 999, "", 999, "", "", 999, 999, "", "", "", "", "", "", "", "", Pressure, 999, 999, "", 0, 0, "", "");
									break;

								default:
									Debug_Message("Get_BLU_Sensor_States", "Unsupported Type - " + sensor.Type.ToString() + " - Sensor - ID = " + sensor.Sensor_Channel + " - Value = " + s);
									break;
							}
						}
					}
				}
				catch (Exception e)
				{
					string err = "Shelly Gen2+ - Get_BLU_Sensor_States - Error Sending Device Command: " + e;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				finally
				{
					if (client != null)
					{
						client.Dispose();
					}
				}
			}
		}

		//****************************************************************************************
		// 
		//  Set_Device_Init_Complete	-	Start acceping UDP messages
		// 
		//****************************************************************************************
		public static void Set_Device_Init_Complete()
		{
			Debug_Message("Set_Device_Init_Complete", "");
			UDP_Message.Device_Init_Complete = true;
		}

		//****************************************************************************************
		// 
		//  Convert_Temperature_C_to_F	-	Convert from Celcius to Fahrenheit
		// 
		//****************************************************************************************
		public static string Convert_Temperature_C_to_F(string Temperature, int Digits)
		{
			double tC = double.Parse(Temperature);
			double tF = (tC * 1.8) + 32;
			tF = Math.Round(tF, Digits);
			return tF.ToString();
		}

		//****************************************************************************************
		// 
		//  Convert_Temperature_F_to_C	-	Convert from Fahrenheit to Celcius
		// 
		//****************************************************************************************
		public static string Convert_Temperature_F_to_C(string Temperature, int Digits)
		{
			double tF = double.Parse(Temperature);
			double tC = (tF - 32) / 1.8;
			tC = Math.Round(tC, Digits);
			return tC.ToString();
		}

		//****************************************************************************************
		// 
		//  Convert_m3_to_liters	-	Convert from cubic meters to liters
		// 
		//****************************************************************************************
		public static string Convert_m3_to_liters(string m3)
		{
			double val = double.Parse(m3);
			val = val * 1000;
			return val.ToString();
		}

		//****************************************************************************************
		// 
		//  Convert_m3_to_gallons	-	Convert from cubic meters to gallons
		// 
		//****************************************************************************************
		public static string Convert_m3_to_gallons(string m3, int Digits)
		{
			double val = double.Parse(m3);
			val = val * 264.172;
			val = Math.Round(val, Digits);
			return val.ToString();
		}

		//****************************************************************************************
		// 
		//  Convert_kPa_to_PSI	-	
		// 
		//****************************************************************************************
		public static string Convert_kPa_to_PSI(string kPa, int Digits)
		{
			double val = double.Parse(kPa);
			val = val * .145038;
			val = Math.Round(val, Digits);
			return val.ToString();
		}

		//****************************************************************************************
		// 
		//  Convert_kPa_to_bar	-	
		// 
		//****************************************************************************************
		public static string Convert_kPa_to_bar(string kPa, int Digits)
		{
			double val = double.Parse(kPa);
			val = val / 100;
			val = Math.Round(val, Digits);
			return val.ToString();
		}

		//****************************************************************************************
		// 
		//  Validate_IP_Address	-	checks if a string contains a valid IP address
		// 
		//****************************************************************************************
		private bool Validate_IP_Address(string IP_Address, string Calling_Routine)
		{
			IPAddress address;

			try
			{
				address = IPAddress.Parse(IP_Address);
			}
			catch (Exception e)
			{
				string err = "Shelly - Validate_IP_Address - Called from: " + Calling_Routine + " - Invalid IP Address: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return false;
			}
			return true;
		}

		//****************************************************************************************
		// 
		//  Convert_To_Device_Type - Converts from string name to type
		// 
		//****************************************************************************************
		Device_Types Convert_To_Device_Type(string Type_Name)
		{
			Debug_Message("Convert_To_Device_Type", "Name = " + Type_Name);

			Type_Name = Type_Name.ToLower();

			if ((Type_Name == "alarm") || (Type_Name == "flood"))
			{
				return Device_Types.Alarm;
			}
			else if (Type_Name == "battery")
			{
				return Device_Types.Battery;
			}
			else if (Type_Name == "button")
			{
				return Device_Types.Button;
			}
			else if (Type_Name == "cover")
			{
				return Device_Types.Cover;
			}
			else if (Type_Name == "dewpoint")
			{
				return Device_Types.Dewpoint;
			}
			else if (Type_Name == "direction")
			{
				return Device_Types.Direction;
			}
			else if (Type_Name == "door/window")
			{
				return Device_Types.Door_Window;
			}
			else if (Type_Name == "em")
			{
				return Device_Types.EM;
			}
			else if (Type_Name == "h&t")
			{
				return Device_Types.H_and_T;
			}
			else if (Type_Name == "humidity")
			{
				return Device_Types.Humidity;
			}
			else if (Type_Name == "illuminance")
			{
				return Device_Types.Illuminance;
			}
			else if (Type_Name == "irrigation")
			{
				return Device_Types.Irrigation;
			}
			else if (Type_Name == "light")
			{
				return Device_Types.Light;
			}
			else if (Type_Name == "moisture")
			{
				return Device_Types.Moisture;
			}
			else if (Type_Name == "motion")
			{
				return Device_Types.Motion;
			}
			else if (Type_Name == "power_monitor")
			{
				return Device_Types.Power_Monitor;
			}
			else if (Type_Name == "precipitation")
			{
				return Device_Types.Precipitation;
			}
			else if (Type_Name == "pressure")
			{
				return Device_Types.Pressure;
			}
			else if (Type_Name == "rgb")
			{
				return Device_Types.RGB;
			}
			else if (Type_Name == "rotation")
			{
				return Device_Types.Rotation;
			}
			else if (Type_Name == "set_point")
			{
				return Device_Types.Set_Point;
			}
			else if (Type_Name == "speed")
			{
				return Device_Types.Speed;
			}
			else if (Type_Name == "switch")
			{
				return Device_Types.Switch;
			}
			else if (Type_Name == "switch_input")
			{
				return Device_Types.Switch_Input;
			}
			else if (Type_Name == "temperature")
			{
				return Device_Types.Temperature;
			}
			else if (Type_Name == "trv")
			{
				return Device_Types.TRV;
			}
			else if (Type_Name == "uv_index")
			{
				return Device_Types.UV_Index;
			}
			else if (Type_Name == "valve")
			{
				return Device_Types.Valve;
			}
			else if (Type_Name == "weather")
			{
				return Device_Types.Weather;
			}
			else if (Type_Name == "neo")
			{
				return Device_Types.Neo;
			}
			else if (Type_Name == "neo_flowrate")
			{
				return Device_Types.Neo_Flowrate;
			}
			else if (Type_Name == "neo_pressure")
			{
				return Device_Types.Neo_Pressure;
			}
			else if (Type_Name == "neo_temperature")
			{
				return Device_Types.Neo_Temperature;
			}
			else
			{
				Debug_Message("Convert_To_Device_Type", Type_Name + " is Unknown Device_Type");
				return Device_Types.Unknown;//unsupported device type
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private static void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			if (Show_Debug_Messages == false)
			{
				return;
			}

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((UDP_Message.Debug == Debug_Options.Console) || (UDP_Message.Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Shelly Gen2+ - " + Name + " - " + sub);
				}

				if ((UDP_Message.Debug == Debug_Options.Error_Log) || (UDP_Message.Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Shelly Gen2+ - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}

	//****************************************************************************************
	// 
	//  HTTP Response Data Semt by Shelly devices  
	// 
	//****************************************************************************************
	#region HTTP Classes
	public class HTTP_Response_Data
	{
		public int id { get; set; }
		public string source { get; set; }
		public bool output { get; set; }
		public double apower { get; set; }
		public double voltage { get; set; }
		public double freq { get; set; }
		public double current { get; set; }
		public double act_power { get; set; }
		public double aprt_power { get; set; }
		public double pf { get; set; }
		public Aenergy aenergy { get; set; }
		public RetAenergy ret_aenergy { get; set; }
		public int brightness { get; set; }
		public string state { get; set; }
		public int current_pos { get; set; }
		public int slat_pos { get; set; }
		public List<int> rgb { get; set; }
		public int white { get; set; }
		public Temperature temperature { get; set; }
		public Humidity humidity { get; set; }
		public double target_C { get; set; }
		public double current_C { get; set; }
		public int battery { get; set; }
		public int pos { get; set; }
		public double tC { get; set; }
		public double tF { get; set; }
		public double rh { get; set; }
		public double percent { get; set; }
		public int num_objects { get; set; }
	}
	#endregion
}
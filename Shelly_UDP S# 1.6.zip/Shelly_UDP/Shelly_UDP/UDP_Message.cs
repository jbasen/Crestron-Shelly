﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;
using Crestron.SimplSharp.Net.Https;
using Crestron.SimplSharp.CrestronSockets;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Shelly_UDP
{
	#region Enum
    public enum Debug_Options
    {
        None,								//Don't do anything with debug information
        Console,							//Output debug information to the console
        Error_Log,							//Send debug information to the error log
        Both								//Send debug infomation to both the console and error log
    };
	public enum Device_Types
	{
		Alarm,
		Battery,
		Button,
		Cover,
		Dewpoint,
		Direction,
		Door_Window,
		EM,
		H_and_T,
		Humidity,
		Illuminance,
		Irrigation,
		Light,
		Moisture,
		Motion,
		Power_Monitor,
		Precipitation,
		Pressure,
		RGB,
		Rotation,
		Set_Point,
		Speed,
		Switch,
		Switch_Input,
		Temperature,
		TRV,
		UV_Index,
		Valve,
		Weather,
		Neo,
		Neo_Flowrate,
		Neo_Pressure,
		Neo_Temperature,
		Unknown
	}
    #endregion

	#region S+ Pass Back Classes
	//Event Classes
	public class SerialChangeEventArgs : EventArgs
	{
		public string Device_IP { get; set; }
		public short Channel { get; set; }
		public ushort Index { get; set; }
		public string Name { get; set; }
		public string Last_Update { get; set; }
		public short Output_Is_On { get; set; }
		public string Power { get; set; }
		public string Voltage { get; set; }
		public string Frequency { get; set; }
		public string Current { get; set; }
		public string aenergy { get; set; }
		public string ret_aenergy { get; set; }
		public short Input_State { get; set; }
		public string act_power { get; set; }
		public string aprt_power { get; set; }
		public string pf { get; set; }
		public string total_act_energy { get; set; }
		public string total_act_ret_energy { get; set; }
		public short Brightness { get; set; }
		public string state { get; set; }
		public short position { get; set; }
		public short slat_position { get; set; }
		public string dev_event { get; set; }
		public short Red { get; set; }
		public short Green { get; set; }
		public short Blue { get; set; }
		public short White { get; set; }
		public string Temperature_C { get; set; }
		public string Temperature_F { get; set; }
		public string Relative_Humidity { get; set; }
		public string Set_Point_C { get; set; }
		public string Set_Point_F { get; set; }
		public short Alarm { get; set; }
		public string Battery_Voltage { get; set; }
		public short Battery_Percent { get; set; }
		public string Illuminance { get; set; }
		public string Rotation { get; set; }
		public short Window_State { get; set; }
		public short Motion { get; set; }
		public string BTH_Sensor_Value { get; set; }
		public string Moisture { get; set; }
		public string Speed_0 { get; set; }
		public string Speed_1 { get; set; }
		public string UV_Index { get; set; }
		public string Direction { get; set; }
		public string Precipitation { get; set; }
		public string Dewpoint { get; set; }
		public string Pressure { get; set; }
		public short Value { get; set; }
		public short Count { get; set; }
		public string Percent { get; set; }
		public short Device_Channel { get; set; }
		public short Steps { get; set; }
		public string Number { get; set; }
		public string Number1 { get; set; }

		public SerialChangeEventArgs()
		{
		}

		public SerialChangeEventArgs(string Device_IP, short Channel, ushort Index, string Name, string Last_Update, short Output_Is_On,
			string Power, string Voltage, string Frequency, string Current, string aenergy, string ret_aenergy, short Input_State,
			string act_power, string aprt_power, string pf, string total_act_energy, string total_act_ret_energy, short Brightness,
			string state, short position, short slat_position, string dev_event, short Red, short Green, short Blue, short White, 
			string Temperature_C, string Temperature_F, string Relative_Humidity, string Set_Point_C, string Set_Point_F, short Alarm, 
			string Battery_Voltage, short Battery_Percent, string Illuminance, string Rotation, short Window_State, short Motion, 
			string BTH_Sensor_Value, string Moisture, string Speed_0, string Speed_1, string UV_Index, string Direction,
			string Precipitation, string Dewpoint, string Pressure, short Value, short Count, string Percent, short Device_Channel,
			short Steps, string Number, string Number1)
		{
			#region Set Class Data Elements from Parameters
			this.Device_IP = Device_IP;
			this.Name = Name;
			this.Channel = Channel;
			this.Index = Index;
			this.Last_Update = Last_Update;
			this.Output_Is_On = Output_Is_On;
			this.Power = Power;
			this.Voltage = Voltage;
			this.Frequency = Frequency;
			this.Current = Current;
			this.aenergy = aenergy;
			this.ret_aenergy = ret_aenergy;
			this.Input_State = Input_State;
			this.act_power = act_power;
			this.aprt_power = aprt_power;
			this.pf = pf;
			this.total_act_energy = total_act_energy;
			this.total_act_ret_energy = total_act_ret_energy;
			this.Brightness = Brightness;
			this.state = state;
			this.position = position;
			this.slat_position = slat_position;
			this.dev_event = dev_event;
			this.Red = Red;
			this.Green = Green;
			this.Blue = Blue;
			this.Temperature_C = Temperature_C;
			this.Temperature_F = Temperature_F;
			this.Relative_Humidity = Relative_Humidity;
			this.Set_Point_C = Set_Point_C;
			this.Set_Point_F = Set_Point_F;
			this.Alarm = Alarm;
			this.Battery_Voltage = Battery_Voltage;
			this.Battery_Percent = Battery_Percent;
			this.Illuminance = Illuminance;
			this.Rotation = Rotation;
			this.Window_State = Window_State;
			this.Motion = Motion;
			this.BTH_Sensor_Value = BTH_Sensor_Value;
			this.Moisture = Moisture;
			this.Speed_0 = Speed_0;
			this.Speed_1 = Speed_1;
			this.UV_Index = UV_Index;
			this.Direction = Direction;
			this.Precipitation = Precipitation;
			this.Dewpoint = Dewpoint;
			this.Pressure = Pressure;
			this.Value = Value;
			this.Count = Count;
			this.Percent = Percent;
			this.Device_Channel = Device_Channel;
			this.Steps = Steps;
			this.Number = Number;
			this.Number1 = Number1;
			#endregion
		}
	}

	public static class SignalChangeEvents
	{
		public static event SerialChangedEventHandler onSerialValueChange;

		public static void SerialValueChange(string Device_IP, short Channel, ushort Index, string Name, string Last_Update, short Output_Is_On,
			string Power, string Voltage, string Frequency, string Current, string aenergy, string ret_aenergy, short Input_State, string act_power,
			string aprt_power, string pf, string total_act_energy, string total_act_ret_energy, short Brightness, string state, short position,
			short slat_position, string dev_event, short Red, short Green, short Blue, short White, string Temperature_C, string Temperature_F,
			string Relative_Humidity, string Set_Point_C, string Set_Point_F, short Alarm, string Battery_Voltage, short Battery_Percent,
			string Illuminance, string Rotation, short Window_State, short Motion, string BTH_Sensor_Value, string Moisture, string Speed_0,
			string Speed_1, string UV_Index, string Direction, string Precipitation, string Dewpoint, string Pressure, short Value, short Count,
			string Percent, short Device_Channel, short Steps, string Number, string Number1)
		{
			SignalChangeEvents.onSerialValueChange(new SerialChangeEventArgs(Device_IP, Channel, Index, Name, Last_Update, Output_Is_On,
				Power, Voltage, Frequency, Current, aenergy, ret_aenergy, Input_State, act_power, aprt_power, pf, total_act_energy, total_act_ret_energy, Brightness,
				state, position, slat_position, dev_event, Red, Green, Blue, White, Temperature_C, Temperature_F, Relative_Humidity, Set_Point_C, Set_Point_F,
				Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value, Moisture, Speed_0, Speed_1, UV_Index, Direction,
				Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, Number, Number1));
		}
	}
	#endregion

	#region UPD Classes

	public class UDP_Message_Data
	{
		public string src { get; set; }
		public string dst { get; set; }
		public string method { get; set; }
		public Params @params { get; set; }
		public Error error { get; set; }
	}

	public class Params
	{
		public double ts { get; set; }
		public Wifi wifi { get; set; }
		public Cloud cloud { get; set; }
		public List<Shelly_Event> events { get; set; }
	}

	public class Wifi
	{
		public int rssi { get; set; }
		public string ssid { get; set; }
		public string sta_ip { get; set; }
		public string status { get; set; }
	}

	public class Cloud
	{
		public bool connected { get; set; }
	}

	public class Shelly_Switch
	{
		public Aenergy aenergy { get; set; }
		public double? apower { get; set; }
		public double? current { get; set; }
		public double? freq { get; set; }
		public RetAenergy ret_aenergy { get; set; }
		public double? voltage { get; set; }
		public bool output { get; set; }
		public string source { get; set; }
	}

	public class Aenergy
	{
		public List<double> by_minute { get; set; }
		public int minute_ts { get; set; }
		public double total { get; set; }
	}

	public class RetAenergy
	{
		public List<double> by_minute { get; set; }
		public int minute_ts { get; set; }
		public double total { get; set; }
	}

	public class Shelly_Event
	{
		public string component { get; set; }
		public int id { get; set; }
		public string @event { get; set; }
		public int? steps { get; set; }
		public int idx { get; set; }
		public int? channel { get; set; }
		public bool value { get; set; }
		public string illumination { get; set; }
		public int num_objects { get; set; }
		public double ts { get; set; }
	}

	public class Input
	{
		public int id { get; set; }
		public bool state { get; set; }
		public double percent { get; set; }
	}

	public class Voltmeter
	{
		public double voltage { get; set; }
	}

	public class Em1data
	{
		public int id { get; set; }
		public double total_act_energy { get; set; }
		public double total_act_ret_energy { get; set; }
	}

	public class Em
	{
		public int id { get; set; }
		public double act_power { get; set; }
		public double aprt_power { get; set; }
		public double current { get; set; }
		public double freq { get; set; }
		public double pf { get; set; }
		public double voltage { get; set; }
	}

	public class Light
	{
		public int brightness { get; set; }
		public bool output { get; set; }
		public double apower { get; set; }
		public double current { get; set; }
		public double voltage { get; set; }
		public string source { get; set; }
		public Aenergy aenergy { get; set; }
	}

	public class Cover
	{
		public int id { get; set; }
		public int apower { get; set; }
		public int current { get; set; }
		public object move_started_at { get; set; }
		public object move_timeout { get; set; }
		public int pf { get; set; }
		public string source { get; set; }
		public string state { get; set; }
		public int current_pos { get; set; }
		public int slat_pos { get; set; }
		public Aenergy aenergy { get; set; }
	}

	public class RGB
	{
		public int id { get; set; }
		public int brightness { get; set; }
		public bool output { get; set; }
		public List<int> rgb { get; set; }
		public string source { get; set; }
		public double apower { get; set; }
		public double current { get; set; }
		public double voltage { get; set; }
		public Aenergy aenergy { get; set; }
	}

	public class RGBW
	{
		public int id { get; set; }
		public int brightness { get; set; }
		public bool output { get; set; }
		public List<int> rgb { get; set; }
		public int white { get; set; }
		public string source { get; set; }
		public double apower { get; set; }
		public double current { get; set; }
		public double voltage { get; set; }
		public Aenergy aenergy { get; set; }
	}

	public class Temperature
	{
		public int id { get; set; }
		public double tC { get; set; }
		public double tF { get; set; }
	}

	public class Humidity
	{
		public int id { get; set; }
		public double rh { get; set; }
	}

	public class Blutrv
	{
		public double current_C { get; set; }
		public int pos { get; set; }
		public int rsv { get; set; }
		public int battery { get; set; }
	}

	public class Bthomesensor
	{
		public int last_updated_ts { get; set; }
	}

	public class Error
	{
		public int code { get; set; }
		public string message { get; set; }
	}

	public class Battery
	{
		public double V { get; set; }
		public int percent { get; set; }
	}

	public class Devicepower
	{
		public int id { get; set; }
		public Battery battery { get; set; }
	}

	public class Flood
	{
		public int id { get; set; }
		public bool alarm { get; set; }
		public bool mute { get; set; }
	}

	public class Boolean
	{
		public int id { get; set; }
		public string source { get; set; }
		public bool value { get; set; }
	}

	public class Number
	{
		public int id { get; set; }
		public string source { get; set; }
		public short value { get; set; }
	}

	public class UDP_Obj
	{
		public Value value { get; set; }
	}

	public class Value
	{
		public Counter counter { get; set; }
	}

	public class Counter
	{
		public double total { get; set; }
	}

	#endregion

	#region Device Classes
	public class Sensor
	{
		public short Sensor_Channel { get; set; }
		public int Sensor_Index { get; set; }
		public short Device_Channel { get; set; }
		public string Gateway_IP { get; set; }
		public Device_Types Type { get; set; }

		//Constructors
		public Sensor()
		{
		}

		public Sensor(string Gateway_IP, short Sensor_Channel, int Sensor_Index, short Device_Channel, Device_Types Type)
		{
			this.Gateway_IP = Gateway_IP;
			this.Sensor_Channel = Sensor_Channel;
			this.Sensor_Index = Sensor_Index;
			this.Device_Channel = Device_Channel;
			this.Type = Type;
		}
	}

	public class Device
	{
		public string Name { get; set; }
		public string IP_Address { get; set; }
		public short Channel { get; set; }
		public Device_Types Type { get; set; }
		public bool BTHome_Device { get; set; }
		public List<Sensor> Sensors { get; set; }

		//Constructors
		public Device()
		{
		}

		public Device(string Name, string IP_Address, short Channel, Device_Types Type, bool BTHome_Device)
		{
			this.Name = Name;
			this.IP_Address = IP_Address;
			this.Channel = Channel;
			this.Type = Type;
			this.Sensors = new List<Sensor>();
			this.BTHome_Device = BTHome_Device;
		}
	}

	public class Obj
	{
		public int obj_id { get; set; }
		public int idx { get; set; }
		public string component { get; set; }
	}

	public class BTHomeDevice
	{
		public int id { get; set; }
		public List<Obj> objects { get; set; }
	}
	#endregion

	#region Delegates
	public delegate void SerialChangedEventHandler(SerialChangeEventArgs e);
	#endregion

	public class UDP_Message
    {
        #region Declarations
        private static UDPServer UDP_Server = null;
        private int Shelly_UDP_Port;
        public static Debug_Options Debug;
		public static string Startup_Debug_Device_IP;
		private static bool Show_Debug_Messages;
		public static List<Device> Devices;
		public static List<Sensor> Sensors;
		public static bool Device_Init_Complete = false;
		#endregion Declarations
		
        //****************************************************************************************
        // 
        //  UDP_Message	-	Constructor
        // 
        //****************************************************************************************
        public UDP_Message()
        {
        }

        //****************************************************************************************
        // 
        //  UDP_Message	-	Destructor
        // 
        //****************************************************************************************
        ~UDP_Message()
        {
            if (UDP_Server != null)
            {
                UDP_Server.DisableUDPServer();
                UDP_Server.Dispose();
            }
        }

        //****************************************************************************************
        // 
        //  UDP_Initialization	-	Called from s+ to start data collection through
        //							UPD Messages from Station
        // 
        //****************************************************************************************
        public short UDP_Initialization(string Port, short Debug, string Startup_Debug_Device_IP)
        {
			Set_Debug_Message_Output(Debug);

			#region Validate Startup Debug IP 
			if (String.IsNullOrEmpty(Startup_Debug_Device_IP) == false)
			{
				Show_Debug_Messages = true;
				if (Validate_IP_Address(Startup_Debug_Device_IP, "UDP_Initialization") == false)
				{
					Debug_Message("UDP_Initialization", "Invalid Startup Debug Device IP = " + Startup_Debug_Device_IP);
					return 0;
				}
			}
			UDP_Message.Startup_Debug_Device_IP = Startup_Debug_Device_IP;
			#endregion

			#region Create list for each bluetooth device in sytem to be registered
			try
			{
				Devices = new List<Device>();
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Shelly - UDP_Initialization - Initialize - Can't create device list: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Shelly - UDP_Initialization - Initialize - Can't create device list: " + e + "\n");
				return 0;
			}
			#endregion

			#region Create list for each bluetooth sensor in sytem to be registered
			try
			{
				Sensors = new List<Sensor>();
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Shelly - UDP_Initialization - Initialize - Can't create sensor list: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Shelly - UDP_Initialization - Initialize - Can't create sensor list: " + e + "\n");
				return 0;
			}
			#endregion

			Shelly_UDP_Port = int.Parse(Port);

            Start_UDP_Receiver(Shelly_UDP_Port);

            return 1;
        }

        //****************************************************************************************
        // 
        //  Start_UDP_Receiver	-	Startup Receiver to receive UDP Messages
        // 
        //****************************************************************************************
        private void Start_UDP_Receiver(int UDP_Port)
        {
            try
            {
                UDP_Server = new UDPServer(IPAddress.Any, UDP_Port, 20000);
                UDP_Server.EnableUDPServer();
                UDP_Server.ReceiveDataAsync(UDP_Receiver_Packet_Received);
            }
            catch (Exception ex)
            {
                string err = "Shelly - Start_UDP_Receiver - Error Starting UDP Receiver: " + ex;
                CrestronConsole.PrintLine(err);
                Crestron.SimplSharp.ErrorLog.Error(err + "\n");
            }
        }

        //****************************************************************************************
        // 
        //  UDP_Receiver_Packet_Received	-	Parse Data Element from Json
        // 
        //****************************************************************************************
        private void UDP_Receiver_Packet_Received(UDPServer my_UDP_Server, int Byte_Count)
        {
            String JSON = "";
			UDP_Message_Data Data;
			string Device_IP_Address = my_UDP_Server.IPAddressLastMessageReceivedFrom;
			Show_Debug_Messages = String.IsNullOrEmpty(Startup_Debug_Device_IP) || (Startup_Debug_Device_IP == Device_IP_Address);

			try
			{
				if (Device_Init_Complete == false)
				{
					Debug_Message("UDP_Receiver_Packet_Received", "Device_Init_Complete = false, Can't Process Messages");
					return;
				}

				Byte[] bytes = (new List<byte>(my_UDP_Server.IncomingDataBuffer)).ToArray();
				JSON = System.Text.Encoding.ASCII.GetString(bytes, 0, Byte_Count);

				//Ignore signal strength messages
				if (JSON.IndexOf("\"rssi\":") != -1)
				{
					return;
				}

				Debug_Message("UDP_Receiver_Packet_Received", "Number of Bytes Received: " + Byte_Count + ", From: " + my_UDP_Server.IPAddressLastMessageReceivedFrom);
				Debug_Message("UDP_Receiver_Packet_Received", "Data: " + JSON);

				#region Parse message
				if ((String.IsNullOrEmpty(JSON) == false) && (Byte_Count > 0))
				{
					Data = Parse(JSON);

					if (Data != null)
					{
						#region Pass Back Data to Simplwin
						Pass_Back_UDP_Response_Data(Device_IP_Address, Data, JSON);
						#endregion
					}
					else
					{
						Debug_Message("UDP_Receiver_Packet_Received", "Parse Returned null");
					}
				}
				#endregion
			}
			catch (Exception ex)
			{
				#region Save Exception Data
				string err = "Shelly - UDP_Receiver_Packet_Received - Error Retreiving UDP_Message: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("Shelly - UDP_Receiver_Packet_Received - \n" + ex.StackTrace);
				CrestronConsole.PrintLine("Shelly - UDP_Receiver_Packet_Received - JSON: " + JSON + "\n");
				#endregion
			}
			finally
			{
				my_UDP_Server.ReceiveDataAsync(UDP_Receiver_Packet_Received);
			}
        }

        //****************************************************************************************
        // 
        //  Parse	-   Parse UDP Message
        // 
        //****************************************************************************************
        private UDP_Message_Data Parse(string JSON)
        {
			Debug_Message("Parse", "JSON = " + JSON);

            #region Fix Json So Newtonsoft Can Parse It
			if (JSON.IndexOf("\"object\":") != -1)//Can't Parse Reserved Word Object
			{
				JSON = JSON.Replace("\"object\":", "\"ObjectCoordinates\":");
			}
            //JSON = JSON.Replace("[[", "["); TESTER Removed for Presence Sensor Gen4 - Can't Find What Required It
            //JSON = JSON.Replace("]]", "]"); TESTER Removed for Presence Sensor Gen4 - Can't Find What Required It
			Debug_Message("Parse", "Revised JSON = " + JSON);
			#endregion Fix Json So Newtonsoft Can Parse It

            try
            {
                UDP_Message_Data item = JsonConvert.DeserializeObject<UDP_Message_Data>(JSON);

                #region Validate Parsing
                if (item == null)
                {
					Debug_Message("Parse", "Error Parsing JSON = " + JSON);
                    return null;
                }
                else
                {
					Debug_Message("Parse", "Successfully Parsed JSON");
                }
                #endregion Validate Parsing

                return item;
            }
            catch (Exception ex)
            {
				string err = "Shelly - Parse - Parsing JSON: " + ex;
                CrestronConsole.PrintLine(err);
                Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("Shelly - Parse - Parsing JSON - \n" + JSON);
				CrestronConsole.PrintLine("Shelly - Parse - Parsing JSON - \n" + ex.StackTrace);
                return null;
            }
        }

		//****************************************************************************************
		// 
		//  Pass_Back_HTTP_Response_Data	-	Pass data back to S+
		// 
		//****************************************************************************************
		private void Pass_Back_UDP_Response_Data(string Device_IP, UDP_Message_Data Data, string JSON)
		{
			Debug_Message("Pass_Back_UDP_Response_Data", "Device_IP = " + Device_IP + ", JSON = " + JSON);

			#region Declarations
			int Start_Index;
			string s;
			short Output = 999;
			short Channel = 999;
			ushort Index = 999;
			string Power = "";
			string Voltage = "";
			string Frequency = "";
			string Current = "";
			string Aenergy = "";
			string Ret_Aenergy = "";
			short Input_State = 999;
			string Act_Power = "";
			string Aprt_Power = "";
			string Power_Factor = "";
			string Total_Act_Energy = "";
			string Total_Act_Ret_Energy = "";
			short Brightness = 999;
			string State = "";
			short Current_Position = 999;
			short Slat_Position = 999;
			string Dev_Event = "";
			short Red = 999;
			short Green = 999;
			short Blue = 999;
			short White = 999;
			string Temperature_C = "";
			string Temperature_F = "";
			string Relative_Humidity = "";
			string Set_Point_C = "";
			string Set_Point_F = "";
			short Alarm = 999;
			string Battery_Voltage = "";
			short Battery_Percent = 999;
			string Illuminance = "";
			string Rotation = "";
			short Window_State = 999;
			string BTH_Sensor_Value = "";
			short Sensor_Channel;
			short Motion = 999;
			string Moisture = "";
			string Speed_0 = "";
			string Speed_1 = "";
			string UV_Index = "";
			string Direction = "";
			string Precipitation = "";
			string Dewpoint = "";
			string Pressure = "";
			short Value = 999;
			short Count = 999;
			string Percent = "";
			short Device_Channel = 0;
			short Steps = 999;
			string Number = "";
			string Number1 = "";
			#endregion

			try
			{
				if (Data.error != null)
				{
					#region Error
					Debug_Message("Pass_Back_UDP_Response_Data", "Data.Error JSON = " + JSON);
					return;
					#endregion
				}
				else if (JSON.IndexOf("\"method\":\"NotifyEvent\"") != -1)
				{
					#region Events
					Debug_Message("Pass_Back_UDP_Response_Data", "Events");
					if (Data.@params.events != null)
					{
						foreach (Shelly_Event ev in Data.@params.events)
						{
							if (GetRegexIndex(ev.component, @"input:\d+") != -1)
							{
								Debug_Message("Pass_Back_UDP_Response_Data", "input event, Channel = " + ev.id + ", Event = " + ev.@event);
								Channel = (short)ev.id;
								Dev_Event = ev.@event;
								SignalChangeEvents.SerialValueChange(Device_IP, Channel, 999, Data.src, DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, Dev_Event, 999, 999, 999, 999, "", "", "",
									"", "", 999, "", 999, "", "", 999, 999, BTH_Sensor_Value, Moisture, Speed_0, Speed_1, UV_Index, Direction,
									Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
							}
							else if (GetRegexIndex(ev.component, @"presencezone:\d+") != -1)
							{
								Debug_Message("Pass_Back_UDP_Response_Data", "presencezone event, Channel = " + ev.id + ", Event = " + ev.@event);
								Channel = (short)ev.id;
								Dev_Event = ev.@event;
								Value = (short) ((ev.value == true) ? 1 : 0);
								Illuminance = ev.illumination;
								if ((string.IsNullOrEmpty(ev.@event) == false) && (ev.@event == "counter"))
								{
									Count = (short) ev.num_objects;
								}
								Debug_Message("Pass_Back_UDP_Response_Data", "presencezone event, Channel = " + ev.id + ", Value = " + Value + ", Illuminance = " + Illuminance + ", Count = " + Count);
								SignalChangeEvents.SerialValueChange(Device_IP, Channel, 999, Data.src, DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, Dev_Event, 999, 999, 999, 999, "", "", "",
									"", "", 999, "", 999, Illuminance, "", 999, 999, BTH_Sensor_Value, Moisture, Speed_0, Speed_1, UV_Index, Direction,
									Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
							}
							else if ((string.IsNullOrEmpty(ev.component) == false) && (ev.component.IndexOf("bthomedevice:") != -1))
							{
								Debug_Message("Pass_Back_UDP_Response_Data", "bthomedevice event, Channel = " + ev.id + ", Event = " + ev.@event);
								Channel = (short)ev.id;
								Dev_Event = ev.@event;
								Index = (ushort) ev.idx;
								if ((ev.channel != null) && (ev.channel != -1))
								{
									Device_Channel = (short)ev.channel;
								}
								else
								{
									Device_Channel = 0;
								}
								if ((ev.steps != null) && (ev.steps != -1))
								{
									Steps = (short)ev.steps;
								}
								else
								{
									Steps = 0;
								}

								SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), 999,
									"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, Dev_Event, 999, 999, 999, 999, "", "", "",
									"", "", 999, "", 999, "", "", 999, 999, BTH_Sensor_Value, Moisture, Speed_0, Speed_1, UV_Index, Direction,
									Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
							}
						}
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"bthomesensor:\d+")) != -1)
				{
					#region bthomesensor

					#region Parse Sensor Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"bthomesensor:", "\"")))
					{
						return;
					}
					Sensor_Channel = short.Parse(s);
					Debug_Message("Pass_Back_UDP_Response_Data", "Sensor_Channel = " + Sensor_Channel);

					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Bthomesensor bthomesensor = JsonConvert.DeserializeObject<Bthomesensor>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "bthomesensor:" + Sensor_Channel + " = " + s);

					#region Collect Elements
					if ((bthomesensor != null) && (s.IndexOf("value") != -1))
					{
						BTH_Sensor_Value = Parse_Data_Substring(s, "", "\"value\":", "}");
					}
					#endregion

					#region Pass Back bthomesensor data
					if (Sensors.Exists(x => x.Sensor_Channel == Sensor_Channel))
					{
						Sensor sensor = Sensors.Find(x => x.Sensor_Channel == Sensor_Channel);
						if ((sensor.Type == Device_Types.Set_Point) && (BTH_Sensor_Value != ""))//Set Point in Celcius
						{
							Set_Point_C = BTH_Sensor_Value;
							Set_Point_F = HTTP_Send.Convert_Temperature_C_to_F(Set_Point_C, 1);
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Set Point - Value = " + Set_Point_C.ToString());
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", Set_Point_C, Set_Point_F, 999, "", 999, "", "", 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Temperature) && (BTH_Sensor_Value != ""))//Temperature in Celcius
						{
							Temperature_C = BTH_Sensor_Value;
							Temperature_F = HTTP_Send.Convert_Temperature_C_to_F(Temperature_C, 1);
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Temperature - Value = " + Temperature_C.ToString());
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, Temperature_C,
							Temperature_F, "", "", "", 999, "", 999, "", "", 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Humidity) && (BTH_Sensor_Value != ""))//Humidity
						{
							Relative_Humidity = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Humidity - Value = " + Relative_Humidity.ToString());
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", Relative_Humidity, "", "", 999, "", 999, "", "", 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Battery) && (BTH_Sensor_Value != ""))//Battery
						{
							Battery_Percent = short.Parse(BTH_Sensor_Value);
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Battery - Value = " + Battery_Percent.ToString());
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", Battery_Percent, "", "", 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Door_Window) && (BTH_Sensor_Value != ""))//Door/Window
						{
							Window_State = (short)((BTH_Sensor_Value == "true") ? 1 : 0);
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Door/Window - Value = " + Window_State);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", "", Window_State, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Illuminance) && (BTH_Sensor_Value != ""))//Illuminance
						{
							Illuminance = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Illuminance - Value = " + Illuminance);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, Illuminance, "", 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Rotation) && (BTH_Sensor_Value != ""))//Rotation
						{
							Rotation = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Rotation - Value = " + Rotation);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", Rotation, 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Motion) && (BTH_Sensor_Value != ""))//Motion
						{
							Motion = (short)((BTH_Sensor_Value == "true") ? 1 : 0);
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Motion - Value = " + Motion);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", "", 999, Motion, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Moisture) && (BTH_Sensor_Value != ""))//Moisture
						{
							Moisture = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Moisture - Value = " + Moisture);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", Rotation, 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Speed) && (BTH_Sensor_Value != "") && (sensor.Sensor_Index == 0))//Speed
						{
							Speed_0 = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Speed - Value = " + Speed_0);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", Rotation, 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Speed) && (BTH_Sensor_Value != "") && (sensor.Sensor_Index == 1))//Speed
						{
							Speed_1 = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Speed - Value = " + Speed_0);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", Rotation, 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.UV_Index) && (BTH_Sensor_Value != ""))//UV_Index
						{
							UV_Index = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - UV_Index - Value = " + UV_Index);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", Rotation, 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Direction) && (BTH_Sensor_Value != ""))//Direction
						{
							Direction = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Direction - Value = " + Direction);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", Rotation, 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Precipitation) && (BTH_Sensor_Value != ""))//Precipitation
						{
							Precipitation = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Precipitation - Value = " + Precipitation);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", Rotation, 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Dewpoint) && (BTH_Sensor_Value != ""))//Dewpoint
						{
							Dewpoint = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Dewpoint - Value = " + Dewpoint);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", Rotation, 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else if ((sensor.Type == Device_Types.Pressure) && (BTH_Sensor_Value != ""))//Pressure
						{
							Pressure = BTH_Sensor_Value;
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor - Pressure - Value = " + Pressure);
							SignalChangeEvents.SerialValueChange(Device_IP, sensor.Device_Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, "", 999, "", Rotation, 999, 999, "", Moisture, Speed_0, Speed_1, UV_Index, Direction,
							Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps, "", "");
						}
						else
						{
							Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor Type Not Supported" + sensor.Type.ToString());
						}
					}
					else
					{
						Debug_Message("Pass_Back_UDP_Response_Data", "BTHome Sensor Not found in List - Channel = " + Channel);
					}
					#endregion

					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"object:\d+")) != -1)
				{
					#region Object

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"object:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}

					UDP_Obj o = JsonConvert.DeserializeObject<UDP_Obj>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "object:" + Channel + " = " + s);

					if ((o != null) && (o.value != null) && (o.value.counter != null))
					{
						Number1 = o.value.counter.total.ToString();
					}
					else
					{
						Number1 = "";
					}

					SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
						Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
						Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
						Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
						Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
						"", Number1);

					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"boolean:\d+")) != -1)
				{
					#region Boolean

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"boolean:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Boolean b = JsonConvert.DeserializeObject<Boolean>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "boolean:" + Channel + " = " + s);

					#region Collect Value
					Value = (short)((b.value == true) ? 1 : 0);
					#endregion

					if (Value != 999)
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"number:\d+")) != -1)
				{
					#region Number

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"number:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}

					string t = ExtractNumericValueRegex(s);

					Debug_Message("Pass_Back_UDP_Response_Data", "number:" + Channel + " = " + t);

					if (t.Contains("."))
					{
						//Number being passed back is a double
						Number = t;
					}
					else
					{
						//Number being passed back is an integer
						Number n = JsonConvert.DeserializeObject<Number>(s);
						Value = n.value;
						Number = n.value.ToString();
					}
					#endregion

					if ((Value != 999) || (Number != ""))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							Number, "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"switch:\d+")) != -1)
				{
					#region Switch

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"switch:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Shelly_Switch Switch_Data = JsonConvert.DeserializeObject<Shelly_Switch>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "switch:" + Channel + " = " + s);

					#region Collect Elements
					if (s.IndexOf("output\":") != -1)
					{
						Output = (short)(Switch_Data.output == true ? 1 : 0);
					}
					if (s.IndexOf("apower\":") != -1)
					{
						Power = Switch_Data.apower.ToString();
					}
					if (s.IndexOf("voltage\":") != -1)
					{
						Voltage = Switch_Data.voltage.ToString();
					}
					if (s.IndexOf("freq\":") != -1)
					{
						Frequency = Switch_Data.freq.ToString();
					}
					if (s.IndexOf("current\":") != -1)
					{
						Current = Switch_Data.current.ToString();
					}
					if (Switch_Data.aenergy != null)
					{
						Aenergy = Switch_Data.aenergy.total.ToString();
					}
					if (Switch_Data.ret_aenergy != null)
					{
						Ret_Aenergy = Switch_Data.ret_aenergy.total.ToString();
					}
					#endregion

					if ((Output != 999) || (String.IsNullOrEmpty(Power) == false) || (String.IsNullOrEmpty(Voltage) == false) || (String.IsNullOrEmpty(Frequency) == false)
						|| (String.IsNullOrEmpty(Current) == false) || (String.IsNullOrEmpty(Aenergy) == false) || (String.IsNullOrEmpty(Ret_Aenergy) == false))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"pm1:\d+")) != -1)
				{
					#region PM1

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"pm1:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Shelly_Switch Switch_Data = JsonConvert.DeserializeObject<Shelly_Switch>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "pm1:" + Channel + " = " + s);

					#region Collect Elements
					if (s.IndexOf("apower\":") != -1)
					{
						Power = Switch_Data.apower.ToString();
					}
					if (s.IndexOf("voltage\":") != -1)
					{
						Voltage = Switch_Data.voltage.ToString();
					}
					if (s.IndexOf("freq\":") != -1)
					{
						Frequency = Switch_Data.freq.ToString();
					}
					if (s.IndexOf("current\":") != -1)
					{
						Current = Switch_Data.current.ToString();
					}
					if (Switch_Data.aenergy != null)
					{
						Aenergy = Switch_Data.aenergy.total.ToString();
					}
					if (Switch_Data.ret_aenergy != null)
					{
						Ret_Aenergy = Switch_Data.ret_aenergy.total.ToString();
					}
					#endregion

					if ((String.IsNullOrEmpty(Power) == false) || (String.IsNullOrEmpty(Voltage) == false) || (String.IsNullOrEmpty(Frequency) == false)
						|| (String.IsNullOrEmpty(Current) == false) || (String.IsNullOrEmpty(Aenergy) == false) || (String.IsNullOrEmpty(Ret_Aenergy) == false))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"input:\d+")) != -1)
				{
					#region Input

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"input:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Input Input_Data = JsonConvert.DeserializeObject<Input>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "input:" + Channel + " = " + s);

					#region Collect Elements
					if (s.IndexOf("state\":") != -1)
					{
						Input_State = (short)(Input_Data.state ? 1 : 0);
					}
					if (s.IndexOf("percent\":") != -1)
					{
						Percent = Input_Data.percent.ToString();
					}
					#endregion

					if ((Input_State != 999) || (string.IsNullOrEmpty(Percent) == false))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"voltmeter:\d+")) != -1)
				{
					#region Voltmeter

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"voltmeter:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Voltmeter Voltmeter_Data = JsonConvert.DeserializeObject<Voltmeter>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "input:" + Channel + " = " + s);

					#region Collect Elements
					if (s.IndexOf("voltage\":") != -1)
					{
						Voltage = Voltmeter_Data.voltage.ToString();
					}
					#endregion

					if (string.IsNullOrEmpty(Voltage) == false)
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"em1data:\d+")) != -1)
				{
					#region Em1data

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"em1data:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Em1data em1data = JsonConvert.DeserializeObject<Em1data>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "emidata:" + Channel + " = " + s);

					#region Collect Elements
					if (s.IndexOf("total_act_energy\":") != -1)
					{
						Total_Act_Energy = em1data.total_act_energy.ToString();
					}
					if (s.IndexOf("total_act_ret_energy\":") != -1)
					{
						Total_Act_Ret_Energy = em1data.total_act_ret_energy.ToString();
					}
					#endregion

					if ((String.IsNullOrEmpty(Total_Act_Energy) == false) || (String.IsNullOrEmpty(Total_Act_Ret_Energy) == false))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"em1:\d+")) != -1)
				{
					#region Em1
					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"em1:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Em em1 = JsonConvert.DeserializeObject<Em>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "switch:" + Channel + " = " + s);

					#region Collect Elements
					if (s.IndexOf("act_power\":") != -1)
					{
						Act_Power = em1.act_power.ToString();
					}
					if (s.IndexOf("aprt_power\":") != -1)
					{
						Aprt_Power = em1.aprt_power.ToString();
					}
					if (s.IndexOf("current\":") != -1)
					{
						Current = em1.current.ToString();
					}
					if (s.IndexOf("freq\":") != -1)
					{
						Frequency = em1.freq.ToString();
					}
					if (s.IndexOf("pf\":") != -1)
					{
						Power_Factor = em1.pf.ToString();
					}
					if (s.IndexOf("voltage\":") != -1)
					{
						Voltage = em1.voltage.ToString();
					}
					#endregion

					if ((String.IsNullOrEmpty(Act_Power) == false) || (String.IsNullOrEmpty(Aprt_Power) == false) || (String.IsNullOrEmpty(Current) == false)
						|| (String.IsNullOrEmpty(Frequency) == false) || (String.IsNullOrEmpty(Power_Factor) == false) || (String.IsNullOrEmpty(Voltage) == false))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
						Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
						Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
						Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
						Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
						"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"light:\d+")) != -1)
				{
					#region Light

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"light:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Light light = JsonConvert.DeserializeObject<Light>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "switch:" + Channel + " = " + s);

					#region Collect Elements
					if (s.IndexOf("output\":") != -1)
					{
						Output = (short)(light.output == true ? 1 : 0);
					}
					if (s.IndexOf("brightness\":") != -1)
					{
						Brightness = (short)(light.brightness);
					}
					if (s.IndexOf("apower\":") != -1)
					{
						Power = light.apower.ToString();
					}
					if (s.IndexOf("voltage\":") != -1)
					{
						Voltage = light.voltage.ToString();
					}
					if (s.IndexOf("current\":") != -1)
					{
						Current = light.current.ToString();
					}
					if (light.aenergy != null)
					{
						Aenergy = light.aenergy.total.ToString();
					}
					#endregion

					if ((Channel != 999) || (Output != 999) || (Brightness != 999) || (String.IsNullOrEmpty(Power) == false)
						|| (String.IsNullOrEmpty(Voltage) == false) || (String.IsNullOrEmpty(Current) == false) || (String.IsNullOrEmpty(Aenergy) == false))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"cover:\d+")) != -1)
				{
					#region Cover
					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"cover:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Cover cover = JsonConvert.DeserializeObject<Cover>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "cover:" + Channel + " = " + s);

					#region Collect Elements
					if (s.IndexOf("current_pos\":") != -1)
					{
						Current_Position = (short)cover.current_pos;
					}
					if (s.IndexOf("state\":") != -1)
					{
						State = cover.state;
					}
					if (s.IndexOf("apower\":") != -1)
					{
						Power = cover.apower.ToString();
					}
					if (s.IndexOf("current\":") != -1)
					{
						Current = cover.current.ToString();
					}
					if (cover.aenergy != null)
					{
						Aenergy = cover.aenergy.total.ToString();
					}
					if (s.IndexOf("slat_pos\":") != -1)
					{
						Slat_Position = (short)cover.slat_pos;
					}
					#endregion

					if ((Channel != 999) || (Current_Position != 999) || (String.IsNullOrEmpty(State) == false) || (String.IsNullOrEmpty(Power) == false)
					|| (String.IsNullOrEmpty(Current) == false) || (String.IsNullOrEmpty(Aenergy) == false) || (Slat_Position != 999))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"rgb:\d+")) != -1)
				{
					#region rgb

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"rgb:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					RGB rgb = JsonConvert.DeserializeObject<RGB>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "rgb:" + Channel + " = " + s);

					#region Collect Elements
					if (s.IndexOf("output\":") != -1)
					{
						Output = (short)(rgb.output == true ? 1 : 0);
					}
					if (s.IndexOf("brightness\":") != -1)
					{
						Brightness = (short)(rgb.brightness);
					}
					if (s.IndexOf("rgb:[") != -1)
					{
						Red = (short)(rgb.rgb[0]);
						Green = (short)(rgb.rgb[1]);
						Blue = (short)(rgb.rgb[2]);
					}
					if (s.IndexOf("apower\":") != -1)
					{
						Power = rgb.apower.ToString();
					}
					if (s.IndexOf("current\":") != -1)
					{
						Current = rgb.current.ToString();
					}
					if (s.IndexOf("voltage\":") != -1)
					{
						Voltage = rgb.voltage.ToString();
					}
					if (rgb.aenergy != null)
					{
						Aenergy = rgb.aenergy.total.ToString();
					}
					#endregion

					if ((Output != 999) || (Brightness != 999) || (String.IsNullOrEmpty(Power) == false)
						|| (String.IsNullOrEmpty(Voltage) == false) || (String.IsNullOrEmpty(Current) == false) || (String.IsNullOrEmpty(Aenergy) == false)
						|| (Red != 999) || (Green != 999) || (Blue != 999))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"rgbw:\d+")) != -1)
				{
					#region rgbw

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"rgbw:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					RGBW rgbw = JsonConvert.DeserializeObject<RGBW>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "rgb:" + Channel + " = " + s);

					#region Collect Elements
					if (s.IndexOf("output\":") != -1)
					{
						Output = (short)(rgbw.output == true ? 1 : 0);
					}
					if (s.IndexOf("brightness\":") != -1)
					{
						Brightness = (short)(rgbw.brightness);
					}
					if (s.IndexOf("rgbw:[") != -1)
					{
						Red = (short)(rgbw.rgb[0]);
						Green = (short)(rgbw.rgb[1]);
						Blue = (short)(rgbw.rgb[2]);
					}
					if (s.IndexOf("brightness\":") != -1)
					{
						Brightness = (short)(rgbw.white);
					}
					if (s.IndexOf("apower\":") != -1)
					{
						Power = rgbw.apower.ToString();
					}
					if (s.IndexOf("current\":") != -1)
					{
						Current = rgbw.current.ToString();
					}
					if (s.IndexOf("voltage\":") != -1)
					{
						Voltage = rgbw.voltage.ToString();
					}
					if (rgbw.aenergy != null)
					{
						Aenergy = rgbw.aenergy.total.ToString();
					}
					#endregion

					if ((Output != 999) || (Brightness != 999) || (String.IsNullOrEmpty(Power) == false)
						|| (String.IsNullOrEmpty(Voltage) == false) || (String.IsNullOrEmpty(Current) == false) || (String.IsNullOrEmpty(Aenergy) == false)
						|| (Red != 999) || (Green != 999) || (Blue != 999))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
							Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
							Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
							Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
							Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"blutrv:\d+")) != -1)
				{
					#region TRV
					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"blutrv:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Blutrv blutrv = JsonConvert.DeserializeObject<Blutrv>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "blutrv:" + Channel + " = " + s);

					#region Keep Name in Sync
					if (Devices.Exists(x => x.Channel == Channel && x.Type == Device_Types.TRV))
					{
						Device device = Devices.Find(x => x.Channel == Channel && x.Type == Device_Types.TRV);
						if (device.Name != Data.src)
						{
							device.Name = Data.src;
						}
					}
					#endregion

					#region Collect Elements
					if ((blutrv != null) && (s.IndexOf("current_C") != -1))
					{
						Temperature_C = blutrv.current_C.ToString();
						Temperature_F = HTTP_Send.Convert_Temperature_C_to_F(Temperature_C, 1);
						Battery_Percent = (short)blutrv.battery;
					}
					#endregion

					if ((Temperature_C != "") || (Battery_Percent != 999))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), 999,
						"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, Temperature_C,
						Temperature_F, "", Set_Point_C, Set_Point_F, 999, "", Battery_Percent, "", "", Window_State, Motion, BTH_Sensor_Value,
						Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
						"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"flood:\d+")) != -1)
				{
					#region Flood

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"flood:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Flood flood = JsonConvert.DeserializeObject<Flood>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "flood:" + Channel + " = " + s);

					#region Collect Elements
					Alarm = (short)(flood.alarm ? 1 : 0);
					#endregion

					SignalChangeEvents.SerialValueChange(Device_IP, Channel, Index, Data.src, DateTime.Now.ToString(), Output,
						Power, Voltage, Frequency, Current, Aenergy, Ret_Aenergy, Input_State, Act_Power, Aprt_Power, Power_Factor, Total_Act_Energy,
						Total_Act_Ret_Energy, Brightness, State, Current_Position, Slat_Position, Dev_Event, Red, Green, Blue, White, "", "", "",
						Set_Point_C, Set_Point_F, Alarm, Battery_Voltage, Battery_Percent, Illuminance, Rotation, Window_State, Motion, BTH_Sensor_Value,
						Moisture, Speed_0, Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
						"", "");
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"temperature:\d+")) != -1)
				{
					#region Temperature
					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"temperature:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Temperature temperature = JsonConvert.DeserializeObject<Temperature>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "temperature:" + Channel + " = " + s);

					#region Collect Elements
					if (temperature != null)
					{
						Temperature_C = temperature.tC.ToString();
						Temperature_F = temperature.tF.ToString();
					}
					#endregion

					if ((Temperature_C != "") || (Temperature_F != ""))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, Temperature_C,
							Temperature_F, "", "", "", 999, "", 999, "", "", 999, 999, BTH_Sensor_Value, Moisture, Speed_0, Speed_1,
							UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"humidity:\d+")) != -1)
				{
					#region Humidity
					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"humidity:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Humidity humidity = JsonConvert.DeserializeObject<Humidity>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "humidity:" + Channel + " = " + s);

					#region Collect Elements
					if (humidity != null)
					{
						Relative_Humidity = humidity.rh.ToString();
					}
					#endregion

					if (Relative_Humidity != "")
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", Relative_Humidity, "", "", 999, "", 999, "", "", 999, 999, BTH_Sensor_Value, Moisture, Speed_0,
							Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
				else if ((Start_Index = GetRegexIndex(JSON, @"devicepower:\d+")) != -1)
				{
					#region Device Power

					#region Parse Channel
					if (string.IsNullOrEmpty(s = Parse_Data_Substring(JSON, "", "\"devicepower:", "\"")))
					{
						return;
					}
					Channel = short.Parse(s);
					#endregion

					#region Parse JSON
					if (string.IsNullOrEmpty(s = Isolate_JSON_Substring(JSON, Start_Index)))
					{
						return;
					}
					Devicepower devicepower = JsonConvert.DeserializeObject<Devicepower>(s);
					#endregion

					Debug_Message("Pass_Back_UDP_Response_Data", "devicepower:" + Channel + " = " + s);

					#region Collect Elements
					if ((devicepower != null) && (devicepower.battery != null))
					{
						Battery_Voltage = devicepower.battery.V.ToString();
						Battery_Percent = (short)devicepower.battery.percent;
					}
					#endregion

					if ((Battery_Voltage != "") || (Battery_Percent != 999))
					{
						SignalChangeEvents.SerialValueChange(Device_IP, Channel, 999, Data.src, DateTime.Now.ToString(), 999,
							"", "", "", "", "", "", 999, "", "", "", "", "", 999, "", 999, 999, "", 999, 999, 999, 999, "",
							"", "", "", "", 999, Battery_Voltage, Battery_Percent, "", "", 999, 999, BTH_Sensor_Value, Moisture, Speed_0,
							Speed_1, UV_Index, Direction, Precipitation, Dewpoint, Pressure, Value, Count, Percent, Device_Channel, Steps,
							"", "");
					}
					#endregion
				}
			}
			catch (Exception ex)
			{
				string err = "Shelly - UDP_Message - Pass_Back_UDP_Response_Data: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				#region Variable Dump
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - \n" + ex.StackTrace);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Device_IP = " + Device_IP);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - JSON = " + JSON);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Output = " + Output);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - channel = " + Channel);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Power = " + Power);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Voltage = " + Voltage);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Frequency = " + Frequency);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Current = " + Current);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - aenergy = " + Aenergy);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - ret_aenergy = " + Ret_Aenergy);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Input_State = " + Input_State);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - act_power = " + Act_Power);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - aprt_power = " + Aprt_Power);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - pf = " + Power_Factor);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - total_act_energy = " + Total_Act_Energy);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - total_act_ret_energy = " + Total_Act_Ret_Energy);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - brightness = " + Brightness);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - State = " + State);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Current_Position = " + Current_Position);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Slat_Position = " + Slat_Position);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Dev_Event = " + Dev_Event);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Red = " + Red);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Green = " + Green);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Blue = " + Blue);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Temperature_C = " + Temperature_C);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Temperature_F = " + Temperature_F);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Relative_Humidity = " + Relative_Humidity);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Set_Point_C = " + Set_Point_C);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Set_Point_F = " + Set_Point_F);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Alarm = " + Alarm);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Battery_Voltage = " + Battery_Voltage);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Battery_Percent = " + Battery_Percent);
				CrestronConsole.PrintLine("Shelly - UDP_Message - Pass_Back_UDP_Response_Data - Relative_Humidity = " + BTH_Sensor_Value);
				#endregion
			}
		}

		//****************************************************************************************
		// 
		//  Validate_IP_Address	-	checks if a string contains a valid IP address
		// 
		//****************************************************************************************
		private bool Validate_IP_Address(string IP_Address, string Calling_Routine)
		{
			IPAddress address;

			try
			{
				address = IPAddress.Parse(IP_Address);
			}
			catch (Exception e)
			{
				string err = "Shelly - Validate_IP_Address - Called from: " + Calling_Routine + " - Invalid IP Address: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return false;
			}
			return true;
		}

		//****************************************************************************************
		// 
		//  Isolate_JSON_Substring	-	isolates JSON substring in larger JSON string
		// 
		//****************************************************************************************
		public static string Isolate_JSON_Substring(string JSON, int Start_Index)
		{
			Debug_Message("Find_Matching_Brace", "JSON = " + JSON + ", Start_Index = " + Start_Index);

			if (string.IsNullOrEmpty(JSON) || Start_Index < 0 || Start_Index >= JSON.Length)
			{
				return null;
			}

			// Find the first occurrence of '{' starting from the index
			int First_Brace_Index = JSON.IndexOf('{', Start_Index);

			if (First_Brace_Index == -1)
			{
				Debug_Message("Find_Matching_Brace", "No Open Brace Found");
				return null;
			}

			int Brace_Stack = 0;

			// Iterate through the string starting from the first brace found
			for (int i = First_Brace_Index; i < JSON.Length; i++)
			{
				if (JSON[i] == '{')
				{
					Brace_Stack++;
				}
				else if (JSON[i] == '}')
				{
					Brace_Stack--;

					// When stack hits 0, we've found the matching pair
					if (Brace_Stack == 0)
					{
						string s = JSON.Substring(First_Brace_Index, (i - First_Brace_Index) + 1);
						Debug_Message("Find_Matching_Brace", "Substring = " + s);
						return s;
					}
				}
			}
			Debug_Message("Find_Matching_Brace", "No Matching Closing Brace Found");
			return null; // No matching closing brace found
		}

		//****************************************************************************************
		// 
		//  Isolate_JSON_Substring	-	isolates JSON substring in larger JSON string
		// 
		//****************************************************************************************
		public static string ExtractNumericValueRegex(string jsonString)
		{
			// Matches "value"\s*:\s* followed by digits and an optional decimal point
			Match match = Regex.Match(jsonString, @"""value""\s*:\s*([0-9.]+)");

			if (match.Success)
			{
				// Group 1 contains just the numeric string
				return match.Groups[1].Value;
			}

			return string.Empty;
		}

		//****************************************************************************************
        // 
        //  Set_Debug_Message_Output	-	Save whether debug messages will be output
        //									to console, error log, both, or not sent
        //									0 = None, 1 = Console, 2 = Error Log, 3 = Both
        // 
        //****************************************************************************************
        public static void Set_Debug_Message_Output(short Debug_Level)
        {
            //Save debug message setting as an enum
            switch (Debug_Level)
            {
                case 0:
                    Debug = Debug_Options.None;
                    break;

                case 1:
                    Debug = Debug_Options.Console;
                    break;

                case 2:
                    Debug = Debug_Options.Error_Log;
                    break;

                case 3:
                    Debug = Debug_Options.Both;
                    break;
            }
        }

		//****************************************************************************************
		// 
		//  GetRegexIndex	-	IndexOf with regular expression
		// 
		//****************************************************************************************
		public int GetRegexIndex(string input, string pattern)
		{
			Match m = Regex.Match(input, pattern);

			if (m.Success)
			{
				return m.Index;
			}

			return -1;
		}

        //****************************************************************************************
        // 
        //  Debug_Message	-	Send Debug Message to Console or Error Log
        //						Depending on Selection
        // 
        //****************************************************************************************
        private static void Debug_Message(string Name, string s)
        {
            const int characters_per_line = 250;
            int start_index = 0;
            int length = characters_per_line;

			if (Show_Debug_Messages == false)
			{
				return;
			}

            //json responses are too large for Simpl Debugger to display on a single line
            //so, we break them up into chunks of 250 characters to be printed on 1 line
            while (start_index < s.Length)
            {
                if ((start_index + characters_per_line) > s.Length)
                {
                    length = s.Length - start_index;
                }

                string sub = s.Substring(start_index, length);

                if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
                {
                    CrestronConsole.PrintLine("Shelly Gen2+ - " + Name + " - " + sub);
                }

                if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
                {
					Crestron.SimplSharp.ErrorLog.Notice("Shelly Gen2+ - " + Name + " - " + sub + "\n");
                }

                start_index += characters_per_line;
            }
        }

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		public static string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//Reporting of not finding section or string as an error eliminted because 
			//there are too many situations where the code has to accomodate the fact
			//that hubitat will send back very different messages depending on exactly
			//what setting was changed on a device.  Thermostat is the prime example

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Hubitat-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Hubitat-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Hubitat-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Hubitat-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Shelly - UDP_Message - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Shelly - UDP_Message - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}
	}
}

﻿using System.Reflection;

[assembly: AssemblyTitle("Shelly_UDP")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Shelly_UDP")]
[assembly: AssemblyCopyright("Copyright ©  2025")]
[assembly: AssemblyVersion("1.0.0.*")]

